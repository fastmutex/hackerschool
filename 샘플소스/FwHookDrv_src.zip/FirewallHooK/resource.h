//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by FirewallApp.rc
//
#define IDD_ABOUTBOX                    100
#define IDD_FIREWALLAPP_FORM            101
#define IDR_MAINFRAME                   128
#define IDR_FIREWATYPE                  129
#define IDD_ADDRULEDLG                  132
#define IDC_LIST1                       1000
#define IDC_COMBO3                      1003
#define IDC_EDIT1                       1004
#define IDC_EDIT2                       1005
#define IDC_EDIT3                       1006
#define IDC_EDIT4                       1007
#define IDC_COMBO4                      1009
#define IDC_EDIT5                       1010
#define IDC_EDIT6                       1011
#define ID_BUTTONSTART                  32771
#define ID_BUTTONSTOP                   32772
#define ID_BUTTONADD                    32773
#define ID_BUTTONDEL                    32774
#define ID_BUTTONINSTALL                32775
#define ID_BUTTONDESINSTALL             32776
#define IDMENU_ADDRULE                  32777
#define IDMENU_DELRULE                  32778
#define IDMENU_INSTALLRULES             32779
#define IDMENU_UNINSTALLRULES           32780
#define ID_MENUSTART                    32781
#define ID_MENUSTOP                     32782
#define IDMENU_LOADRULES                32783
#define IDMENU_SAVERULES                32784

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        134
#define _APS_NEXT_COMMAND_VALUE         32785
#define _APS_NEXT_CONTROL_VALUE         1012
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif

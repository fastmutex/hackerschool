/*++

	Copyright (C) 2000, Korea Information Engineering Services, CO., LTD.
	All rights reserved.
 
	FileName:
		tcpip.h

	Description:
		-- define tcp/ip related headers

	Author:
		Written by ChungHanYi, 08/24/1999.

	Misc:

--*/

#pragma once

#define		IPPROTO_ANY		0
#define		IPPROTO_ICMP	1
#define		IPPROTO_TCP		6
#define		IPPROTO_UDP		17

/* ethernet header */
typedef struct _ether{
	UCHAR		dest_addr[6];		/* dest */		
	UCHAR		src_addr[6];		/* src */		
	USHORT		d_type;				/* ether type */
} ether_t;

/* ip header */
typedef struct ip {
	unsigned char	ip_v:4,         /* version */
					ip_hl:4;        /* header length */
    unsigned char	ip_tos;         /* type of service */
    unsigned short	ip_len;         /* total length */
    unsigned short	ip_id;          /* identification */
    unsigned short	ip_off;         /* fragment offset field */
#define IP_DF 0x4000				/* dont fragment flag */
#define IP_MF 0x2000				/* more fragments flag */
    unsigned char	ip_ttl;         /* time to live */
    unsigned char	ip_p;           /* protocol */
    unsigned short	ip_sum;         /* checksum */
    unsigned int	ip_src,ip_dst;  /* source and dest address */
} ip_t;


/* tcp header */
typedef struct tcp {
	 unsigned short	th_sport;
	unsigned short	th_dport;
	unsigned int	th_seq;
	unsigned int	th_ack;
	unsigned char	th_off:4,       /* data offset */
					th_x2:4;        /* (unused) */
	unsigned char	th_flags;

#define TH_FIN  0x01
#define TH_SYN  0x02
#define TH_RST  0x04
#define TH_PUSH 0x08
#define TH_ACK  0x10
#define TH_URG  0x20

	unsigned short	th_win;
	unsigned short	th_sum;
	unsigned short	th_urp;
} tcp_t;

#define	TH_NULL		0x00
#define	TH_R1		0x40		//maybe
#define	TH_R2		0x80		//maybe
#define TH_PA		TH_PUSH | TH_ACK
#define	TH_SF		TH_SYN | TH_FIN
#define	TH_FPU		TH_FIN | TH_PUSH | TH_URG
#define	TH_SFPU		TH_SYN | TH_FIN | TH_PUSH | TH_URG
#define	TH_SRAFPU	TH_SYN | TH_RST | TH_ACK | TH_FIN | TH_PUSH | TH_URG
#define	TH_FU		TH_FIN | TH_URG
#define	TH_PU		TH_PUSH | TH_URG
#define	TH_SU		TH_SYN | TH_URG

/* udp header */
typedef struct udp {
    unsigned short uh_sport;       /* source port */
    unsigned short uh_dport;       /* destination port */
    unsigned short uh_ulen;        /* udp length */
    unsigned short uh_sum;         /* udp checksum */
} udp_t;


// icmp header -- should be defined by you ..
/*
typedef	struct imcp {
	...
} icmp_t;

*/

/* ip overlaid header: 20 bytes */
typedef struct ipovly {
	unsigned int dummy1;
	unsigned int dummy2;
	unsigned char ih_x1;
	unsigned char ih_pr;
	unsigned short ih_len;
	unsigned int ih_src;
	unsigned int ih_dst;
} ipovly_t;

/* tcpip header for tcp checksum computation */
typedef struct tcpiphdr {
	struct ipovly ti_i;
	struct tcp ti_t;
} tcpiphdr_t;

/* udpip header for udp checksum computation */
typedef struct udpiphdr {
	struct ipovly ti_i;
	struct udp ui_t;
} udpiphdr_t;

typedef union xx2 {
	unsigned char a[2];
	unsigned short b;
} u2_t;

typedef union xx4 {
	unsigned char a[4];
	unsigned int b;
} u4_t;

#define htons(a) (((a) >> 8)&0xff|((a) & 0xff)<<8)
#define ntohs(x) htons((x))
#define htonl(a) ((((a) & 0XFF000000) >> 24) | (((a) & 0X00FF0000) >> 8) | \
				  (((a) & 0X0000FF00) << 8)  | (((a) & 0X000000FF) << 24))
#define ntohl(a) (htonl(a))
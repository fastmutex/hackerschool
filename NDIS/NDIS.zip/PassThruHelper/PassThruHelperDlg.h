// PassThruHelperDlg.h : header file
//

#if !defined(AFX_PASSTHRUHELPERDLG_H__42456661_91DD_4A3A_9AF6_E4DBD4483F67__INCLUDED_)
#define AFX_PASSTHRUHELPERDLG_H__42456661_91DD_4A3A_9AF6_E4DBD4483F67__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "global.h"

/////////////////////////////////////////////////////////////////////////////
// CPassThruHelperDlg dialog

class CPassThruHelperDlg : public CDialog
{
// Construction
public:
	CPassThruHelperDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CPassThruHelperDlg)
	enum { IDD = IDD_PASSTHRUHELPER_DIALOG };
	CListBox	m_lstPort;
	CString	m_strPort;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPassThruHelperDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	unsigned char m_sInBuf[256];
	unsigned char m_sOutBuf[256];
	
	bool DeviceIOControl(HANDLE hDevice, MASO_IOCTL_T	iBuf);

	// Generated message map functions
	//{{AFX_MSG(CPassThruHelperDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();	
	afx_msg void OnButtonPortIst();
	afx_msg void OnButtonPortRmv();
	afx_msg void OnButtonInstall();
	afx_msg void OnButtonUninstall();
	afx_msg void OnButtonWdmPort();
	afx_msg void OnButtonWdmPrint1();
	afx_msg void OnButtonWdmPrint2();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PASSTHRUHELPERDLG_H__42456661_91DD_4A3A_9AF6_E4DBD4483F67__INCLUDED_)

/*++

Copyright (c) 1996  Microsoft Corporation

Module Name:

    globals.c

Abstract:

    global declarations

Author:

    Jim Mateer 4/1/97

Environment:

    Kernel Mode

Revision History:

--*/

#include "ImSamp.h"

#pragma hdrstop

#include <ntverp.h>



//
// current adapter whose IM device instance is being initialized. This is
// used by MiniportInitialize to associate the IMSamp MP device with an ADAPTER
// structure
//




//
// AdapterList - List of adapters to which the IMSAMP is bound
//

LIST_ENTRY AdapterList;

//
// AdapterListLock - protects AdapterList
//

NDIS_SPIN_LOCK AdapterListLock;

//
// ClientProtocolHandle - handle returned by NDIS when registering the Client
//    portion of the IM 
//

NDIS_HANDLE ClientProtocolHandle;

//
// MPWrapperHandle - Ndis wrapper handle for MP section
//

NDIS_HANDLE MPWrapperHandle;

//
// LMDriverHandle - handle returned by NDIS when MP portion registers as LM
//

NDIS_HANDLE LMDriverHandle;

//
// IMDriverObject, IMDeviceObject - pointer to NT driver and device objects
//

PDRIVER_OBJECT IMDriverObject;
PDEVICE_OBJECT IMDeviceObject;

//
// ConfigData - global (driver-wide) configuration data
//

CONFIG_DATA ConfigData;

//
// NdisRequestLL - a pre-allocated list of IM_NDIS_REQUEST structures
//

NPAGED_LOOKASIDE_LIST NdisRequestLL;

//
// name constants used during registration/initialization
//

#if BINARY_COMPATIBLE
NDIS_STRING IMSymbolicName = NDIS_STRING_CONST("\\DosDevices\\ImSamp");
#else
NDIS_STRING IMSymbolicName = NDIS_STRING_CONST("\\??\\ImSamp");
#endif

NDIS_STRING IMDriverName = NDIS_STRING_CONST( "\\Device\\ImSamp" );

//
// on Memphis, MP name needs to be the same as Protocol Name
//

#if BINARY_COMPATIBLE
NDIS_STRING IMMPName = NDIS_STRING_CONST( "\\Device\\ImSamp" );
#else
NDIS_STRING IMMPName = NDIS_STRING_CONST( "\\Device\\ImSampMP" );
#endif

#if DBG

//CHAR VersionNumber[] = VER_PRODUCTVERSION_STR;
CHAR VersionNumber[] = "0.100";
CHAR VersionHerald[] = "ImSamp: Ndis 4.0 Intermediate Driver Sample: Version %s built on %s\n";
CHAR VersionTimestamp[] = __DATE__ " " __TIME__;

ULONG DbgTraceLevel;
ULONG DbgTraceMask;


///////////////////////////////////////////////////////////
// Maso IOCTL structures
//
UINT	MAXO_PRINT_TYPE=0;
UINT	MASO_PORT_LIST[MASO_MAX_PORT_LIST];
UINT	MASO_PORT_CNT=0;

#endif

/* end globals.c */

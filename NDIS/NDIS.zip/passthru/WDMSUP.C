/*++

Copyright (c) 1996  Microsoft Corporation

Module Name:

    wdmsup.c

Abstract:

    functions that are supported either directly on NT or by WDM on Memphis

Author:

    Jim Mateer 4-1-97

Environment:

    Kernel Mode

Revision History:

--*/

#pragma hdrstop

#undef BINARY_COMPATIBLE
#define BINARY_COMPATIBLE 0

#include "ImSamp.h"

#include "sioctl.h"

NTSTATUS
WDMInitialize(
    PDRIVER_OBJECT DriverObject,
    PULONG InitShutdownMask
    );

VOID
WDMCleanup(
    ULONG ShutdownMask
    );



STATIC NTSTATUS
IMIoctl(
    IN PDEVICE_OBJECT DeviceObject,
    IN PIRP Irp
    );



#pragma NDIS_PAGEABLE_FUNCTION(IMIoctl)


NTSTATUS
WDMInitialize(
    PDRIVER_OBJECT DriverObject,
    PULONG InitShutdownMask
    )

/*++

Routine Description:

    Perform initialization supported by WDM

Arguments:

    DriverObject - pointer to DriverObject from DriverEntry
    InitShutdownMask - pointer to mask used to indicate which events have been
        successfully init'ed

Return Value:

    STATUS_SUCCESS if everything worked ok

--*/

{
    NTSTATUS Status;
    UINT FuncIndex;

    //
    // Initialize the driver object's entry points
    //

    DriverObject->FastIoDispatch = NULL;

    for (FuncIndex = 0; FuncIndex <= IRP_MJ_MAXIMUM_FUNCTION; FuncIndex++) {
        DriverObject->MajorFunction[FuncIndex] = IMIoctl;
    }

    Status = IoCreateDevice(DriverObject,
                            0,
                            &IMDriverName,
                            FILE_DEVICE_NETWORK,
                            0,
                            FALSE,
                            &IMDeviceObject);

    if ( NT_SUCCESS( Status )) {

        *InitShutdownMask |= SHUTDOWN_DELETE_DEVICE;

        IMDeviceObject->Flags |= DO_BUFFERED_IO;

        Status = IoCreateSymbolicLink( &IMSymbolicName, &IMDriverName );

        if ( NT_SUCCESS( Status )) {

            *InitShutdownMask |= SHUTDOWN_DELETE_SYMLINK;
        } else {
            ImDbgOut(DBG_INFO, DBG_INIT, ("IoCreateSymbolicLink Failed (%08X): %ls -> %ls\n",
                                          Status, IMSymbolicName.Buffer, IMDriverName.Buffer));
        }
    } else {
        ImDbgOut( DBG_CRITICAL_ERROR, DBG_INIT,
                 ("IoCreateDevice Failed - %08x\n", Status ));


        IMDeviceObject = NULL;
    }

    return Status;
}


STATIC NTSTATUS
IMIoctl(
    IN PDEVICE_OBJECT DeviceObject,
    IN PIRP Irp
    )

/*
Routine Description:

    Process the IRPs sent to this device.

Arguments:

    DeviceObject - pointer to a device object
    Irp      - pointer to an I/O Request Packet

Return Value:

    None

*/
{
    PIO_STACK_LOCATION  irpStack;
    PVOID               ioBuffer;
    ULONG               inputBufferLength;
    ULONG               outputBufferLength;
    ULONG               ioControlCode;
    NTSTATUS            Status = STATUS_SUCCESS;

	// for maso
	PCHAR					inputBuf, outputBuf;			// pointer to Input and output buffer..
	MASO_IOCTL_T			*usrMsg;
	// for maso

    PAGED_CODE();

    //
    // Init to default settings- 
    Irp->IoStatus.Status      = STATUS_SUCCESS;
    Irp->IoStatus.Information = 0;

    //
    // Get a pointer to the current location in the Irp. This is where
    //     the function codes and parameters are located.
    //

    irpStack = IoGetCurrentIrpStackLocation(Irp);

    //
    // Get the pointer to the input/output buffer and it's length
    //

    ioBuffer           = Irp->AssociatedIrp.SystemBuffer;
    inputBufferLength  = irpStack->Parameters.DeviceIoControl.InputBufferLength;
    outputBufferLength = irpStack->Parameters.DeviceIoControl.OutputBufferLength;

    switch (irpStack->MajorFunction) {
    case IRP_MJ_CREATE:
        ImDbgOut( DBG_TRACE, DBG_IO, ("IRP Create\n" ));
        break;

    case IRP_MJ_CLOSE:
        ImDbgOut( DBG_TRACE, DBG_IO, ("IRP Close\n" ));
        break;

    case IRP_MJ_CLEANUP:
        ImDbgOut( DBG_TRACE, DBG_IO, ("IRP Cleanup\n" ));
        break;

    case IRP_MJ_SHUTDOWN:
        ImDbgOut( DBG_TRACE, DBG_IO, ("IRP Shutdown\n" ));
        break;

    case IRP_MJ_DEVICE_CONTROL:

        //
        // get control code from stack and perform the operation
        //

        ioControlCode = irpStack->Parameters.DeviceIoControl.IoControlCode;
        switch (ioControlCode) {

       // This is where you would add your IOCTL handlers          

		case IOCTL_SIOCTL_METHOD_BUFFERED :		// buffered i/o.

			// ���ۿ��� ���� �о�´�.
			inputBuf  = Irp->AssociatedIrp.SystemBuffer;
			outputBuf = Irp->AssociatedIrp.SystemBuffer;
			
			if(inputBufferLength != 0)
			{
				//
				// ����� ���α׷����� ��Ŷ�ϳ��� ������ ���̴�.
				// ��Ŷ�� �޾Ƽ� �츮�� ���ϴ� �۾��� �Ѵ�.
				//
				usrMsg = (MASO_IOCTL_T*)inputBuf;
				switch(usrMsg->type)
				{
				case MASO_IO_PORT_CLEAR :
					//
					// ��Ʈ�� �ִ� ���� ��� ���ִ� ����̴�.
					// ��Ʈ �迭�� �ε����� 0���� �������μ� �ذ��Ѵ�.
					//

					DbgPrint("PASSTHRU: MASO_IO_PORT_CLEAR");
					MASO_PORT_CNT=0;
					break;

				case MASO_IO_PORT_ADD:
					//
					// ��Ʈ�� ���� �־��ֵ��� �Ѵ�.
					// ��Ʈ �迭�� �ε����� �ϳ��÷��ش�.
					//

					DbgPrint("PASSTHRU: MASO_IO_PORT_ADD");
					if( MASO_PORT_CNT<MASO_MAX_PORT_LIST )
					{
						MASO_PORT_LIST[MASO_PORT_CNT]=usrMsg->port;
						MASO_PORT_CNT++;
						DbgPrint("PASSTHRU: PORT %d ADDED", usrMsg->port);
					}
					else
					{
						DbgPrint("PASSTHRU: PORT CNT EXCEEDED %d", MASO_MAX_PORT_LIST);
					}
					break;

				case MASO_IO_PRINT_TYPE_1:
					//
					// ����Ʈ Ÿ���� 1�� �����ش�.
					// IP������ֵ��� �ϴ� �ɼ��̴�.
					// 

					DbgPrint("PASSTHRU: CHANGE PRINT TYPE TO 1 (show IP)");
					MAXO_PRINT_TYPE=1;
					break;

				case MASO_IO_PRINT_TYPE_2:
					//
					// ����Ʈ Ÿ���� 2�� �����ش�.
					// ��Ʈ������ֵ��� �ϴ� �ɼ��̴�.
					// 

					DbgPrint("PASSTHRU: CHANGE PRINT TYPE TO 2 (show IP, PORT)");
					MAXO_PRINT_TYPE=2;
					break;

				default:
					break;
				}
			}
			break;
		default:
            ImDbgOut( DBG_INFO, DBG_IO,
                     ("unknown IRP_MJ_DEVICE_CONTROL\n = %X\n",ioControlCode));
            Status = STATUS_INVALID_PARAMETER;
            break;
        }
        break;

    default:
        ImDbgOut(DBG_INFO, DBG_IO,
                 ("unknown IRP major function = %08X\n", irpStack->MajorFunction));

        Status = STATUS_UNSUCCESSFUL;
        break;
    }

    //
    // all requests complete synchronously; notify caller of status
    //

    Irp->IoStatus.Status = Status;
    Irp->IoStatus.Information = outputBufferLength;

    IoCompleteRequest(Irp, IO_NO_INCREMENT);

    return Status;

} // ImIoctl




VOID
WDMCleanup(
    ULONG ShutdownMask
    )

/*++

Routine Description:

    Cleanup code for WDMInitialize

Arguments:

    ShutdownMask - mask indicating which functions need to be cleaned up

Return Value:

    None

--*/

{
    if ( ShutdownMask & SHUTDOWN_DELETE_SYMLINK ) {

        IoDeleteSymbolicLink( &IMSymbolicName );
    }

    if ( ShutdownMask & SHUTDOWN_DELETE_DEVICE ) {

        IoDeleteDevice( IMDeviceObject );
    }
}

/* end wdmsup.c */

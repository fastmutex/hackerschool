//****************************************************************************//
//*                                                                           //
//* Copyright (C) 2003, James Antognini, antognini@mindspring.com.            //
//*                                                                           //
//****************************************************************************//

/******************************************************************************/      
/*                                                                            */      
/* Routine that talks to TCP/IP, which is transport.                          */      
/*                                                                            */      
/* Notes:                                                                     */      
/*        1) Most routines here are intended to be called at PASSIVE_LEVEL,   */      
/*           since they do things like touch pageable storage or wait.        */      
/*                                                                            */      
/******************************************************************************/      

/******************************************************************************/      
/*                                                                            */      
/* Some code is based very loosely on Gary Nebbett, "Sample TDI kernel-mode   */      
/* client," comp.os.ms-windows.programmer.nt.kernel-mode, 1998/04/16.         */      
/*                                                                            */      
/******************************************************************************/      

#define JADrvRtnsName   "TDIClientRtns"
#define JADrvRtnsVer    "2.26"                                                                  
                                                                                                
#ifdef __cplusplus  // C++ conversion.                                                          
extern "C"                                                                                      
{                                                                                               
#endif              // End #ifdef C++ conversion.                                               
                                                                                                
#include <ntddk.h>
#include <tdikrnl.h>
                                                                                                
#define  JADriverKernelMode 1                         // Ensure kernel pieces available.        
#include "TDIClient.h"                                                                             
                                                                                                
#ifdef __cplusplus  // C++ conversion.                                                          
}                                                                                               
#endif              // End #ifdef C++ conversion.                                               

// The preprocessor variable UseRecvHandler controls whether the Receive event handler is used.
// This variable may be externally defined (ie, in sources file or in a command window) via
// C_DEFINES, eg, C_DEFINES=-DUseRecvHandler=FALSE.

#if !defined(UseRecvHandler)                          // Not defined?
#define UseRecvHandler   FALSE                        // Set UseRecvHandler to FALSE.
#endif

//****************************************************************************//
//*                                                                           //
//* Globals.                                                                  //
//*                                                                           //
//****************************************************************************//

#define CompDateTimeStr "dd mmm yyyy hh:mm:ss"

char DrvRtnsCompileInfo[sizeof(CompDateTimeStr)+1] =  // Null in first character means not initialized.
       {0x0};

char static * pSendData[] = {                         // Pointer to data to be sent.
                             "Hello from TDIClientMain() v" JADrvRtnsVer,
                             "Hello number 2 from TDIClient driver",
                             "Hello from TDIClient driver number 3",
                             "Hello number 4 from TDIClient driver",
                             "Hello from TDIClient driver number 5"
                            };
  
//****************************************************************************//
//*                                                                           //
//* Forward definitions of some routines provided here.                       //
//*                                                                           //
//****************************************************************************//

NTSTATUS
TDIClnExecClient(pTDIClientExtension, ULONG, USHORT, pTDIClnReqElem, PULONG, PULONG);

NTSTATUS
TDIClnExecServer(pTDIClientExtension, ULONG, USHORT, pTDIClnReqElem, PULONG, PULONG);

NTSTATUS
TDIClnPerformSends(pTDIClientExtension, PFILE_OBJECT, pTDIClnReqElem, PULONG);

NTSTATUS
TDIClnPerformReceives(pTDIClientExtension, PFILE_OBJECT, pTDIClnReqElem, TDIClientOperType, pTDIClnConn, PULONG);

/**************************************************************************************************/
/*                                                                                                */
/**************************************************************************************************/
NTSTATUS
TDIClientMain(
              pTDIClientExtension pDevExt,            // Device extension.
              pTDIClientTestStr   pInStr              // Parameters from user space (via IOCTL).
             )
{
 NTSTATUS                    status,
                             ExecStatus = STATUS_SUCCESS;

 #define                     NbrReq    10             // Number of request elements.
 #define                     NbrConns  2              // Number of connection endpoints.

 TDIClnReqElem               ReqElem[NbrReq];

 if (0==DrvRtnsCompileInfo[0])                        // Information string about compilation date and time not yet built?
   {
    char static DateCompiledBase[] = __DATE__,
                TimeCompiledBase[] = " "__TIME__;
    char        tmpDateCompileInfo[]   =              // Build date in preferred (dd mmm yyyy) format.
                  {DateCompiledBase[4], DateCompiledBase[5], DateCompiledBase[6],
                   DateCompiledBase[0], DateCompiledBase[1], DateCompiledBase[2], DateCompiledBase[3],
                   DateCompiledBase[7], DateCompiledBase[8], DateCompiledBase[9], DateCompiledBase[10],
                   0x0
                  };

    // Build date and time of compilation.

    if (' '==tmpDateCompileInfo[0])                   // Leading blank (ie, first through ninth day of month)?
      strcpy(DrvRtnsCompileInfo, tmpDateCompileInfo+1); 
    else
      strcpy(DrvRtnsCompileInfo, tmpDateCompileInfo+0);
    strcat(DrvRtnsCompileInfo, TimeCompiledBase);
   }

 DbgPrint((JADrvNm " " JADrvRtnsName " v" JADrvRtnsVer " TDIClientMain() (compiled %s)\n",
           DrvRtnsCompileInfo));
 
 do {                                                 // Single-iteration loop, to make possible escape via break.
     pDevExt->hAddr = INVALID_HANDLE_VALUE;
     pDevExt->pAddrFileObj = NULL;
     pDevExt->pReqElemsArr = NULL;
     pDevExt->pBufferBase = NULL;
     pDevExt->pTDIClnConnArr = NULL;

     //
     // Handle parameters.
     //

     WCHAR * pOutW;

     ANSI_STRING AnsiDestAddr,
                 AnsiDestPort;

     AnsiDestAddr.Length = strlen(pInStr->InDestAddr);
     AnsiDestAddr.MaximumLength = strlen(pInStr->InDestAddr) + 1;
     AnsiDestAddr.Buffer = pInStr->InDestAddr;

     AnsiDestPort.Length = strlen(pInStr->InDestPort);
     AnsiDestPort.MaximumLength = strlen(pInStr->InDestPort) + 1;
     AnsiDestPort.Buffer = pInStr->InDestPort;

     UNICODE_STRING UniDestAddr,
                    UniDestPort;

     status = RtlAnsiStringToUnicodeString(&UniDestAddr, &AnsiDestAddr, TRUE);

     if (!NT_SUCCESS(status))
       {
        DbgPrint((JADrvNm " " JADrvRtnsName ".TDIClientMain:  Failed RtlAnsiStringToUnicodeString() # 1, status = 0x%08x, quitting\n", status));
        break;
       }

     status = RtlAnsiStringToUnicodeString(&UniDestPort, &AnsiDestPort, TRUE);

     if (!NT_SUCCESS(status))
       {
        DbgPrint((JADrvNm " " JADrvRtnsName ".TDIClientMain:  Failed RtlAnsiStringToUnicodeString() # 2, status = 0x%08x, quitting\n", status));
        break;
       }

     ULONG  DestAddr =                                // Get network-form address (translate octets to binary and swap positions).
       GetInetAddr(UniDestAddr.Buffer, &pOutW);
     USHORT DestPort =                                // Get network-form port.
       (USHORT)((GetInetAddr(UniDestPort.Buffer, &pOutW))>>16);

     RtlFreeUnicodeString(&UniDestAddr);              // Free allocated storage.
     RtlFreeUnicodeString(&UniDestPort);              // "

     //
     // Open transport address.
     //

     // Note:  According to DDK ("Opening a Connection Endpoint" and "Making an Endpoint-to-Endpoint
     //        Connection"), the client first opens transport address and then connection.

     USHORT tmpPort =                                 // If acting as server, use supplied port; otherwise, 0.
       TDIClientServer==pInStr->InOperType ? DestPort : 0;

//   DbgPrint((JADrvNm " " JADrvRtnsName ".TDIClientMain:  Opening transport addr = %d\n", GetNetwkPort(tmpPort)));

     status = TDIClnOpenTransAddr(                    
                                  wcharTcpDevName,
                                  &pDevExt->hAddr,
                                  &pDevExt->pAddrFileObj,
                                  tmpPort
                                 );

     if (!NT_SUCCESS(status))                         // A problem?
       break;

     //
     // Get buffer space, request elements, etc.
     //

     // Get space for request elements.

     pDevExt->pReqElemsArr =                         
       (pTDIClnReqElem)ExAllocatePool(
                                      NonPagedPool,
                                      sizeof(TDIClnReqElem)*NbrReq
                                     );

     if (NULL==pDevExt->pReqElemsArr)                 // Didn't work?
       {
        DbgPrint((JADrvNm " " JADrvRtnsName ".TDIClientMain:  Failed to get request elements, quitting\n"));
        status = STATUS_INSUFFICIENT_RESOURCES;
        break;
       }

     memset(pDevExt->pReqElemsArr,
            0,
            sizeof(TDIClnReqElem)*NbrReq
           );

     #if UseRecvHandler                               // Use Receive event handler?
     #define BufferPoolType NonPagedPool              // Get storage from non-paged pool.
     #else
     #define BufferPoolType PagedPool                 // Get storage from paged pool.
     #endif

     // Get buffer space.  If paged pool is used, MmProbeAndLockPages will be used later, and the transport
     // is presumed to do the unfixing.

     pDevExt->pBufferBase =                           
       (PCHAR)ExAllocatePool(
                             BufferPoolType,
                             TDIClientRecvBfrLen*NbrReq
                            );

     if (NULL==pDevExt->pBufferBase)                  // Didn't work?
       {
        DbgPrint((JADrvNm " " JADrvRtnsName ".TDIClientMain:  Failed to get buffer, quitting\n"));
        status = STATUS_INSUFFICIENT_RESOURCES;
        break;
       }

     // Set up request elements.

     for (ULONG i = 0; i < NbrReq; i ++)              
       {
        ReqElem[i].pBuffer =                          // Point to i-th place in buffer.
          pDevExt->pBufferBase + (i*TDIClientRecvBfrLen);
        KeInitializeEvent(&ReqElem[i].RecvEvent,      // Initialize i-th Receive event (used only in completion of a Receive Irp).
                          NotificationEvent,
                          FALSE                       // Initialized to not-signalled.
                         );
       }

     // Get space for connection endpoint structures.

     pDevExt->pTDIClnConnArr =                       
       (pTDIClnConn)ExAllocatePool(
                                   NonPagedPool,
                                   sizeof(TDIClnConn)*NbrConns
                                  );

     if (NULL==pDevExt->pTDIClnConnArr)               // Didn't work?
       {
        DbgPrint((JADrvNm " " JADrvRtnsName ".TDIClientMain:  Failed to get client connection endpoints, quitting\n"));
        status = STATUS_INSUFFICIENT_RESOURCES;
        break;
       }

     memset(pDevExt->pTDIClnConnArr,                  // Clear memory.
            0,
            sizeof(TDIClnConn)*NbrConns
           );

     //
     // Open connection endpoints.
     //

     for (ULONG i = 0; i < NbrConns; i ++)            
       {
        pDevExt->pTDIClnConnArr[i].pReqElemsArr =     // Point to array of request elements.
          ReqElem;
        pDevExt->pTDIClnConnArr[i].pDevExt =          // Point to device extension.
          pDevExt;
        pDevExt->pTDIClnConnArr[i].hConn =            // Show invalid handle value.
          INVALID_HANDLE_VALUE;

        status = TDIClnOpenConnEndPt(                 
                                     &pDevExt->pTDIClnConnArr[i],
                                     pDevExt
                                    );

        if (!NT_SUCCESS(status))                      // A problem?
          goto doCleanUp;
       }                                              

     //
     // Get pointer to TDI driver's (\Driver\SYMTDI, as found by windbg on WinXP Pro SP1 system) device object.
     //

     pDevExt->pTcpDevObj = IoGetRelatedDeviceObject(pDevExt->pAddrFileObj);

     //
     // Set up some event handlers.
     //

#if UseRecvHandler                                    // Use Receive event handler?

     status =                                         // Set up Receive event handler.
       TDIClnSetEventHandler(
                             pDevExt->pAddrFileObj,
                             pDevExt->pTcpDevObj,
                             TDI_EVENT_RECEIVE,
                             TDIClnEventReceive,      // Receive event handler routine.
                             NULL                     // Context for event handler.
                            );

     if (!NT_SUCCESS(status)) break;

#endif                                                // End #if UseRecvHandler.

     status =                                         // Set up disconnect event handler.
       TDIClnSetEventHandler(
                             pDevExt->pAddrFileObj,
                             pDevExt->pTcpDevObj,
                             TDI_EVENT_DISCONNECT,
                             TDIClnEventDisconnect,   // Disconnect event handler routine.
                             NULL                     // Context for event handler.
                            );
  
     if (!NT_SUCCESS(status)) break;

     status =                                         // Set up error event handler.
       TDIClnSetEventHandler(
                             pDevExt->pAddrFileObj,
                             pDevExt->pTcpDevObj,
                             TDI_EVENT_ERROR_EX,
                             TDIClnEventErrorEx,      // Error event handler routine.
                             NULL
                            );                        // Context for event handler.

     if (!NT_SUCCESS(status)) break;

     //
     // Associate connection endpoints with transport address.
     //

     for (ULONG i = 0; i < NbrConns; i ++)            
       {
        status = TDIClnAssocAddr(                     
                                 pDevExt->pTDIClnConnArr[i].pConnFileObj,
                                 pDevExt->pTcpDevObj,
                                 pDevExt->hAddr
                                );

        if (!NT_SUCCESS(status))
          goto doCleanUp;
       }

     //
     // Handle the requested operation.
     //

     ULONG ulKernelSent,
           ulKernelReceived;

     if (TDIClientClient==pInStr->InOperType)         // Client operation?
       {
        ExecStatus = TDIClnExecClient(
                                      pDevExt,
                                      DestAddr,
                                      DestPort,
                                      ReqElem,        // Address of request-element array.
                                      &ulKernelSent,
                                      &ulKernelReceived
                                     );

        if (STATUS_SUCCESS==ExecStatus)
          {
           pInStr->ulKernelSent = ulKernelSent;
           pInStr->ulKernelReceived = ulKernelReceived;
          }
       }
     else
     if (TDIClientServer==pInStr->InOperType)         // Server operation?
       {
        ExecStatus = TDIClnExecServer(
                                      pDevExt,
                                      DestAddr,
                                      DestPort,
                                      ReqElem,        // Address of request-element array.
                                      &ulKernelSent,
                                      &ulKernelReceived
                                     );
                                      
        if (STATUS_SUCCESS==ExecStatus)
          {
           pInStr->ulKernelSent = ulKernelSent;
           pInStr->ulKernelReceived = ulKernelReceived;
          }
       }
     else
       {
        DbgPrint((JADrvNm " " JADrvRtnsName ".TDIClientMain:  Unknown operation, quitting\n"));
        ExecStatus = STATUS_INVALID_PARAMETER;
       }

     //
     // Disassociate connection endpoints from transport address.
     //

     for (ULONG i = 0; i < NbrConns; i ++)            
       {
        status = TDIClnDisassocAddr(
                                    pDevExt->pTDIClnConnArr[i].pConnFileObj,
                                    pDevExt->pTcpDevObj
                                   );

        if (!NT_SUCCESS(status))
          goto doCleanUp;
       }
    } while(0);                                       // End 'do-while' single-iteration loop.

doCleanUp:
 if (NULL!=pDevExt->pBufferBase)                      // Got a buffer?
   {
    ExFreePool(pDevExt->pBufferBase);
    pDevExt->pBufferBase = NULL;
   }

 if (NULL!=pDevExt->pReqElemsArr)                     // Got request elements?
   {
    ExFreePool(pDevExt->pReqElemsArr);
    pDevExt->pReqElemsArr = NULL;
   }

 if (INVALID_HANDLE_VALUE!=pDevExt->hAddr)            // Opened transport address?
   {
    ZwClose(pDevExt->hAddr);
    pDevExt->hAddr = INVALID_HANDLE_VALUE;
   }

 if (NULL!=pDevExt->pTDIClnConnArr)                   // Got connection structures?
   {
    for (ULONG i = 0; i < NbrConns; i ++ )            
      {
       if (INVALID_HANDLE_VALUE!=                     // Opened connection endpoint?
           pDevExt->pTDIClnConnArr[i].hConn)
         {
          ZwClose(pDevExt->pTDIClnConnArr[i].hConn);
          pDevExt->pTDIClnConnArr[i].hConn = INVALID_HANDLE_VALUE;
         }

       if (NULL!=                                     // Referenced object?
             pDevExt->pTDIClnConnArr[i].pConnFileObj)
         {
          ObDereferenceObject(pDevExt->pTDIClnConnArr[i].pConnFileObj);
          pDevExt->pTDIClnConnArr[i].pConnFileObj = NULL;
         }
      }

    ExFreePool(pDevExt->pTDIClnConnArr);              // Free storage used for connection structures.
    pDevExt->pTDIClnConnArr = NULL;
   }

 if (NULL!=pDevExt->pAddrFileObj)                     // Referenced object?
   {
    ObDereferenceObject(pDevExt->pAddrFileObj);
    pDevExt->pAddrFileObj = NULL;
   }

 return STATUS_SUCCESS==status ? ExecStatus : status; // Return ExecStatus unless status!=STATUS_SUCCESS.
}                                                     // End TDIClientMain().

/**************************************************************************************************/
/*                                                                                                */
/* Perform functions as client to remote server.                                                  */
/*                                                                                                */
/**************************************************************************************************/
NTSTATUS
TDIClnExecClient(
                 pTDIClientExtension pDevExt,
                 ULONG               DestAddr,        // IP address of destination.
                 USHORT              DestPort,        // Port of destination.
                 pTDIClnReqElem      pReqElem,        // Address of request-element array.
                 PULONG              pUlKernelSent,
                 PULONG              pUlKernelReceived
                )
{
 NTSTATUS                    status;

 do {                                                 // Single-iteration loop, to make possible escape via break.
     pTDIClnConn                 pLclConn = NULL;

     //
     // Connect to address and port specified by IOCTL.
     //

     // Note:  If TDIClientExec is done on a previously used connection, even one that has been disconnected,
     //        STATUS_ADDRESS_ALREADY_EXISTS (0xC000020A) will result if connection is in TIME_WAIT.

     for (ULONG i = 0; i < NbrConns; i ++)            // Try to open a connection endpoint.
       {
        KeInitializeEvent(&pDevExt->pTDIClnConnArr[i].DiscEvent, NotificationEvent, FALSE);
        
        status = TDIClnConnect(                       // Effect connection by initiating offer.
                               pDevExt->pTDIClnConnArr[i].pConnFileObj,
                               pDevExt->pTcpDevObj,
                               DestAddr,
                               DestPort
                              );

        if (NT_SUCCESS(status))                       // Success?
          {                                           // Use this connection structure.
           pLclConn = &pDevExt->pTDIClnConnArr[i];    // Get a pointer to the connection structure.
           pLclConn->bConnd = TRUE; 

           break;
          }
       }

     if (NULL==pLclConn)                              // Didn't work?
       {
        DbgPrint((JADrvNm " " JADrvRtnsName ".TDIClnExecClient:  Failed in TDIClnConnect(), quitting\n", status));
        break;
       }

     // Note:  Because the same buffers are used in Receive and Send, all Send operations must be complete
     //        before Receive operations commence, and vice-versa.

     //
     // Perform Sends.
     //

     ULONG ulKernelSent,
           ulKernelReceived;

     status = TDIClnPerformSends(                     
                                 pDevExt,
                                 pLclConn->pConnFileObj,
                                 pReqElem,            // Address of request-element array.
                                 pUlKernelSent
                                );

     if (STATUS_SUCCESS!=status)                      // A problem?
       break;

     //
     // Perform Receives.
     //

     status = TDIClnPerformReceives(
                                    pDevExt,
                                    pLclConn->pConnFileObj,
                                    pReqElem,         // Address of request-element array.
                                    TDIClientClient,  // This indicates disconnection at the proper place.
                                    pLclConn,
                                    pUlKernelReceived
                                   );

     if (STATUS_SUCCESS!=status)
       break;
    } while(0);                                       // End 'do-while' single-iteration loop.
  
 return status;
}                                                     // End TDIClnExecClient().

/**************************************************************************************************/
/*                                                                                                */
/* Perform functions as server to remote client.                                                  */
/*                                                                                                */
/**************************************************************************************************/
NTSTATUS
TDIClnExecServer(
                 pTDIClientExtension pDevExt,
                 ULONG               DestAddr,        // IP address of destination.
                 USHORT              DestPort,        // Port of destination.
                 pTDIClnReqElem      pReqElem,        // Address of request-element array.
                 PULONG              pUlKernelSent,
                 PULONG              pUlKernelReceived
                )
{
 NTSTATUS                    status;
 IO_STATUS_BLOCK             IoStatus;
 PVOID                       pLclConnIPInfo = NULL;
  
 // Note:  At present, the first (0-th) element of the array of TDIClnConn elements is always used.

 pTDIClnConn                 pLclClnConn =            // Point to 0-th element in array of TDIClnConn elements.
                               pDevExt->pTDIClnConnArr + 0;

 do {                                                 // Single-iteration loop, to make possible escape via break.
     //
     // Build IP address structures (for local server (not used any longer) and for remote client).
     //

     ULONG IPAddrWkSz =                               // Size of storage needed for IP address structures.
                        (2*sizeof(TDI_CONNECTION_INFORMATION)) +    
                        (2*sizeof(TA_IP_ADDRESS));                  

     pLclConnIPInfo =                                 // Get storage.
       (pConnParms)ExAllocatePool(NonPagedPool, IPAddrWkSz);

     if (NULL==pLclConnIPInfo)
       {
        DbgPrint((JADrvNm " " JADrvRtnsName ".TDIClnExecServer:  Couldn't get storage\n"));
        status = STATUS_INSUFFICIENT_RESOURCES;
        break;
       }

     memset(pLclConnIPInfo, 0, IPAddrWkSz);           // Zero storage.

     PTDI_CONNECTION_INFORMATION pServerConn =        // Point to server structure.
       (PTDI_CONNECTION_INFORMATION)pLclConnIPInfo,
                                 pClientConn =        // Point to client structure.
                                   &pServerConn[1];

     PTA_IP_ADDRESS pLclServerInfo =                  // Point to server structure.
                      (PTA_IP_ADDRESS)&pServerConn[2],
                    pRmtClientInfo =                  // Point to client structure.
                      &pLclServerInfo[1];

     pRmtClientInfo->TAAddressCount = 1;
     pRmtClientInfo->Address[0].AddressLength = TDI_ADDRESS_LENGTH_IP;
     pRmtClientInfo->Address[0].AddressType = TDI_ADDRESS_TYPE_IP;

     pClientConn->RemoteAddressLength = sizeof(TA_IP_ADDRESS);
     pClientConn->RemoteAddress = pRmtClientInfo;

     pLclClnConn->pClientConnInfo = pClientConn;

     //
     // Prepare an Irp for Accept, to be used in TDIClnEventConnect().
     //

     KeInitializeEvent(                               // Initialize Accept event.
                       &pLclClnConn->AccEvent, NotificationEvent, FALSE);

     PIRP pIrp =                                      // Get an Accept Irp that will be finalized in TDIClnEventConnect().
       TdiBuildInternalDeviceControlIrp(TDI_ACCEPT,
                                        pDevExt->pTcpDevObj,    // TDI driver's device object.
                                        pLclClnConn->pConnFileObj,
                                        &pLclClnConn->AccEvent, // Event to be signalled when Irp completes.
                                        &IoStatus               // I/O status block.
                                       );

     if (NULL==pIrp)
       {
        status = STATUS_INSUFFICIENT_RESOURCES;
        break;
       }

     pDevExt->pIrpAccept = pIrp;                      // Keep Irp address.  

     KeInitializeEvent(                               // Initialize Disconnect event.
                       &pLclClnConn->DiscEvent, NotificationEvent, FALSE);

     //
     // Set up connect event handler.
     //

     status =                                         
       TDIClnSetEventHandler(pDevExt->pAddrFileObj,
                             pDevExt->pTcpDevObj,
                             TDI_EVENT_CONNECT,
                             TDIClnEventConnect,
                             pLclClnConn              // Context for event.
                            );
  
     if (!NT_SUCCESS(status)) break;

     // Wait for connection and then acceptance to occur (connection event handler will provide the Accept Irp
     // for transport to run).

     KeWaitForSingleObject(&pLclClnConn->AccEvent, Executive, KernelMode, FALSE, 0);

     if (STATUS_SUCCESS!=IoStatus.Status)             // A problem?
       break;

     // Note:  Because the same buffers are used in Receive and Send, all Receive operations must be complete
     //        before Send operations commence, and vice-versa.

     //
     // Perform Receives.
     //

     status = TDIClnPerformReceives(
                                    pDevExt,
                                    pLclClnConn->pConnFileObj,
                                    pReqElem,         // Address of request-element array.
                                    TDIClientServer,  // This indicates disconnection is not to be done.
                                    NULL,
                                    pUlKernelReceived
                                   );

     if (STATUS_SUCCESS!=status)
       break;

     //
     // Perform Sends.
     //

     status = TDIClnPerformSends(
                                 pDevExt,
                                 pLclClnConn->pConnFileObj,
                                 pReqElem,            // Address of request-element array.
                                 pUlKernelSent
                                );

     if (STATUS_SUCCESS!=status)
       break;

     //
     // Disconnect.
     //

     status = TDIClnDisconnect(
                               pLclClnConn->pConnFileObj,
                               pDevExt->pTcpDevObj
                              );

     if (
         !NT_SUCCESS(status)                          // A problem?
           &&
         STATUS_CONNECTION_INVALID!=status            // Problem is not invalid connection, eg, not due to other side disconnecting?
        )
       break;

     // Wait on disconnection to complete.

     KeWaitForSingleObject(&pLclClnConn->DiscEvent, Executive, KernelMode, FALSE, 0);

    } while(0);                                       // End 'do-while' single-iteration loop.
  
 if (NULL!=pLclConnIPInfo)
   ExFreePool(pLclConnIPInfo);

 return status;
}                                                     // End TDIClnExecServer().
 
/**************************************************************************************************/
/*                                                                                                */
/* Perform Sends on open connection.                                                              */
/*                                                                                                */
/**************************************************************************************************/
NTSTATUS
TDIClnPerformSends(
                   pTDIClientExtension pDevExt,
                   PFILE_OBJECT        pConnFileObj,
                   pTDIClnReqElem      pReqElem,      // Address of request-element array.
                   PULONG              pUlKernelSent
                  )
{
 NTSTATUS                    status = STATUS_SUCCESS;

 do {                                                 // Single-iteration loop, to make possible escape via break.
     // Build and send first (dynamic) string.

     strcpy(pReqElem[0].pBuffer+sizeof(ULONG),        // Start just after area to be used for total length.
            pSendData[0]
           );
     strcat(pReqElem[0].pBuffer+sizeof(ULONG), " (compiled ");
     strcat(pReqElem[0].pBuffer+sizeof(ULONG), DrvRtnsCompileInfo);
     strcat(pReqElem[0].pBuffer+sizeof(ULONG), ")");

     ULONG ulTotalSend =                                   // Get length of 
             sizeof(ULONG) +                               //   length field +
             strlen(pReqElem[0].pBuffer+sizeof(ULONG)) + 1,//   size of this string, including terminator.
           ulFirstSend = ulTotalSend;                      // Copy length of first Send.

     for (ULONG i = 1; i < arraysize(pSendData); i ++)// Add lengths of other (fixed) strings, including their terminators.
       ulTotalSend += strlen(pSendData[i]) + 1;

     *(PULONG)pReqElem[0].pBuffer = ulTotalSend;      // Put total length of all sent bytes at the beginning.

     status = TDIClnSend(pConnFileObj,
                         pDevExt->pTcpDevObj,
                         pReqElem[0].pBuffer,
                         ulFirstSend
                        );

     if (!NT_SUCCESS(status)) break;

     // Send remaining (static) strings.

     for (ULONG i = 1; i < arraysize(pSendData); i ++)
       {
        ULONG ulSend = strlen(pSendData[i])+1;

        status = TDIClnSend(pConnFileObj,
                            pDevExt->pTcpDevObj,
                            pSendData[i],
                            ulSend
                           );

        if (!NT_SUCCESS(status))
          goto done;
       }

     *pUlKernelSent = ulTotalSend;                    // Set first send length.

     DbgPrint((JADrvNm " " JADrvRtnsName ".TDIClnPerformSends:  Sent %d bytes\n", ulTotalSend));
    } while(0);                                       // End 'do-while' single-iteration loop.
  
done:
 if (STATUS_SUCCESS!=status)
   {
    DbgPrint((JADrvNm " " JADrvRtnsName ".TDIClnPerformSends:  Ending status = %lx\n", status));
   }
  
 return status;
}                                                     // End TDIClnPerformSends().

/**************************************************************************************************/
/*                                                                                                */
/* Perform Receives on open connection.                                                           */
/*                                                                                                */
/* If caller is acting as client, disconnection will be done, too.                                */
/*                                                                                                */
/**************************************************************************************************/
NTSTATUS
TDIClnPerformReceives(
                      pTDIClientExtension pDevExt,
                      PFILE_OBJECT        pConnFileObj,
                      pTDIClnReqElem      pReqElem,   // Address of request-element array.
                      TDIClientOperType   OperType,
                      pTDIClnConn         pLclConn,
                      PULONG              pUlKernelReceived
                     )
{
 NTSTATUS                    status;

 do {                                                 // Single-iteration loop, to make possible escape via break.
     ULONG i,
           nbrWaits,
           ulDataSent,
           ulDataRcvd;

     for (                                            // Do Receives (or just loop, if Receive event handler used).
          i = 0,
            nbrWaits = 0;
          i < NbrReq;
          i ++,
            nbrWaits ++                               // Bump number of waits to be done.
         )
       {
        // If the Receive event handler is being used, incoming data are received without any Receive Irps being
        // sent to the transport.  That is, this particular routine is more "server-like," just responding to
        // client requests and not (in the case of Receive operations) initiating I/O.  But the same Receive event
        // handler logic works well when the role being performed is that of a client to a remote server.
        //
        // For didactic purposes, however, the "active" Receive logic (that is, the call to TDIClnRecv) is
        // retained and can be used by building with the preprocessor variable UseRecvHandler set to FALSE (see
        // above on how to do that).

        if (TRUE==UseRecvHandler)                     // Using Receive event handler?
          continue;                                   // Skip to bottom of loop.

        // Since there's no guarantee that a particular Receive will contain integral sent units
        // (that is, the strings sent by WinsockServer.cpp), zero the Receive buffer so that even
        // if the last string in a buffer is not complete, it will appear as a string since what
        // there is of it will be null-terminated.

        memset(pReqElem[i].pBuffer, 0, TDIClientRecvBfrLen);

        status = TDIClnRecv(pConnFileObj,
                            pDevExt->pTcpDevObj,
                            pReqElem[i].pBuffer,           // Buffer to fill.
                            TDIClientRecvBfrLen-1,         // Ensure that at least the last null remains untouched.
                            &pReqElem[i].ReqIoStatus,      // IoStatus.
                            &pReqElem[i]                   // Context for I/O completion routine.
                           );

        if (
            STATUS_SUCCESS!=status
              &&
            STATUS_PENDING!=status
           )
          {
           if (STATUS_INVALID_DEVICE_STATE!=status)   // Not (presumably) past last good Send/Receive?
             {
              DbgPrint((JADrvNm " " JADrvRtnsName ".TDIClnPerformReceives:  Receive status = %lx\n", status));
             }
           break;
          }
       }                                              // End 'for' do Receives (or just loop).

     if (TDIClientClient==OperType)                   // Is caller acting as client?
       {
        // Doing disconnection ensures WinsockServer.cpp (other side) sees return code = 0 from Receive.  If
        // disconnection were not done at this point (that is, if wait were done here immediately), WinsockServer
        // would continue waiting for latest Receive (in loop) to complete and would not do Send, and
        // this side would wait indefinitely for wait (eg, until WinsockServer disconnected).

        status = TDIClnDisconnect(pConnFileObj,
                                  pDevExt->pTcpDevObj
                                 );

        if (
            !NT_SUCCESS(status)                       // A problem?
              &&
            STATUS_CONNECTION_INVALID!=status         // Problem is not invalid connection, eg, not due to other side disconnecting?
           )
          break;

        pLclConn->bConnd = FALSE;                     // Show no longer connected.

        // Wait on disconnection to complete.

        KeWaitForSingleObject(&pLclConn->DiscEvent, Executive, KernelMode, FALSE, 0);
       }

     for (                                            // Wait on the data to arrive.
          i = 0,
            ulDataRcvd = 0;
          i < nbrWaits;
          i ++
         )
       {
        status = KeWaitForSingleObject(&pReqElem[i].RecvEvent, Executive, KernelMode, FALSE, 0);

        if (0==i)                                     // First TSDU?
          {
           ulDataSent = *(PULONG)pReqElem[0].pBuffer; // Get total data length the remote party said it sent.
           pReqElem[0].pBuffer += sizeof(ULONG);      // Advance pointer past total data length field.
           pReqElem[0].ReqIoStatus.Information -=     // Reduce length.
             sizeof(ULONG);
          }

        ulDataRcvd += pReqElem[i].ulBytesReceived;    // Get running total of bytes received.

        if (ulDataRcvd==ulDataSent)                   // All data received?
          {
           nbrWaits = i + 1;                          // Adjust index.
           break;                                     // Leave 'for' loop.
          }
       }                                              // End 'for' wait on data arrival.

     *pUlKernelReceived = ulDataRcvd;                 // Set total receive length.

     // Display the received data.

     for (i = 0; i < nbrWaits; i ++)                  
       {
        // Note:  If other side disconnected prematurely (ie, TDIClnDisconnect got STATUS_CONNECTION_INVALID),
        //        ReqIoStatus.Status will probably = STATUS_CONNECTION_RESET, and ReqIoStatus.Information = 0).

        if (                                                     
            STATUS_SUCCESS!=                          // Some error?
              pReqElem[i].ReqIoStatus.Status     
              ||
            0==pReqElem[i].ReqIoStatus.Information    // No data?
           )
          {
           DbgPrint((JADrvNm " " JADrvRtnsName ".TDIClnPerformReceives:  i = %d, ReqIoStatus.Status = 0x%08x, "
                     "ReqIoStatus.Information = 0x%08x\n",
                     i, pReqElem[i].ReqIoStatus.Status, pReqElem[i].ReqIoStatus.Information));
           continue;                                  // Skip to bottom of the current for-loop.
          }

        #define ServerMsgArraySz 10

        // It is assumed -- but not checked -- that in each Receive there is at least 1 string and
        // that the total number of strings sent across receives does not exceed ServerMsgArraySz.

        char       * pSvrMsg[ServerMsgArraySz];
        int          msgCt = 0;
        BOOLEAN      bFindNextStr = TRUE;

        // Find strings (there may be more than one in the received data, since sent data may have been aggregated).

        for (ULONG charIdx = 0; charIdx < pReqElem[i].ReqIoStatus.Information; charIdx ++)                                                                                                                                                                     
          {
           if (TRUE==bFindNextStr)                    // Looking for a string?
             if (0!=pReqElem[i].pBuffer[charIdx])     // Is current byte not 0?
               {
                msgCt++;                              // Bump string count.
                pSvrMsg[msgCt-1] =                    // Point to current string.
                  &pReqElem[i].pBuffer[charIdx];
                bFindNextStr = FALSE;                 // Remember now not looking for a string.
               }
             else
               ;
           else                                       // Handling a string.
             if (0==pReqElem[i].pBuffer[charIdx])     // Is current byte 0?
               bFindNextStr = TRUE;                   // Remember now looking for a string.
             else
               ;
          }

        // Display the string(s) received from the server.  (The first and last could be partial.)                                                                                                                                                          

        for (int msgIdx = 0; msgIdx < msgCt; msgIdx ++)
          {
           DbgPrint((JADrvNm " " JADrvRtnsName ".TDIClnPerformReceives:  For i = %d, received data = >%s<\n",
                     i, pSvrMsg[msgIdx]));
          }
       }                                              // End 'for' Display the received data.
    } while(0);                                       // End 'do-while' single-iteration loop.
  
 if (STATUS_SUCCESS!=status)
   {
    DbgPrint((JADrvNm " " JADrvRtnsName ".TDIClnPerformReceives:  Ending status = %lx\n", status));
   }
  
 return status;
}                                                     // End TDIClnPerformReceives().

/**************************************************************************************************/
/*                                                                                                */
/* Open transport address.                                                                        */
/*                                                                                                */
/**************************************************************************************************/
NTSTATUS
TDIClnOpenTransAddr(
                    PWSTR          pTransDevName,     // Transport device name.
                    PHANDLE        pHandle,           // Output handle address.
                    PFILE_OBJECT * ppAddrFileObj,     // Output address file object.
                    USHORT         Port               // Port to open.
                   )
{
 NTSTATUS                    status;
 UNICODE_STRING              TransDeviceName;
 OBJECT_ATTRIBUTES           Attr;
 IO_STATUS_BLOCK             IoStatus;

 RtlInitUnicodeString(&TransDeviceName,               // Build Unicode transport device name.
                      pTransDevName
                     );

 InitializeObjectAttributes(&Attr,                    // Attributes (to be initialized);
                            &TransDeviceName,
                            OBJ_CASE_INSENSITIVE
                              |
                            OBJ_KERNEL_HANDLE,        // Only in kernel mode but in any process.
                            0,
                            0
                           );

 char Buffer[sizeof(FILE_FULL_EA_INFORMATION) + TDI_TRANSPORT_ADDRESS_LENGTH + sizeof(TA_IP_ADDRESS)];

 PFILE_FULL_EA_INFORMATION pEa =                      // Point to Buffer.
                             PFILE_FULL_EA_INFORMATION(Buffer);

 pEa->NextEntryOffset = 0;
 pEa->Flags = 0;
 pEa->EaNameLength = TDI_TRANSPORT_ADDRESS_LENGTH;    // Length of TdiTransportAddress, namely of "TransportAddress" string less 1 (ie, without terminator).
 memcpy(pEa->EaName,                                  // Copy TdiTransportAddress, including terminator.
        TdiTransportAddress,
        pEa->EaNameLength + 1
       );
 pEa->EaValueLength = sizeof(TA_IP_ADDRESS);          // Length of structure.

 PTA_IP_ADDRESS pSin =                                // Point to Buffer just after what's been used (ie, after terminator).
                  PTA_IP_ADDRESS(pEa->EaName + pEa->EaNameLength + 1);
 pSin->TAAddressCount = 1;                                                                                                                                                                                                                                     
 pSin->Address[0].AddressLength = TDI_ADDRESS_LENGTH_IP;                                                                                                                                                                                                       
 pSin->Address[0].AddressType = TDI_ADDRESS_TYPE_IP;                                                                                                                                                                                                           
 pSin->Address[0].Address[0].sin_port = Port;                                                                                                                                                                                                                
 pSin->Address[0].Address[0].in_addr = 0;
 memset(pSin->Address[0].Address[0].sin_zero,         // Ensure remainder of structure is zeroes.
        0,
        sizeof(pSin->Address[0].Address[0].sin_zero)
       );

 status = ZwCreateFile(pHandle,                       // Actual open of transport address.
                       0,
                       &Attr,
                       &IoStatus,
                       0,
                       FILE_ATTRIBUTE_NORMAL,
                       0,
                       FILE_OPEN,
                       0,
                       pEa,
                       sizeof Buffer
                      );

 if (!NT_SUCCESS(status))
   {
    DbgPrint((JADrvNm " " JADrvRtnsName ".TDIClnOpenTransAddr:  Problem in ZwCreateFile().  status = 0x%08x\n", status));
    return status;
   }

 status = ObReferenceObjectByHandle(*pHandle,         // Get the object pointer for the address file object's handle.
                                    GENERIC_READ | GENERIC_WRITE,
                                    0,
                                    KernelMode,
                                    (PVOID *)ppAddrFileObj,
                                    NULL
                                   );

 if (!NT_SUCCESS(status))
   {
    DbgPrint((JADrvNm " " JADrvRtnsName ".TDIClnOpenTransAddr:  Problem in ObReferenceObjectByHandle().  status = 0x%08x\n", status));
   }

 return status;
}                                                     // End TDIClnOpenTransAddr().

/**************************************************************************************************/
/*                                                                                                */
/* Open connection endpoint.                                                                      */
/*                                                                                                */
/**************************************************************************************************/
NTSTATUS
TDIClnOpenConnEndPt(
                    pTDIClnConn         pLclConn,     // Address of connection-endpoint structure.
                    pTDIClientExtension pDevExt       // Device extension.
                   )
{
 NTSTATUS                    status;
 UNICODE_STRING              TransDeviceName;
 OBJECT_ATTRIBUTES           Attr;
 IO_STATUS_BLOCK             IoStatus;

 RtlInitUnicodeString(&TransDeviceName,               // Build Unicode transport device name.
                      wcharTcpDevName                 // '\Device\Tcp'.
                     );

 InitializeObjectAttributes(
                            &Attr,                    // Attributes (to be initialized);
                            &TransDeviceName,
                            OBJ_CASE_INSENSITIVE
                              |
                            OBJ_KERNEL_HANDLE,        // Only in kernel mode but in any process.
                            0,
                            0
                           );

 ULONG ulBuffer =                                     // Per Catlin, microsoft.public.development.device.drivers,
                                                      // "question on TDI client, please do help," 2002-10-18.
         FIELD_OFFSET(FILE_FULL_EA_INFORMATION, EaName) +
         TDI_CONNECTION_CONTEXT_LENGTH + 1              +
         sizeof(CONNECTION_CONTEXT);

 PFILE_FULL_EA_INFORMATION pEa; 

 pEa = (PFILE_FULL_EA_INFORMATION)ExAllocatePool(NonPagedPool, ulBuffer);

 if (NULL==pEa)
   {
    DbgPrint((JADrvNm " " JADrvRtnsName "TDIClnOpenConnEndPt:  Couldn't get buffer\n"));
    status = STATUS_INSUFFICIENT_RESOURCES;
    return status;
   }

 memset(pEa, 0, ulBuffer);                            // Ensure zeroed.

 pEa->NextEntryOffset = 0;
 pEa->Flags = 0;
 pEa->EaNameLength = TDI_CONNECTION_CONTEXT_LENGTH;   // Length of TdiConnectionContext, namely of "ConnectionContext" string less 1
                                                      //   (ie, without terminator).
 memcpy(pEa->EaName,                                  // Copy TdiConnectionContext, including terminator.
        TdiConnectionContext,
        pEa->EaNameLength + 1
       );

 // The "connection context" is significant, at least in the case of an Accept Irp returned by a connect event handler, 
 // because the handler specifies, in addition to an Irp, a connection-context value that the transport will use to find 
 // the intended connection endpoint against which the Irp is to be executed.  This point is not clear in the DDK and is 
 // only somewhat vaguely stated in newsgroups, eg,
 //
 //   Thomas F Divine, "Handling accept requests in TDI client," microsoft.public.win32.programmer.kernel, 2000/06/19,                                                                                                                                       
 //
 //   Keith Moore, "TDI client doubts," comp.os.ms-windows.programmer.nt.kernel-mode, 1999/12/23,                                                                                                                                           
 //                                                                                                                                           
 // but getting it correct is crucial to success in such a connection event.  (If the wrong context value is supplied,                                                                                                                                         
 // STATUS_CONNECTION_INVALID is a likely result.)
 //                                                                                                                                           
 // The connection context will also be that presented in any Receive event handler, unless a connection event handler                                                                                                                                         
 // has supplied a context, in which latter case the supplied context will be presented to the Receive event handler.                                                                                                                                          

 pEa->EaValueLength = sizeof(CONNECTION_CONTEXT);               // Set length of connection context.
 *(CONNECTION_CONTEXT*)(pEa->EaName+(pEa->EaNameLength + 1)) =  // Set "EaValue" (immediately after EaName) -- the connection context.
   (CONNECTION_CONTEXT)pLclConn;                                   

 status = ZwCreateFile(&pLclConn->hConn,              // Open TCP (\Device\Tcp) connection endpoint.
                       0,
                       &Attr,
                       &IoStatus,
                       0,
                       FILE_ATTRIBUTE_NORMAL,
                       0,
                       FILE_OPEN,
                       0,
                       pEa,
                       ulBuffer
                      );

 if (!NT_SUCCESS(status))
   {
    DbgPrint((JADrvNm " " JADrvRtnsName "TDIClnOpenConnEndPt:  Problem in ZwCreateFile().  status = 0x%08x\n", status));
    return status;
   }

 status = ObReferenceObjectByHandle(pLclConn->hConn,  // Get the object pointer for the file connection object's handle.
                                    GENERIC_READ | GENERIC_WRITE,
                                    0,
                                    KernelMode,
                                    (PVOID *)&pLclConn->pConnFileObj,
                                    NULL
                                   );

 if (!NT_SUCCESS(status))
   {
    DbgPrint((JADrvNm " " JADrvRtnsName ".TDIClnOpenConnEndPt:   Problem in ObReferenceObjectByHandle().  status = 0x%08x\n", status));
   }

 return status;
}                                                     // End TDIClnOpenConnEndPt().

/**************************************************************************************************/
/*                                                                                                */
/* Set up an event handler.                                                                       */
/*                                                                                                */
/* Note:  This routine is synchronous.                                                            */
/*                                                                                                */
/**************************************************************************************************/
NTSTATUS
TDIClnSetEventHandler(
                      PFILE_OBJECT   pAddrFileObj,    // Address file object.
                      PDEVICE_OBJECT pTcpDevObj,      // TDI driver's device object.
                      LONG           EventType,       // Type of event.
                      PVOID          pEventHandler,   // Event handler routine.
                      PVOID          pEventContext    // Context for event handler.
                     )
{
 NTSTATUS                    status;
 KEVENT                      Event;
 IO_STATUS_BLOCK             IoStatus;

 do {                                                 // Single-iteration loop, to make possible escape via break.
     KeInitializeEvent(&Event, NotificationEvent, FALSE);

     PIRP pIrp =                                      // Get an Irp for internal device ioctl.
       TdiBuildInternalDeviceControlIrp(TDI_SET_EVENT_HANDLER,
                                        pTcpDevObj,   // TDI driver's device object.
                                        pAddrFileObj, // Address file object.
                                        &Event,       // Event to be signalled when Irp completes.
                                        &IoStatus     // I/O status block.
                                       );

     if (NULL==pIrp)
       {
        status = STATUS_INSUFFICIENT_RESOURCES;
        break;
       }

     TdiBuildSetEventHandler(pIrp,
                             pTcpDevObj,
                             pAddrFileObj,
                             NULL,                    // I/O completion routine.
                             NULL,                    // Context for I/O completion routine.
                             EventType,
                             pEventHandler,           // Event handler routine.
                             pEventContext            // Context for event handler routine.
                            );

     status = IoCallDriver(pTcpDevObj, pIrp);

     if (STATUS_PENDING==status)                      // Have to wait on this Irp?
       KeWaitForSingleObject(&Event, Executive, KernelMode, FALSE, 0);

     if (
         (                                            // Problem from IoCallDriver()?
          STATUS_SUCCESS!=status
            &&
          STATUS_PENDING!=status
         )
          ||
         (                                            // Problem discovered in completion?
          STATUS_PENDING==status
            &&
          0!=IoStatus.Status
         )
        )
       {
        // Note:  If problem was in IoCallDriver(), IoStatus.Status probably won't be meaningful.

        DbgPrint((JADrvNm " " JADrvRtnsName ".TDIClnSetEventHandler:  Problem in IoCallDriver().  status = 0x%08x, IoStatus.Status = 0x%08x\n",
                 STATUS_PENDING==status ? 0 : status , IoStatus.Status));
       }
    } while(0);                                       // End 'do-while' single-iteration loop.

 status = ((STATUS_SUCCESS==status) || (STATUS_PENDING==status)) ? IoStatus.Status : status;

 return status;
}                                                     // End TDIClnSetEventHandler().

/**************************************************************************************************/
/*                                                                                                */
/* Associate local transport address and connection endpoint.                                     */
/*                                                                                                */
/* Note:  This routine is synchronous.                                                            */
/*                                                                                                */
/**************************************************************************************************/
NTSTATUS
TDIClnAssocAddr(
                PFILE_OBJECT   pConnFileObj,          // Connection (endpoint) file object.
                PDEVICE_OBJECT pTcpDevObj,            // TDI driver's device object.
                HANDLE         hAddr                  // Handle to file object representing local-node address.
               )
{
 NTSTATUS                    status;
 KEVENT                      Event;
 IO_STATUS_BLOCK             IoStatus;

 do {                                                 // Single-iteration loop, to make possible escape via break.
     KeInitializeEvent(&Event, NotificationEvent, FALSE);

     PIRP pIrp =                                      // Get an Irp for internal device ioctl.
       TdiBuildInternalDeviceControlIrp(TDI_ASSOCIATE_ADDRESS,
                                        pTcpDevObj,   // TDI driver's device object.
                                        pConnFileObj, // Connection (endpoint) file object.
                                        &Event,       // Event to be signalled when Irp completes.
                                        &IoStatus     // I/O status block.
                                       );

     if (NULL==pIrp) 
       {
        status = STATUS_INSUFFICIENT_RESOURCES;
        break;
       }

     TdiBuildAssociateAddress(pIrp,
                              pTcpDevObj,
                              pConnFileObj,           // I/O completion routine.
                              NULL,                   // Context for I/O completion routine.
                              NULL,
                              hAddr
                             );

     status = IoCallDriver(pTcpDevObj, pIrp);

     if (STATUS_PENDING==status)                      // Have to wait on this Irp?
       KeWaitForSingleObject(&Event, Executive, KernelMode, FALSE, 0);

     if (
         (                                            // Problem from IoCallDriver()?
          STATUS_SUCCESS!=status
            &&
          STATUS_PENDING!=status
         )
          ||
         (                                            // Problem discovered in completion?
          STATUS_PENDING==status
            &&
          0!=IoStatus.Status
         )
        )
       {
        // Note:  If problem was in IoCallDriver(), IoStatus.Status probably won't be meaningful.

        DbgPrint((JADrvNm " " JADrvRtnsName ".TDIClnAssocAddr:  Problem in IoCallDriver().  status = 0x%08x, IoStatus.Status = 0x%08x\n",
                 STATUS_PENDING==status ? 0 : status , IoStatus.Status));
       }
    } while(0);                                       // End 'do-while' single-iteration loop.

 status = ((STATUS_SUCCESS==status) || (STATUS_PENDING==status)) ? IoStatus.Status : status;

 return status;
}                                                     // End TDIClnAssocAddr().

/**************************************************************************************************/
/*                                                                                                */
/* Disassociate local transport address from connection endpoint.                                 */
/*                                                                                                */
/* Note:  This routine is synchronous.                                                            */
/*                                                                                                */
/**************************************************************************************************/
NTSTATUS
TDIClnDisassocAddr(
                   PFILE_OBJECT   pConnFileObj,       // Connection (endpoint) file object.
                   PDEVICE_OBJECT pTcpDevObj          // TDI driver's device object.
                  )
{
 NTSTATUS                    status;
 KEVENT                      Event;
 IO_STATUS_BLOCK             IoStatus;

 do {                                                 // Single-iteration loop, to make possible escape via break.
     KeInitializeEvent(&Event, NotificationEvent, FALSE);

     PIRP pIrp =                                      // Get an Irp for internal device ioctl.
       TdiBuildInternalDeviceControlIrp(TDI_DISASSOCIATE_ADDRESS,
                                        pTcpDevObj,   // TDI driver's device object.
                                        pConnFileObj, // Connection (endpoint) file object.
                                        &Event,       // Event to be signalled when Irp completes.
                                        &IoStatus     // I/O status block.
                                       );

     if (NULL==pIrp) 
       {
        status = STATUS_INSUFFICIENT_RESOURCES;
        break;
       }

     TdiBuildDisassociateAddress(pIrp,
                                 pTcpDevObj,
                                 pConnFileObj,
                                 NULL,                // I/O completion routine.
                                 NULL                 // Context for I/O completion routine.
                                );

     status = IoCallDriver(pTcpDevObj, pIrp);

     if (STATUS_PENDING==status)                      // Have to wait on this Irp?
       KeWaitForSingleObject(&Event, Executive, KernelMode, FALSE, 0);

     if (
         (                                            // Problem from IoCallDriver()?
          STATUS_SUCCESS!=status
            &&
          STATUS_PENDING!=status
         )
          ||
         (                                            // Problem discovered in completion?
          STATUS_PENDING==status
            &&
          0!=IoStatus.Status
         )
        )
       {
        // Note: If problem was in IoCallDriver(), IoStatus.Status probably won't be meaningful.

        DbgPrint((JADrvNm " " JADrvRtnsName ".TDIClnDisassocAddr:  Problem in IoCallDriver().  status = 0x%08x, IoStatus.Status = 0x%08x\n",
                 STATUS_PENDING==status ? 0 : status , IoStatus.Status));
       }
    } while(0);                                       // End 'do-while' single-iteration loop.

 status = ((STATUS_SUCCESS==status) || (STATUS_PENDING==status)) ? IoStatus.Status : status;

 return status;
}                                                     // End TDIClnDisassocAddr().

/**************************************************************************************************/
/*                                                                                                */
/* Effect connection by initiating offer.                                                         */
/*                                                                                                */
/* Note:  This routine is synchronous.                                                            */
/*                                                                                                */
/**************************************************************************************************/
NTSTATUS
TDIClnConnect(
              PFILE_OBJECT   pConnFileObj,            // Connection (endpoint) file object.
              PDEVICE_OBJECT pTcpDevObj,              // TDI driver's device object.
              ULONG          RmtAddr,                 // Remote IP address.
              USHORT         RmtPort                  // Remote port.
             )
{
 NTSTATUS                    status;
 KEVENT                      Event;
 IO_STATUS_BLOCK             IoStatus;

// DbgPrint((JADrvNm " " JADrvRtnsName ".TDIClnConnect():  pConnFileObj = 0x%08x, RmtAddr = 0x%08x, RmtPort = 0x%04x\n",
//          pConnFileObj,
//          GetNetwkAddrDw(RmtAddr),                    // Swap bytes for display.
//          GetNetwkPort(RmtPort)                       // "
//         ));

 do {                                                 // Single-iteration loop, to make possible escape via break.
     KeInitializeEvent(&Event, NotificationEvent, FALSE);

     PIRP pIrp =                                      // Get an Irp for internal device ioctl.
       TdiBuildInternalDeviceControlIrp(TDI_CONNECT,  // Type of Irp.
                                        pTcpDevObj,   // TDI driver's device object.
                                        pConnFileObj, // Connection (endpoint) file object.
                                        &Event,       // Event to be signalled when Irp completes.
                                        &IoStatus     // I/O status block.
                                       );

     if (NULL==pIrp) 
       {
        status = STATUS_INSUFFICIENT_RESOURCES;
        break;
       }

     TA_IP_ADDRESS RmtIPAddr = {1,
                                {TDI_ADDRESS_LENGTH_IP,
                                 TDI_ADDRESS_TYPE_IP,
                                 {RmtPort, RmtAddr}
                                }
                               };

     TDI_CONNECTION_INFORMATION RmtNode = {0, 0, 0, 0, sizeof(RmtIPAddr), &RmtIPAddr};

     TdiBuildConnect(pIrp,
                     pTcpDevObj,                      // TDI driver's device object.
                     pConnFileObj,                    // Connection (endpoint) file object.
                     NULL,                            // I/O completion routine.
                     NULL,                            // Context for I/O completion routine.
                     NULL,                            // Address of timeout interval.
                     &RmtNode,                        // Remote-node client address.
                     0                                // (Output) remote-node address.
                    );

     status = IoCallDriver(pTcpDevObj, pIrp);

     if (STATUS_PENDING==status)                      // Have to wait on this Irp?
       KeWaitForSingleObject(&Event, Executive, KernelMode, FALSE, 0);

     if (
         (                                            // Problem from IoCallDriver()?
          STATUS_SUCCESS!=status
            &&
          STATUS_PENDING!=status
         )
          ||
         (                                            // Problem discovered in completion?
          STATUS_PENDING==status
            &&
          0!=IoStatus.Status
         )
        )
       {
        // Note:  If problem was in IoCallDriver(), IoStatus.Status probably won't be meaningful.

        DbgPrint((JADrvNm " " JADrvRtnsName ".TDIClnConnect:  Problem in IoCallDriver().  status = 0x%08x, IoStatus.Status = 0x%08x\n",
                 STATUS_PENDING==status ? 0 : status , IoStatus.Status));
       }
    } while(0);                                       // End 'do-while' single-iteration loop.

 status = ((STATUS_SUCCESS==status) || (STATUS_PENDING==status)) ? IoStatus.Status : status;

 return status;
}                                                     // End TDIClnConnect().

/**************************************************************************************************/
/*                                                                                                */
/* Initiate disconnection.                                                                        */
/*                                                                                                */
/* Notes:                                                                                         */
/*        1) After this completes, this client can no longer send but can receive.  Receives      */
/*           can continue until remote client does its own disconnect.                            */
/*                                                                                                */
/*        2) This routine is synchronous (but see comment about TDI_DISCONNECT_RELEASE).          */ 
/*                                                                                                */
/**************************************************************************************************/
NTSTATUS
TDIClnDisconnect(
                 PFILE_OBJECT   pConnFileObj,         // Connection (endpoint) file object.
                 PDEVICE_OBJECT pTcpDevObj            // TDI driver's device object.
                )
{
 NTSTATUS                    status;
 KEVENT                      Event;
 IO_STATUS_BLOCK             IoStatus;

 do {                                                 // Single-iteration loop, to make possible escape via break.
     KeInitializeEvent(&Event, NotificationEvent, FALSE);

     PIRP pIrp =                                      // Get an Irp for internal device ioctl.
       TdiBuildInternalDeviceControlIrp(TDI_DISCONNECT,
                                        pTcpDevObj,   // TDI driver's device object.
                                        pConnFileObj, // Connection (endpoint) file object.
                                        &Event,       // Event to be signalled when Irp completes.
                                        &IoStatus
                                       );

     if (NULL==pIrp) 
       {
        status = STATUS_INSUFFICIENT_RESOURCES;
        break;
       }

     TdiBuildDisconnect(pIrp,
                        pTcpDevObj,                   // TDI driver's device object.
                        pConnFileObj,                 // Connection (endpoint) file object.
                        NULL,                         // I/O completion routine.
                        NULL,                         // Context for I/O completion routine.
                        0,                            // Timeout interval.
                        TDI_DISCONNECT_RELEASE,       // "Controlled" disconnection; eg, data that have arrived at local
                                                          // transport but haven't been yet received by client can be received.
                        0,
                        0
                       );

     status = IoCallDriver(pTcpDevObj, pIrp);

     if (STATUS_PENDING==status)                      // Have to wait on this Irp?
       KeWaitForSingleObject(&Event, Executive, KernelMode, FALSE, 0);

     if (
         (                                            // Problem from IoCallDriver()?
          STATUS_SUCCESS!=status
            &&
          STATUS_PENDING!=status
         )
          ||
         (                                            // Problem discovered in completion?
          STATUS_PENDING==status
            &&
          0!=IoStatus.Status
         )
        )
       {
        // Note:  If problem was in IoCallDriver(), IoStatus.Status probably won't be meaningful.

        DbgPrint((JADrvNm " " JADrvRtnsName ".TDIClnDisconnect:  Problem in IoCallDriver().  status = 0x%08x, IoStatus.Status = 0x%08x\n",
                 STATUS_PENDING==status ? 0 : status , IoStatus.Status));
       }
    } while(0);                                       // End 'do-while' single-iteration loop.

 status = ((STATUS_SUCCESS==status) || (STATUS_PENDING==status)) ? IoStatus.Status : status;

 return status;
}                                                     // End TDIClnDisconnect().

/**************************************************************************************************/
/*                                                                                                */
/* Build and send down an Irp for Send.                                                           */
/*                                                                                                */
/* Notes:                                                                                         */
/*        1) This routine is synchronous.                                                         */
/*                                                                                                */
/*        2) There are indications that an MDL and probe-and-lock are needed even if the buffer   */
/*           is from the non-paged pool.  Eg, microsoft.public.win32.programmer.kernel,           */
/*           "MmProbeAndLockPages bug checks," dave porter, 2001-03-02.  But see the further      */
/*           discussion in comp.os.ms-windows.programmer.nt.kernel-mode, "Free MDL in completion  */
/*           routine," 1999/05/09.                                                                */
/*                                                                                                */
/*        3) Although not documented, it appears that the Irp, the Mdl and the locking are undone */
/*           by the transport.  There are claims to that effect in several places in newsgroups,  */
/*           and freeing the MDL always caused errors in a test (eg, bad pool caller or touching  */
/*           paged storage at wrong IRQL).  Further, testing showed that IoFreeMdl() was being    */
/*           called by somebody (presumably, the transport) for a given MDL.                      */
/*                                                                                                */
/**************************************************************************************************/
NTSTATUS
TDIClnSend(
           PFILE_OBJECT   pConnFileObj,               // Connection (endpoint) file object.
           PDEVICE_OBJECT pTcpDevObj,                 // TDI driver's device object.
           PVOID          pSendBfr,                   // Send buffer address.
           ULONG          Length
          )
{
 NTSTATUS                    status;
 KEVENT                      SendEvent;               // Used to await completion of Send Irp.
 IO_STATUS_BLOCK             IoStatus;
 EXCEPTION_POINTERS        * pExceptionInfo;       
 ULONG                       lclExceptionCode;     
 PVOID                       lclExceptionAddr;     

// DbgPrint((JADrvNm " " JADrvRtnsName ".TDIClnSend:  Entered\n"));                                                                                               

 do {                                                 // Single-iteration loop, to make possible escape via break.
     KeInitializeEvent(&SendEvent, NotificationEvent, FALSE);

     PIRP pIrp =                                      // Get an Irp for internal device ioctl.
       TdiBuildInternalDeviceControlIrp(TDI_SEND,     // Type of Irp.
                                        pTcpDevObj,   // TDI driver's device object.
                                        pConnFileObj, // Connection (endpoint) file object.
                                        &SendEvent,   // Event to be signalled when Irp completes.
                                        &IoStatus
                                       );

     if (NULL==pIrp) 
       {
        status = STATUS_INSUFFICIENT_RESOURCES;
        break;
       }

     PMDL pMdl = IoAllocateMdl(pSendBfr, Length, FALSE, FALSE, pIrp);

     if (NULL==pMdl) 
       {
        status = STATUS_INSUFFICIENT_RESOURCES;
        break;
       }

     _try
       {
        MmProbeAndLockPages(pMdl,                     // (Try to) fix buffer.
                            KernelMode,
                            IoModifyAccess
                           );
       }
        _except(
                pExceptionInfo = GetExceptionInformation(),                                                                                                                                                                                                    
                lclExceptionCode = pExceptionInfo->ExceptionRecord->ExceptionCode,                                                                                                                                                                             
                lclExceptionAddr = pExceptionInfo->ExceptionRecord->ExceptionAddress,                                                                                                                                                                          
                EXCEPTION_EXECUTE_HANDLER                                                                                                                                                                                                                      
               )                                                                                                                                                                                                                                               
          {                                                                                                                                                                                                                                                    
           DbgPrint((JADrvNm " " JADrvRtnsName ".TDIClnSend:  MmProbeAndLockPages() failed.  Error = 0x%08x at 0x%08x\n", lclExceptionCode, lclExceptionAddr));
           status = lclExceptionCode;                                                                                                                                                                                                                          
           goto done;
          }                                                                                                                                                                                                                                                    

     TdiBuildSend(pIrp,
                  pTcpDevObj,                         // TDI driver's device object.
                  pConnFileObj,                       // Connection (endpoint) file object.
                  NULL,                               // I/O completion routine.
                  NULL,                               // Context for I/O completion routine.
                  pMdl,                               // MDL address.
                  0,                                  // Flags.  0 => send as normal TSDU.
                  Length                              // Length of buffer mapped by MDL.
                 );

     status = IoCallDriver(pTcpDevObj, pIrp);

     if (STATUS_PENDING==status)                      // Have to wait on this Irp?
       KeWaitForSingleObject(&SendEvent, Executive, KernelMode, FALSE, 0);

     if (
         (                                            // Problem from IoCallDriver()?
          STATUS_SUCCESS!=status
            &&
          STATUS_PENDING!=status
         )
          ||
         (                                            // Problem discovered in completion?
          STATUS_PENDING==status
            &&
          0!=IoStatus.Status
         )
        )
       {
        // Note:  If problem was in IoCallDriver(), IoStatus.Status probably won't be meaningful.

        DbgPrint((JADrvNm " " JADrvRtnsName ".TDIClnSend:  Problem in IoCallDriver().  status = 0x%08x, IoStatus.Status = 0x%08x\n",
                 STATUS_PENDING==status ? 0 : status , IoStatus.Status));
       }
    } while(0);                                       // End 'do-while' single-iteration loop.

 status = ((STATUS_SUCCESS==status) || (STATUS_PENDING==status)) ? IoStatus.Status : status;

done:
 return status;
}                                                     // End TDIClnSend().

/**************************************************************************************************/
/*                                                                                                */
/* Build and send down an Irp for Receive.                                                        */
/*                                                                                                */
/* Notes:                                                                                         */
/*        1) This routine is NOT synchronous (no particular reason it's not, other than to show   */
/*           off asynchronous operation of an Irp).                                               */
/*                                                                                                */
/*        2) There are indications that an MDL and probe-and-lock are needed even if the buffer   */
/*           is from the non-paged pool.  Eg, microsoft.public.win32.programmer.kernel,           */
/*           "MmProbeAndLockPages bug checks," dave porter, 2001-03-02.  But see the further      */
/*           discussion in comp.os.ms-windows.programmer.nt.kernel-mode, "Free MDL in completion  */
/*           routine," 1999/05/09.                                                                */
/*                                                                                                */
/*        3) Although not documented, it appears that the Irp, the Mdl and the locking are undone */
/*           by the transport.  There are claims to that effect in several places in newsgroups,  */
/*           and freeing the MDL always caused errors in a test (eg, bad pool caller or touching  */
/*           paged storage at wrong IRQL).  Further, testing showed that IoFreeMdl() was being    */
/*           called by somebody (presumably, the transport) for a given MDL.                      */
/*                                                                                                */
/*        4) The supplied context (pCtx) is an event, which the I/O completion routine for the    */
/*           Receive Irp will signal.                                                             */
/*                                                                                                */
/**************************************************************************************************/
NTSTATUS
TDIClnRecv(
           PFILE_OBJECT     pConnFileObj,             // Connection (endpoint) file object.
           PDEVICE_OBJECT   pTcpDevObj,               // TDI driver's device object.
           PVOID            pRecvBfr,                 // Receive buffer address.
           ULONG            Length,                   // Length of Receive buffer.
           PIO_STATUS_BLOCK pIoStatus,                // I/O status block.
           PVOID            pCtx                      // I/O completion routine's context.
          )
{
 NTSTATUS                    status;
 EXCEPTION_POINTERS        * pExceptionInfo;       
 ULONG                       lclExceptionCode;     
 PVOID                       lclExceptionAddr;     

// DbgPrint((JADrvNm " " JADrvRtnsName ".TDIClnRecv:  Entered\n"));                                                                                               

 do {                                                 // Single-iteration loop, to make possible escape via break.
     PIRP pIrp =                                      // Get an Irp for internal device ioctl.
       TdiBuildInternalDeviceControlIrp(TDI_RECEIVE,  // Type of Irp.
                                        pTcpDevObj,   // TDI driver's device object.
                                        pConnFileObj, // Connection (endpoint) file object.
                                        NULL,         // Event to be signalled when Irp completes.
                                        pIoStatus     // I/O status block.
                                       );

     if (NULL==pIrp) 
       {
        status = STATUS_INSUFFICIENT_RESOURCES;
        break;
       }

     PMDL pMdl = IoAllocateMdl(pRecvBfr, Length, FALSE, FALSE, pIrp);

     if (NULL==pMdl) 
       {
        status = STATUS_INSUFFICIENT_RESOURCES;
        break;
       }

     _try
       {
        MmProbeAndLockPages(pMdl,                     // (Try to) fix buffer.
                            KernelMode,
                            IoModifyAccess
                           );
       }
        _except(
                pExceptionInfo = GetExceptionInformation(),                                                                                                                                                                                                    
                lclExceptionCode = pExceptionInfo->ExceptionRecord->ExceptionCode,                                                                                                                                                                             
                lclExceptionAddr = pExceptionInfo->ExceptionRecord->ExceptionAddress,                                                                                                                                                                          
                EXCEPTION_EXECUTE_HANDLER                                                                                                                                                                                                                      
               )                                                                                                                                                                                                                                               
          {                                                                                                                                                                                                                                                    
           DbgPrint((JADrvNm " " JADrvRtnsName ".TDIClnRecv:  MmProbeAndLockPages() failed.  Error = 0x%08x at 0x%08x\n",
                     lclExceptionCode, lclExceptionAddr));
           status = lclExceptionCode;                                                                                                                                                                                                                          
           goto done;
          }                                                                                                                                                                                                                                                    

     TdiBuildReceive(pIrp,
                     pTcpDevObj,                      // TDI driver's device object.
                     pConnFileObj,                    // Connection (endpoint) file object.
                     TDIClnIoCompRtnRecv,             // I/O completion routine.
                     (PVOID)pCtx,                     // Context (an event) for completion routine.
                     pMdl,                            // MDL address.
                     TDI_RECEIVE_NORMAL,              // Flags.
                     Length                           // Length of Receive buffer.
                    );

     status = IoCallDriver(pTcpDevObj, pIrp);

     if (
         STATUS_SUCCESS!=status
           &&
         STATUS_PENDING!=status
        )
       {
//      DbgPrint((JADrvNm " " JADrvRtnsName ".TDIClnRecv: Problem in IoCallDriver(). status = 0x%08x\n",
//               status));
       }
    } while(0);                                       // End 'do-while' single-iteration loop.

done:
 return status;
}                                                     // End TDIClnRecv().

/**************************************************************************************************/
/*                                                                                                */
/* Notes:                                                                                         */
/*        1) This routine is synchronous.                                                         */
/*                                                                                                */
/**************************************************************************************************/
NTSTATUS
TDIClnSendDGram(
                PFILE_OBJECT          pAddrFileObj,   // Transport address file object.
                PDEVICE_OBJECT        pUdpDevObj,     // TDI driver's device object.
                PTDI_CONNECTION_INFORMATION
                                      pConnInfo,
                PVOID                 pSendBfr,       // Send buffer address.
                ULONG                 sendLn          // Length to send.
               )
{
 NTSTATUS                    status;
 IO_STATUS_BLOCK             IoStatus;

// DbgPrint((JADrvNm " " JADrvRtnsName ".TDIClnSendDGram:  Entered\n"));                                                                                               

 do {                                                 // Single-iteration loop, to make possible escape via break.
     KEVENT                  SendEvent;               // Used to await completion of Send Irp.
     EXCEPTION_POINTERS    * pExceptionInfo;
     ULONG                   lclExceptionCode;
     PVOID                   lclExceptionAddr;

     KeInitializeEvent(&SendEvent, NotificationEvent, FALSE);

     PIRP pIrp =                                           // Get an Irp for internal device ioctl.
       TdiBuildInternalDeviceControlIrp(TDI_SEND_DATAGRAM, // Type of Irp.
                                        pUdpDevObj,        // TDI driver's device object.
                                        pConnFileObj,      // Connection (endpoint) file object.
                                        &SendEvent,        // Event to be signalled when Irp completes.
                                        &IoStatus
                                       );

     if (NULL==pIrp) 
       {
        status = STATUS_INSUFFICIENT_RESOURCES;
        break;
       }

     PMDL pMdl = IoAllocateMdl(pSendBfr, sendLn, FALSE, FALSE, NULL);

     if (NULL==pMdl) 
       {
        status = STATUS_INSUFFICIENT_RESOURCES;
        break;
       }

     _try
       {
        MmProbeAndLockPages(                          // (Try to) fix buffer.
                            pMdl,
                            KernelMode,
                            IoModifyAccess
                           );
       }
        _except(
                pExceptionInfo = GetExceptionInformation(),                                                                                                                                                                                                    
                lclExceptionCode = pExceptionInfo->ExceptionRecord->ExceptionCode,                                                                                                                                                                             
                lclExceptionAddr = pExceptionInfo->ExceptionRecord->ExceptionAddress,                                                                                                                                                                          
                EXCEPTION_EXECUTE_HANDLER                                                                                                                                                                                                                      
               )                                                                                                                                                                                                                                               
          {                                                                                                                                                                                                                                                    
           DbgPrint((JADrvNm " " JADrvRtnsName ".TDIClnSendDGram:  MmProbeAndLockPages() failed.  Error = 0x%08x at 0x%08x\n", lclExceptionCode, lclExceptionAddr));
           status = lclExceptionCode;                                                                                                                                                                                                                          
           goto done;
          }                                                                                                                                                                                                                                                    

     TdiBuildSendDatagram(pIrp,
                          pUdpDevObj,                 // TDI driver's device object.
                          pAddrFileObj,               // Transport address file object.
                          NULL,                       // I/O completion routine.
                          NULL,                       // Context for I/O completion routine.
                          pMdl,                       // MDL address.
                          sendLn,                     // Length of buffer mapped by MDL.
                          pConnInfo                   // Connection information.
                         );

     status = IoCallDriver(pUdpDevObj, pIrp);

     if (STATUS_PENDING==status)                      // Have to wait on this Irp?
       KeWaitForSingleObject(&SendEvent, Executive, KernelMode, FALSE, 0);

     if (
         (                                            // Problem from IoCallDriver()?
          STATUS_SUCCESS!=status
            &&
          STATUS_PENDING!=status
         )
          ||
         (                                            // Problem discovered in completion?
          STATUS_PENDING==status
            &&
          0!=IoStatus.Status
         )
        )
       {
        // Note:  If problem was in IoCallDriver(), IoStatus.Status probably won't be meaningful.

        DbgPrint((JADrvNm " " JADrvRtnsName ".TDIClnSendDGram:  Problem in IoCallDriver().  status = 0x%08x, IoStatus.Status = 0x%08x\n",
                 STATUS_PENDING==status ? 0 : status , IoStatus.Status));
       }
    } while(0);                                       // End 'do-while' single-iteration loop.

 status = ((STATUS_SUCCESS==status) || (STATUS_PENDING==status)) ? IoStatus.Status : status;

done:
 return status;
}                                                     // End TDIClnSendDGram().

/**************************************************************************************************/
/*                                                                                                */
/* Notes:                                                                                         */
/*        1) This routine is synchronous.                                                         */
/*                                                                                                */
/**************************************************************************************************/
NTSTATUS
TDIClnRecvDGram(
                PFILE_OBJECT          pAddrFileObj,   // Transport address file object.
                PDEVICE_OBJECT        pUdpDevObj,     // TDI driver's device object.
                PTDI_CONNECTION_INFORMATION           // Information about intended remote party.
                                      pConnInfo,
                PVOID                 pRecvBfr,       // Receive buffer address.
                ULONG                 ulBfr,          // Length of Receive buffer.
                PIO_STATUS_BLOCK      pIoStatus       // I/O status block.
               )
{
 NTSTATUS                    status;
 KEVENT                      lclRecvEvent;            // testing.

 KeInitializeEvent(&lclRecvEvent, NotificationEvent, FALSE);  // testing.

// DbgPrint((JADrvNm " " JADrvRtnsName ".TDIClnRecvDGram:  Entered\n"));                                                                                               

 do {                                                 // Single-iteration loop, to make possible escape via break.
     EXCEPTION_POINTERS    * pExceptionInfo;       
     ULONG                   lclExceptionCode;     
     PVOID                   lclExceptionAddr;     

     PIRP pIrp =                                                // Get an Irp for internal device ioctl.
       TdiBuildInternalDeviceControlIrp(TDI_RECEIVE_DATAGRAM,   // Type of Irp.
                                        pUdpDevObj,             // TDI driver's device object.
                                        pAddrFileObj,           // Transport address file object.
                                        NULL,                   // Address of event to be signalled when Irp completes.
                                        pIoStatus               // I/O status block.
                                       );

     if (NULL==pIrp) 
       {
        status = STATUS_INSUFFICIENT_RESOURCES;
        break;
       }

     PMDL pMdl = IoAllocateMdl(pRecvBfr, ulBfr, FALSE, FALSE, NULL);

     if (NULL==pMdl) 
       {
        status = STATUS_INSUFFICIENT_RESOURCES;
        break;
       }

     _try
       {
        MmProbeAndLockPages(pMdl,                     // (Try to) fix buffer.
                            KernelMode,
                            IoModifyAccess
                           );
       }
        _except(
                pExceptionInfo = GetExceptionInformation(),                                                                                                                                                                                                    
                lclExceptionCode = pExceptionInfo->ExceptionRecord->ExceptionCode,                                                                                                                                                                             
                lclExceptionAddr = pExceptionInfo->ExceptionRecord->ExceptionAddress,                                                                                                                                                                          
                EXCEPTION_EXECUTE_HANDLER                                                                                                                                                                                                                      
               )                                                                                                                                                                                                                                               
          {                                                                                                                                                                                                                                                    
           DbgPrint((JADrvNm " " JADrvRtnsName ".TDIClnRecvDGram:  MmProbeAndLockPages() failed.  Error = 0x%08x at 0x%08x\n",
                     lclExceptionCode, lclExceptionAddr));
           status = lclExceptionCode;                                                                                                                                                                                                                          
           goto done;
          }                                                                                                                                                                                                                                                    

     TA_IP_ADDRESS RmtIPAddr = {1,
                                {TDI_ADDRESS_LENGTH_IP,
                                 TDI_ADDRESS_TYPE_IP,
                                 {0, 0}
                                }
                               };

     TDI_CONNECTION_INFORMATION RmtServerInfo =       // Will get information about remote partner.
       {0, 0, 0, 0, sizeof(RmtIPAddr), &RmtIPAddr};

     TdiBuildReceiveDatagram(pIrp,
                             pUdpDevObj,              // TDI driver's device object.
                             pAddrFileObj,            // Transport address file object.
                             TDIClnIoCompRtnRecvDGram,// I/O completion routine.
                             &lclRecvEvent,           // Context (an event) for completion routine.
                             pMdl,                    // MDL address.
                             ulBfr,                   // Buffer length to use.
                             pConnInfo,               // Information about acceptable remote partner.
                             &RmtServerInfo,          // Returned information about remote partner.
                             TDI_RECEIVE_NORMAL       // Flags.
                            );

     status = IoCallDriver(pUdpDevObj, pIrp);

     if (
         STATUS_SUCCESS!=status
           &&
         STATUS_PENDING!=status
        )
       {
        DbgPrint((JADrvNm " " JADrvRtnsName ".TDIClnRecvDGram:  Problem in IoCallDriver().  status = 0x%08x\n",
                 status));
       }
                                                                                                                              
     // Following cancel logic per Oney, "Programming the Microsoft Windows Driver Model," second edition, pp 282-283.

     if (STATUS_PENDING==status)                      // Underway?
       {
        LARGE_INTEGER TimeOut;
        TimeOut.QuadPart = -DNSTimeoutValue *         // Calculate timeout value (5 seconds from now).
                           10000000;

        // Wait until completion or timeout.

        NTSTATUS lclStatus =                          
          KeWaitForSingleObject(&lclRecvEvent, Executive, KernelMode, FALSE, &TimeOut);

        if (STATUS_TIMEOUT==lclStatus)                // Timeout?
          {
           IoCancelIrp(pIrp);                         // Cancel Irp.

           // Wait until completion, which should now be very quick.
         
           KeWaitForSingleObject(&lclRecvEvent, Executive, KernelMode, FALSE, 0);
          }
       }

     IoCompleteRequest(pIrp, IO_NO_INCREMENT);        // Complete the Irp, which the Receive Datagram I/O completion  routine suspended.

     DbgPrint((JADrvNm " " JADrvRtnsName ".TDIClnRecvDGram:  After wait.  status = 0x%08x, pIoStatus->Status = 0x%08x, pIoStatus->Information = 0x%08x\n",
              status, pIoStatus->Status, pIoStatus->Information));
    } while(0);                                       // End 'do-while' single-iteration loop.

done:
 status = ((STATUS_SUCCESS==status) || (STATUS_PENDING==status)) ? pIoStatus->Status : status;

 return status;
}                                                     // End TDIClnRecvDGram().

/**************************************************************************************************/
/*                                                                                                */
/* Event completion routine for connection.                                                       */
/*                                                                                                */
/* Notes:                                                                                         */
/*                                                                                                */
/**************************************************************************************************/
NTSTATUS
TDIClnEventConnect(
                   PVOID                pEventCtx,    // Event context.
                   LONG                 lnRmtAddr,    // Buffer length.
                   PVOID                pRmtClnTA,    // Buffer (transport address of remote client).
                   LONG                 lnUserData,   // Length of user data buffer.
                   PVOID                pUserData,    // User data buffer.
                   LONG                 lnOptions,    // Length of options.
                   PVOID                pOptions,     // Options buffer.
                   CONNECTION_CONTEXT * ppConnCtx,    // Output connection context.
                   PIRP               * ppIrp         // Output Irp address.
                  )
{
// DbgPrint((JADrvNm " " JADrvRtnsName ".TDIClnEventConnect\n"));

 pTDIClnConn            pLclConn =                    // Recast context pointer.
                          (pTDIClnConn)pEventCtx;
 pTDIClientExtension    pDevExt = pLclConn->pDevExt;  // Point to our device extension.
 PTDI_CONNECTION_INFORMATION                          // Point to client connection information.
                        pClientConn = pLclConn->pClientConnInfo;
 PTA_IP_ADDRESS         pClientConnInfo =             // Point to output area for connector information.
                          (PTA_IP_ADDRESS)pClientConn->RemoteAddress,
                        pTAAddrIp =                   // Get supplied remote connector information.
                          (PTA_IP_ADDRESS)pRmtClnTA;

 pClientConnInfo->Address[0].Address[0].in_addr =     // Fill in connector's IP address.
   pTAAddrIp->Address[0].Address[0].in_addr;
 pClientConnInfo->Address[0].Address[0].sin_port =    // Fill in connector's port.
   pTAAddrIp->Address[0].Address[0].sin_port;

 TdiBuildAccept(pDevExt->pIrpAccept,                  // Finish Irp for Accept.
                pDevExt->pTcpDevObj,
                pLclConn->pConnFileObj,
                TDIClnIoCompRtnAcc,                   // I/O completion routine.
                pDevExt,                              // Context for I/O completion routine.
                pClientConn,                          // Return connection information.
                NULL
               );

 IoSetNextIrpStackLocation(pDevExt->pIrpAccept);      // Set stack location correct for transport's use.

 *ppIrp = pDevExt->pIrpAccept;                        // Point to Irp to be used for Accept.   

 *ppConnCtx = (CONNECTION_CONTEXT)pLclConn;           // Set up context, used by transport to find connection endpoint.  This will
                                                      //   also be the connection context in any Receive event handler.

// DbgPrint((JADrvNm " " JADrvRtnsName ".TDIClnEventConnect:  Context = 0x%08x\n", pLclConn));

 return STATUS_MORE_PROCESSING_REQUIRED;
}                                                     // End TDIClnEventConnect().

/**************************************************************************************************/
/*                                                                                                */
/* Event completion routine for disconnection.  Runs when remote node in endpoint-to-endpoint     */
/* connection closes connection.                                                                  */
/*                                                                                                */
/* Flag definitions (from tdi.h):                                                                 */
/*                                                                                                */
/* #define TDI_DISCONNECT_WAIT           ((USHORT)0x0001) // used for disconnect                  */
/*                                                        //   notification                       */
/* #define TDI_DISCONNECT_ABORT          ((USHORT)0x0002) // immediately terminate                */
/*                                                        //   connection                         */
/* #define TDI_DISCONNECT_RELEASE        ((USHORT)0x0004) // initiate graceful                    */
/*                                                        //   disconnect                         */
/*                                                                                                */
/* Notes:                                                                                         */
/*        1) According to Max Shatskih (comp.os.ms-windows.programmer.nt.kernel-mode,             */
/*           "Help!!! How to close the transport address," 2001-07-21), the connection file       */
/*           object should not be closed until this event has occurred.                           */
/*                                                                                                */
/**************************************************************************************************/
NTSTATUS
TDIClnEventDisconnect(
                      PVOID              pEventCtx,   // Event context.
                      CONNECTION_CONTEXT pConnCtx,    // Connection context (that from ZwCreateFile on endpoint and from connection event).
                      LONG,                           // Disconnection event data length.
                      PVOID,                          // Disconnection event data.
                      LONG,
                      PVOID,
                      ULONG              Flags        
                     )
{
// DbgPrint((JADrvNm " " JADrvRtnsName ".TDIClnEventDisconnect:  Flags = 0x%08x\n", Flags));

 pTDIClnConn            pLclConn =                    // Recast context pointer.
                          (pTDIClnConn)pConnCtx;
 pTDIClientExtension    pDevExt = pLclConn->pDevExt;  // Point to our device extension.

 if (0!=(Flags&(0xffffffff-TDI_DISCONNECT_RELEASE)))  // Not graceful disconnect?
   {
    DbgPrint((JADrvNm " " JADrvRtnsName ".TDIClnEventDisconnect:  Not graceful disconnect, flags = 0x%08x\n", Flags));
   }

 KeSetEvent(&pLclConn->DiscEvent, 0, FALSE);          // Signal event.

 return STATUS_SUCCESS;
}                                                     // End TDIClnEventDisconnect().

/**************************************************************************************************/
/*                                                                                                */
/* Event completion routine for error.                                                            */
/*                                                                                                */
/**************************************************************************************************/
NTSTATUS
TDIClnEventErrorEx(
                   PVOID,                             // Context supplied in TdiBuildSetEventHandler to register completion routine.
                   NTSTATUS status,
                   PVOID                              // Buffer with information supplied by transport.
                  )
{
 DbgPrint((JADrvNm " " JADrvRtnsName ".TDIClnEventError:  Error = 0x%08x\n", status));

 return STATUS_SUCCESS;
}                                                     // End TDIClnEventErrorEx().

/**************************************************************************************************/
/*                                                                                                */
/* Event completion routine for Receive.                                                          */
/*                                                                                                */
/* Notes:                                                                                         */
/*         1) This routie is used only if UseRecvHandler is TRUE.                                 */
/*         2) This routine assumes all the received data are presented; that is, no account is    */
/*            taken for the possibility of more bytes available than present in TSDU.             */
/*                                                                                                */
/**************************************************************************************************/
NTSTATUS
TDIClnEventReceive(
                   PVOID                pEventCtx,    // Address of event context supplied in TdiBuildSetEventHandler().
                   CONNECTION_CONTEXT   pConnCtx,     // Connection context (that from ZwCreateFile on endpoint and from connection event).
                   ULONG                Flags,        // Flag values are mapped in tdi.h, eg, TDI_RECEIVE_NORMAL.
                   ULONG                Indicated,    // Number of bytes currently available in TSDU.
                   ULONG                Available,    // Total number of bytes available (if greater than currently available, requires another Irp).
                   PULONG               pBytesTaken,  // Output number of bytes taken (copied from TSDU).
                   PVOID                pTSDU,        // Pointer to TSDU.
                   PIRP               * ppIrp         // Output Irp address if more bytes available than indicated and they are to be subsequently received.
                  )
{
// DbgPrint((JADrvNm " " JADrvRtnsName ".TDIClnEventReceive:  Context = 0x%08x, Flags = 0x%08x, indicated = %ld, available = %ld\n",
//          pConnCtx, Flags, Indicated, Available));

 pTDIClnConn            pLclConn =                    // Recast connection context pointer.
                          (pTDIClnConn)pConnCtx;

 ULONG                  idx =                         // Get index of first available request element
                          pLclConn->IdxReqElemAvail;
 pLclConn->IdxReqElemAvail++;                         //   and bump index.

 memcpy(pLclConn->pReqElemsArr[idx].pBuffer,          // Copy bytes from TSDU to buffer.
        pTSDU,
        Available
       );

 pLclConn->pReqElemsArr[idx].ulBytesReceived =        // Show bytes received.
   Available;

 KeSetEvent(                                          // Signal event.
            PKEVENT(&pLclConn->pReqElemsArr[idx].RecvEvent), 0, FALSE       
           );       

 *pBytesTaken = Available;                            // Everything consumed.
 *ppIrp = NULL;                                       // Not returning an Irp pointer.

 return STATUS_SUCCESS;
}                                                     // End TDIClnEventReceive().

/**************************************************************************************************/
/*                                                                                                */
/* I/O completion routine for Receive Irp.                                                        */
/*                                                                                                */
/* Notes:                                                                                         */
/*        1) If other side disconnected prematurely (ie, TDIClnDisconnect got                     */
/*           STATUS_CONNECTION_INVALID), probably pIrp->IoStatus.Status will =                    */
/*           STATUS_CONNECTION_RESET and pIrp->IoStatus.Information = 0.                          */
/*                                                                                                */
/*        2) If the number of bytes received is 0 (pIrp->IoStatus.Information = 0), probably the  */
/*           other side disconnected; in that case, TDIClnEventDisconnect() should have shown     */
/*           flags = 0x00000004, namely, TDI_DISCONNECT_RELEASE.                                  */
/*                                                                                                */
/**************************************************************************************************/
NTSTATUS
TDIClnIoCompRtnRecv(
                    PDEVICE_OBJECT      pDevObj,      // TDI driver's device object.
                    PIRP                pIrp,         // Address of completed Irp.
                    PVOID               pCtx          // Pointer to context.
                   )
{
// DbgPrint((JADrvNm " " JADrvRtnsName ".TDIClnIoCompRtnRecv:  IoStatus.Status = 0x%08x, IoStatus.Information = 0x%08x\n",
//           pIrp->IoStatus.Status, pIrp->IoStatus.Information));

 pTDIClnReqElem pLclReqElem = (pTDIClnReqElem)pCtx;   // Recast connection context pointer.

 pLclReqElem->ulBytesReceived =                       // Remember number of bytes received.
   pIrp->IoStatus.Information;

 KeSetEvent(&pLclReqElem->RecvEvent, 0, FALSE);       // Signal event.

 return STATUS_SUCCESS;
}                                                     // End TDIClnIoCompRtnRecv().

/**************************************************************************************************/
/*                                                                                                */
/* I/O completion routine for Receive Datagram Irp.                                               */
/*                                                                                                */
/**************************************************************************************************/
NTSTATUS                                          
TDIClnIoCompRtnRecvDGram(
                         PDEVICE_OBJECT      pDevObj, // TDI driver's device object.
                         PIRP                pIrp,    // Address of completed Irp.
                         PVOID               pCtx     // Pointer to context.
                        )                              
{
 DbgPrint((JADrvNm " " JADrvRtnsName ".TDIClnIoCompRtnRecvDGram:  IoStatus.Status = 0x%08x, IoStatus.Information = 0x%08x\n",
           pIrp->IoStatus.Status, pIrp->IoStatus.Information));

 // Following logic per Oney, "Programming the Microsoft Windows Driver Model," second edition, pp 282-283.

 if (TRUE==pIrp->PendingReturned)                     // Is driver mainline waiting or going to wait (because of I/O pending)?
   KeSetEvent((PKEVENT)pCtx, IO_NO_INCREMENT, FALSE); // Signal driver.
 
 return STATUS_MORE_PROCESSING_REQUIRED;              // Cause Irp to be suspended.
}                                                     // End TDIClnIoCompRtnRecvDGram().

/**************************************************************************************************/
/*                                                                                                */
/* I/O completion routine for Accept Irp.                                                         */
/*                                                                                                */
/**************************************************************************************************/
NTSTATUS
TDIClnIoCompRtnAcc(
                   PDEVICE_OBJECT       pDevObj,      // TDI driver's device object.
                   PIRP                 pIrp,         // Address of completed Irp.
                   PVOID                pCtx          // Pointer to context.
                  )
{
// DbgPrint((JADrvNm " " JADrvRtnsName ".TDIClnIoCompRtnAcc\n"));

 pTDIClientExtension pDevExt =                        // Recast connection context pointer.
                       (pTDIClientExtension)pCtx;

 pDevExt->pIrpAccept = NULL;                          // Be neat (the Irp will be recycled by transport).

 if (STATUS_SUCCESS!= pIrp->IoStatus.Status)
   {
    DbgPrint((JADrvNm " " JADrvRtnsName ".TDIClnIoCompRtnAcc:  IoStatus.Status = 0x%08x, IoStatus.Information = 0x%08x\n",
              pIrp->IoStatus.Status, pIrp->IoStatus.Information));
   }

 return STATUS_SUCCESS;
}                                                     // End TDIClnIoCompRtnAcc().


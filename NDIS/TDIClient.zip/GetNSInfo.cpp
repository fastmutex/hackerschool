//****************************************************************************//
//*                                                                           //
//* Copyright (C) 2003, James Antognini, antognini@mindspring.com.            //
//*                                                                           //
//****************************************************************************//

/******************************************************************************/      
/*                                                                            */      
/* Notes:                                                                     */      
/*                                                                            */      
/******************************************************************************/      

#define JADrvRtnsName   "GetNSInfo"
#define JADrvRtnsVer    "1.00"                                                                  
                                                                                                
#ifdef __cplusplus  // C++ conversion.                                                          
extern "C"                                                                                      
{                                                                                               
#endif              // End #ifdef C++ conversion.                                               
                                                                                                
#include <ntddk.h>
#include <tdikrnl.h>
                                                                                                
#define JADriverKernelMode     1                      // Ensure kernel pieces available.        
#include "TDIClient.h"                                                                             
                                                                                                
#ifdef __cplusplus  // C++ conversion.                                                          
}                                                                                               
#endif              // End #ifdef C++ conversion.                                               

//****************************************************************************//
//*                                                                           //
//* Globals.                                                                  //
//*                                                                           //
//****************************************************************************//

#define CompDateTimeStr "dd mmm yyyy hh:mm:ss"

char GetNSInfoCompileInfo[sizeof(CompDateTimeStr)+1] =// Null in first character means not initialized.
       {0x0};

//****************************************************************************//
//*                                                                           //
//* Forward definitions of routines provided here.                            //
//*                                                                           //
//****************************************************************************//


/**************************************************************************************************/
/*                                                                                                */
/* Try to get DNS information from the NIC sections of the TCP/IP service in the registry.        */
/*                                                                                                */
/**************************************************************************************************/
NTSTATUS
GetNSInfo(pTDIClientExtension pDevExt)                // Device extension.
{
 NTSTATUS                    status = STATUS_SUCCESS;
 HANDLE                      hRegKey = INVALID_HANDLE_VALUE;                                                                                                                                                                                       
 PVOID                       pWk = NULL;                                                                           
 ULONG                       cumDNSIPAddrCt = 0;

 if (0==GetNSInfoCompileInfo[0])                      // Information string about compilation date and time not yet built?
   {
    char static DateCompiledBase[] = __DATE__,
                TimeCompiledBase[] = " "__TIME__;
    char        tmpDateCompileInfo[]   =              // Build date in preferred (dd mmm yyyy) format.
                  {DateCompiledBase[4], DateCompiledBase[5], DateCompiledBase[6],
                   DateCompiledBase[0], DateCompiledBase[1], DateCompiledBase[2], DateCompiledBase[3],
                   DateCompiledBase[7], DateCompiledBase[8], DateCompiledBase[9], DateCompiledBase[10],
                   0x0
                  };

    // Build date and time of compilation.

    if (' '==tmpDateCompileInfo[0])                   // Leading blank (ie, first through ninth day of month)?
      strcpy(GetNSInfoCompileInfo, tmpDateCompileInfo+1);
    else
      strcpy(GetNSInfoCompileInfo, tmpDateCompileInfo+0);
    strcat(GetNSInfoCompileInfo, TimeCompiledBase);
   }

 DbgPrint((JADrvNm " " JADrvRtnsName " v" JADrvRtnsVer " (compiled %s)\n",
           GetNSInfoCompileInfo));
 
 do {                                                 // Single-iteration loop, to make possible escape via break.
     ULONG                         i;                                                                                                                                                                                                                 
     ULONG                   const szDNSIPArray =     // Number of entries provided in DNS IP address array.
                                     arraysize(pDevExt->DNSIPAddr);
     WCHAR                   const constTcpipInfo[] =                                                                                                                                                                                             
                                     L"\\Registry\\Machine\\System\\CurrentControlSet\\Services\\Tcpip\\Parameters\\Interfaces",                                                                                                                               
                                   constNameServerValue[] = L"NameServer";                                                                                                                                                                          
     WCHAR                         RegKey[512];                                                                                                                                                                                                          
     OBJECT_ATTRIBUTES             KeyObj;                                                                                                                                                                                                               
     UNICODE_STRING                TcpIntf,                                                                                                                                                                                                           
                                   NameServerValue,
                                   WkUniStr;                                                                                                                                                                                                             
                                                                                                                                           
     RtlInitUnicodeString(&TcpIntf, constTcpipInfo);  // Build Unicode descriptor for registry key.
                                                                                                                                           
     InitializeObjectAttributes(&KeyObj,              // Create object for registry key.                                                                                                                                                   
                                &TcpIntf,                                                                                                                                                                                                  
                                OBJ_CASE_INSENSITIVE,                                                                                                                                                                                      
                                NULL,                                                                                                                                                                                                      
                                NULL                                                                                                                                                                                                       
                               );                                                                                                                                                                                                          
                                                                                                                                           
     status = ZwOpenKey(&hRegKey,                     // Open key.                                                                                                                                                                                      
                        KEY_ENUMERATE_SUB_KEYS,                                                                                                                                                                                                              
                        &KeyObj                                                                                                                                                                                                                         
                       );                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                          
     if (STATUS_SUCCESS!=status)                      // A problem?                                                                                                                                                                                     
       {                                                                                                                                                                                                                                                  
        DbgPrint((JADrvNm " " JADrvRtnsName ":  Failed to open registry, status = 0x%08x; quitting\n", status));
                                                                                                                                                                                                                                                          
        status = STATUS_UNSUCCESSFUL;                                                                                                                                                                                                                     
        break;                                                                                                                                                                                                                                            
       }                                                                                                                                                                                                                                                  
                                                                                                                                           
     #define lnOutKeyInfo   1024                                                                                                             
     #define lnSubKeyName   1024                                                                                                             
     #define lnKeyValueInfo 1024                                                                                                             
     #define lnSubKeyWork   1024                                                                                                             
                                                                                                                                           
     pWk =                                            // Get some working storage.
       ExAllocatePool(PagedPool, lnOutKeyInfo+lnSubKeyName+lnKeyValueInfo);
                                                                                                                                           
     if (NULL==pWk)                                                                                                                                           
       {                                                                                                                                           
        DbgPrint((JADrvNm " " JADrvRtnsName ":  Failed to get working storage, quitting\n"));
                                                                                                                                                                                                                                                          
        status = STATUS_INSUFFICIENT_RESOURCES;                                                                                                                                                                                                                
        break;                                                                                                                                                                                                                                            
       }                                                                                                                                           
                                                                                                                                           
     // Point to pieces of the working storage.

     PWCHAR pOutKeyInfo  = (PWCHAR)pWk,                                                                                                                                           
            pSubKeyName  = pOutKeyInfo+(lnOutKeyInfo/sizeof(WCHAR)),                                                                                                                                                         
            pSubKeyValue = pSubKeyName+(lnSubKeyName/sizeof(WCHAR));                                                                                                                                                         
     PCHAR  pSubKeyWork  = (PCHAR)pSubKeyValue+(lnKeyValueInfo/sizeof(WCHAR));                                                                                                                                                         

     BOOLEAN bQuitEnumLoop = FALSE;
                                                                                                                                           
     RtlInitUnicodeString(&NameServerValue, constNameServerValue);                                                                                                                                          
                                                                                                                                           
     for (i = 0; ; i ++)                              // Enumerate subkeys, corresponding to NICs.                                                                    
       {                                                                                                                                           
        ULONG             ulOutInfo;
        UNICODE_STRING    UniSubKey,
                          UniSubKeyValue;
        ANSI_STRING       AnsiSubKeyValue;
        OBJECT_ATTRIBUTES SubKeyObj;                                                                                                                                                                                                               
        HANDLE            hSubKey;                                                                                                                                                                                       

        status = ZwEnumerateKey(hRegKey,              // Get current subkey.
                                i,                    // Current index.
                                KeyBasicInformation,
                                pOutKeyInfo,
                                lnOutKeyInfo,
                                &ulOutInfo
                               );

        if (STATUS_NO_MORE_ENTRIES==status)           // Finished?
          break;

        PKEY_BASIC_INFORMATION pKeyInfo =             // Point to returned key information.
          (PKEY_BASIC_INFORMATION)pOutKeyInfo;

        //
        // Build subkey name, open subkey, get the data from the NameServer value under the subkey.
        //

        // Ensure a Unicode null terminator, for copying.

        *(PWCHAR)(((PCHAR)pKeyInfo->Name)+pKeyInfo->NameLength) = UNICODE_NULL;

        wcscpy(pSubKeyName, constTcpipInfo);
        wcscat(pSubKeyName, L"\\");
        wcscat(pSubKeyName, pKeyInfo->Name);

        RtlInitUnicodeString(&UniSubKey, pSubKeyName);// Build Unicode descriptor for subkey.

        InitializeObjectAttributes(&SubKeyObj,        // Create object for subkey.
                                   &UniSubKey,
                                   OBJ_CASE_INSENSITIVE,
                                   NULL,
                                   NULL
                                  );

        status = ZwOpenKey(&hSubKey,                  // Open subkey.
                           KEY_QUERY_VALUE,
                           &SubKeyObj
                          );

        if (STATUS_SUCCESS!=status)                   // A problem?
          {
           DbgPrint((JADrvNm " " JADrvRtnsName ":  Failed to open subkey, status = 0x%08x; quitting\n", status));

           goto exit;
          }
                                                                                                                                           
        status = ZwQueryValueKey(hSubKey,             // Get data from NameServer value.                                                                                                                               
                                 &NameServerValue,
                                 KeyValuePartialInformation,
                                 pSubKeyValue,
                                 lnKeyValueInfo,
                                 &ulOutInfo
                                );
                                                                                                                                           
        if (STATUS_SUCCESS==status)                   // Success?                                                                                                     
          ;                                           // Just drop down.
        else
        if (STATUS_OBJECT_NAME_NOT_FOUND==status)     // Not found?                                                                                                                 
          goto CloseSubKey;                           
        else
          {                                           // Something else.                                                                                                                                           
           DbgPrint((JADrvNm " " JADrvRtnsName ":  Unexpected error in getting NameServer value, status = 0x%08x; quitting\n", status));

           bQuitEnumLoop = TRUE;                      // Ensure subkey-enumeration loop is exited.
           goto CloseSubKey;
          }                                                                                                                                           
                                                                                                                                           
        PKEY_VALUE_PARTIAL_INFORMATION pSubKeyValueInfo =
          (PKEY_VALUE_PARTIAL_INFORMATION)pSubKeyValue;

        if (REG_SZ==pSubKeyValueInfo->Type)           // Expected type?
          {
           RtlInitUnicodeString(&UniSubKeyValue,      // Build Unicode descriptor.
                                (PCWSTR)pSubKeyValueInfo->Data
                               );

           PWCHAR pStr = UniSubKeyValue.Buffer,
                  pStrLast = pStr + wcslen(pStr);

           for (                                      // Go through the DNS IP addresses.
                ;
                pStr<pStrLast;                        // So long as at a point before null terminator.
               )
             {
              ULONG lenNSIPAddr;

              PWCHAR pComma = wcschr(pStr, ',');      // Find next comma in DNS string.

              if (NULL==pComma)                       // None?
                lenNSIPAddr = wcslen(pStr);           // Get remaining length (in wide characters).
              else
                lenNSIPAddr = pComma - pStr;          // Calculate length (in wide characters).

              memcpy(pSubKeyValue,                    // Use pSubKeyValue as a work area.
                     pStr,
                     lenNSIPAddr*sizeof(WCHAR)        // Double length, for byte count.
                    );

              *(pSubKeyValue+lenNSIPAddr) =           // Ensure a trailing null terminator.
                UNICODE_NULL;

              WCHAR * pOutW;                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                               
              ULONG DNServerAddr =                    // Get network-form address (translate octets to binary and swap positions).                                                                                                                    
                      GetInetAddr(pSubKeyValue, &pOutW);                                                                                                                                                                                            
                                                                                                                                        
              if (0!=DNServerAddr)                    // Not zero (a bit of a sanity check)?
                {
                 pDevExt->DNSIPAddr[cumDNSIPAddrCt] = // Keep DNS IP address in device-extension array.
                   DNServerAddr;

                 cumDNSIPAddrCt++;                    // Bump cumulative count of DNS IP addresses kept.

                 if (szDNSIPArray==cumDNSIPAddrCt)    // Reached the limit of the array?
                   {
                    bQuitEnumLoop = TRUE;             // Ensure subkey-enumeration loop is exited.
                    goto CloseSubKey;
                   }
                }
                                                                                                                                        
              pStr += lenNSIPAddr + 1;                // Bump pointer past comma or past end.
             }                                        // End 'for' go through the DNS IP addresses.
          }                                           // End 'if' expected type.

CloseSubKey:
        ZwClose(hSubKey);                                                                                                                                   

        if (TRUE==bQuitEnumLoop)                      // To quit subkey-enumeration loop?
          break;
       }                                              // End 'for' enumerate NIC subkeys.                                                                                      
                                                                                                                                           
    } while(0);                                       // End 'do-while' single-iteration loop.

exit:
 if (NULL!=pWk)                                       // Got working storage?
   ExFreePool(pWk);

 if (INVALID_HANDLE_VALUE!=hRegKey)                   // Registry opened?
   ZwClose(hRegKey);

 if (cumDNSIPAddrCt>0)                                // Found at least 1 DNS IP address?
   {

#if DBG

    for (ULONG i = 0; i < cumDNSIPAddrCt; i ++)       // Say what was found.
      {
       ULONG addr =                                   // Get IP address, converting it from network form.
               GetNetwkAddrDw(pDevExt->DNSIPAddr[i]);                                                                                                                                                                                                  
                                                                                                                                                                                                                                                          
       DbgPrint((JADrvNm " " JADrvRtnsName ":  DNS IP addr = %d.%d.%d.%d\n",
                 (addr>>24), ((0x00ff0000&addr)>>16), ((0x0000ff00&addr)>>8), (0x000000ff&addr)
               ));
      }

#endif

    status = STATUS_SUCCESS;
   }                                                  // End 'if' found at least 1 DNS IP address.
 else                                                 
   status = STATUS_UNSUCCESSFUL;

 return status; 
}                                                     // End GetNSInfo().


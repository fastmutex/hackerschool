//****************************************************************************//
//*                                                                           //
//* Copyright (C) 2003, James Antognini, antognini@mindspring.com.            //
//*                                                                           //
//****************************************************************************//

/******************************************************************************/      
/*                                                                            */      
/* Notes:                                                                     */      
/*                                                                            */      
/******************************************************************************/      

#define JADrvRtnsName   "HTTPFetch"
#define JADrvRtnsVer    "1.04"                                                                  
                                                                                                
#ifdef __cplusplus  // C++ conversion.                                                          
extern "C"                                                                                      
{                                                                                               
#endif              // End #ifdef C++ conversion.                                               
                                                                                                
#include <ntddk.h>
#include <tdikrnl.h>
                                                                                                
#define  JADriverKernelMode 1                         // Ensure kernel pieces available.        
#include "TDIClient.h"                                                                             
                                                                                                
#ifdef __cplusplus  // C++ conversion.                                                          
}                                                                                               
#endif              // End #ifdef C++ conversion.                                               

// The preprocessor variable UseRecvHandler controls whether the Receive event handler is used.
// This variable may be externally defined (ie, in sources file or in a command window) via
// C_DEFINES, eg, C_DEFINES=-DUseRecvHandler=FALSE.

#if !defined(UseRecvHandler)                          // Not defined?
#define UseRecvHandler   FALSE                        // Set UseRecvHandler to FALSE.
#endif

#define UseRecvHandler FALSE

#define TDIClnURLRecvBfrLen 100000

//****************************************************************************//
//*                                                                           //
//* Globals.                                                                  //
//*                                                                           //
//****************************************************************************//

#define CompDateTimeStr "dd mmm yyyy hh:mm:ss"

char HTTPFetchCompileInfo[sizeof(CompDateTimeStr)+1] =// Null in first character means not initialized.
       {0x0};

char static * pHTTPData[] = {                         // Pointer to data to be sent.
                             "GET ",
                             " HTTP/1.0\r\n"
                             "Accept: text/html, image/gif, image/jpeg, *; q=.2, */*; q=.2\r\n"          
                             "Content-Type: application/x-www-form-urlencoded\r\n"                       
                             "Connection: keep-alive\r\n\r\n"                                            
                            };
  
//****************************************************************************//
//*                                                                           //
//* Forward definitions of routines provided here.                            //
//*                                                                           //
//****************************************************************************//

NTSTATUS
HTTPFetchClient(pTDIClientExtension, ULONG, USHORT, pTDIClnReqElem, pTDIClientTestStr);

NTSTATUS
HTTPFetchPerformSend(pTDIClientExtension, PFILE_OBJECT, pTDIClnReqElem, pTDIClientTestStr);

NTSTATUS
HTTPFetchPerformReceives(pTDIClientExtension, PFILE_OBJECT, pTDIClnReqElem, TDIClientOperType, pTDIClnConn);

/**************************************************************************************************/
/*                                                                                                */
/**************************************************************************************************/
NTSTATUS
HTTPFetch(
          pTDIClientExtension pDevExt,                // Device extension.
          pTDIClientTestStr   pInStr,                 // Parameters from user space (via IOCTL).
          PULONG              pOutBufferSz            // Size of output buffer.
         )
{
 NTSTATUS                    status,
                             ExecStatus = STATUS_SUCCESS;

 #define                     NbrReqElems  10          // Number of request elements.
 #define                     NbrConns      2          // Number of connection endpoints.

 TDIClnReqElem               ReqElem[NbrReqElems];

 if (0==HTTPFetchCompileInfo[0])                      // Information string about compilation date and time not yet built?
   {
    char static DateCompiledBase[] = __DATE__,
                TimeCompiledBase[] = " "__TIME__;
    char        tmpDateCompileInfo[]   =              // Build date in preferred (dd mmm yyyy) format.
                  {DateCompiledBase[4], DateCompiledBase[5], DateCompiledBase[6],
                   DateCompiledBase[0], DateCompiledBase[1], DateCompiledBase[2], DateCompiledBase[3],
                   DateCompiledBase[7], DateCompiledBase[8], DateCompiledBase[9], DateCompiledBase[10],
                   0x0
                  };

    // Build date and time of compilation.

    if (' '==tmpDateCompileInfo[0])                   // Leading blank (ie, first through ninth day of month)?
      strcpy(HTTPFetchCompileInfo, tmpDateCompileInfo+1);
    else
      strcpy(HTTPFetchCompileInfo, tmpDateCompileInfo+0);
    strcat(HTTPFetchCompileInfo, TimeCompiledBase);
   }

 DbgPrint((JADrvNm " " JADrvRtnsName " v" JADrvRtnsVer " (compiled %s)\n",
           HTTPFetchCompileInfo));
 
 do {                                                 // Single-iteration loop, to make possible escape via break.
     pInStr->rc = STATUS_SUCCESS;                     // Presume success.
 
     ULONG lenOutputBfr = *pOutBufferSz;              // Save output buffer size.

     *pOutBufferSz = sizeof(TDIClientTestStr);        // Set minimum output size.

     pDevExt->hAddr = INVALID_HANDLE_VALUE;
     pDevExt->pAddrFileObj = NULL;
     pDevExt->pReqElemsArr = NULL;
     pDevExt->pBufferBase = NULL;
     pDevExt->pTDIClnConnArr = NULL;

     //
     // Handle parameters.
     //

     WCHAR * pOutW;

     ANSI_STRING AnsiDestAddr,
                 AnsiDestPort;

     AnsiDestAddr.Length = strlen(pInStr->InDestAddr);                   
     AnsiDestAddr.MaximumLength = strlen(pInStr->InDestAddr) + 1;        
     AnsiDestAddr.Buffer = pInStr->InDestAddr;                           

     AnsiDestPort.Length = strlen(pInStr->InDestPort);
     AnsiDestPort.MaximumLength = strlen(pInStr->InDestPort) + 1;
     AnsiDestPort.Buffer = pInStr->InDestPort;

     UNICODE_STRING UniDestAddr,
                    UniDestPort;

     status = RtlAnsiStringToUnicodeString(&UniDestAddr, &AnsiDestAddr, TRUE);

     if (!NT_SUCCESS(status))
       {
        DbgPrint((JADrvNm " " JADrvRtnsName ".HTTPFetch:  Failed RtlAnsiStringToUnicodeString() # 1, status = 0x%08x, quitting\n", status));
        pInStr->rc = status;
        break;
       }

     status = RtlAnsiStringToUnicodeString(&UniDestPort, &AnsiDestPort, TRUE);

     if (!NT_SUCCESS(status))
       {
        DbgPrint((JADrvNm " " JADrvRtnsName ".HTTPFetch:  Failed RtlAnsiStringToUnicodeString() # 2, status = 0x%08x, quitting\n", status));
        pInStr->rc = status;
        break;
       }

     ULONG  DestAddr =                                // Get network-form address (translate octets to binary and swap positions).
       GetInetAddr(UniDestAddr.Buffer, &pOutW);
     USHORT DestPort =                                // Get network-form port.
       (USHORT)((GetInetAddr(UniDestPort.Buffer, &pOutW))>>16);

     RtlFreeUnicodeString(&UniDestAddr);              // Free allocated storage.
     RtlFreeUnicodeString(&UniDestPort);              // "

     //
     // Open transport address.
     //

     USHORT tmpPort = 0;

//   DbgPrint((JADrvNm " " JADrvRtnsName ".HTTPFetch:  Opening transport addr = %d\n", GetNetwkPort(tmpPort)));

     status = TDIClnOpenTransAddr(                    
                                  wcharTcpDevName,
                                  &pDevExt->hAddr,
                                  &pDevExt->pAddrFileObj,
                                  tmpPort
                                 );

     if (!NT_SUCCESS(status))                         // A problem?
       {
        pInStr->rc = status;
        break;
       }

     //
     // Get buffer space, request elements, etc.
     //

     // Get space for request elements.

     pDevExt->pReqElemsArr =                         
       (pTDIClnReqElem)ExAllocatePool(
                                      NonPagedPool,
                                      sizeof(TDIClnReqElem)*NbrReqElems
                                     );

     if (NULL==pDevExt->pReqElemsArr)                 // Didn't work?
       {
        DbgPrint((JADrvNm " " JADrvRtnsName ".HTTPFetch:  Failed to get request elements, quitting\n"));
        status =
          pInStr->rc =
            STATUS_INSUFFICIENT_RESOURCES;
        break;
       }

     #if UseRecvHandler                               // Use Receive event handler?
     #define BufferPoolType NonPagedPool              // Get storage from non-paged pool.
     #else
     #define BufferPoolType PagedPool                 // Get storage from paged pool.
     #endif

     // Get buffer space.  If paged pool is used, MmProbeAndLockPages will be used later, and the transport
     // is presumed to do the unfixing.

     pDevExt->pBufferBase =                           
       (PCHAR)ExAllocatePool(
                             BufferPoolType,
                             TDIClnURLRecvBfrLen*NbrReqElems
                            );

     if (NULL==pDevExt->pBufferBase)                  // Didn't work?
       {
        DbgPrint((JADrvNm " " JADrvRtnsName ".HTTPFetch:  Failed to get buffer, quitting\n"));
        status =
          pInStr->rc =
            STATUS_INSUFFICIENT_RESOURCES;
        break;
       }

     // Set up request elements.

     memset(ReqElem, 0, sizeof(ReqElem));             // Clear elements.

     for (ULONG i = 0; i < NbrReqElems; i ++)
       {
        ReqElem[i].pBuffer =                          // Point to i-th place in buffer.
          pDevExt->pBufferBase + (i*TDIClnURLRecvBfrLen);
        KeInitializeEvent(&ReqElem[i].RecvEvent,      // Initialize i-th Receive event (used only in completion of a Receive Irp).
                          NotificationEvent,
                          FALSE                       // Initialized to not-signalled.
                         );
       }

     // Get space for connection endpoint structures.

     pDevExt->pTDIClnConnArr =                       
       (pTDIClnConn)ExAllocatePool(
                                   NonPagedPool,
                                   sizeof(TDIClnConn)*NbrConns
                                  );

     if (NULL==pDevExt->pTDIClnConnArr)               // Didn't work?
       {
        DbgPrint((JADrvNm " " JADrvRtnsName ".HTTPFetch:  Failed to get client connection endpoints, quitting\n"));
        status =
          pInStr->rc =
            STATUS_INSUFFICIENT_RESOURCES;
        break;
       }

     memset(pDevExt->pTDIClnConnArr,                  // Clear memory.
            0,
            sizeof(TDIClnConn)*NbrConns
           );

     //
     // Open connection endpoints.
     //

     for (ULONG i = 0; i < NbrConns; i ++)            
       {
        pDevExt->pTDIClnConnArr[i].pReqElemsArr =     // Point to array of request elements.
          ReqElem;
        pDevExt->pTDIClnConnArr[i].pDevExt =          // Point to device extension.
          pDevExt;
        pDevExt->pTDIClnConnArr[i].hConn =            // Show invalid handle value.
          INVALID_HANDLE_VALUE;

        status = TDIClnOpenConnEndPt(                 
                                     &pDevExt->pTDIClnConnArr[i],
                                     pDevExt
                                    );

        if (!NT_SUCCESS(status))                      // A problem?
          {
           pInStr->rc = status;
           goto doCleanUp;
          }
       }                                              

     //
     // Get pointer to TDI driver's (\Driver\SYMTDI, as found by windbg on WinXP Pro SP1 system) device object.
     //

     pDevExt->pTcpDevObj = IoGetRelatedDeviceObject(pDevExt->pAddrFileObj);

     //
     // Set up some event handlers.
     //

#if FALSE                                             // Use Receive event handler?
//#if UseRecvHandler                                    // Use Receive event handler?

     status =                                         // Set up Receive event handler.
       TDIClnSetEventHandler(
                             pDevExt->pAddrFileObj,
                             pDevExt->pTcpDevObj,
                             TDI_EVENT_RECEIVE,
                             TDIClnEventReceive,      // Receive event handler routine.
                             NULL
                            );

     if (!NT_SUCCESS(status))
       {
        pInStr->rc = status;
        break;
       }

#endif                                                // End #if UseRecvHandler.

//   KeInitializeEvent(&pDevExt->DiscEvent, NotificationEvent, FALSE);

     status =                                         // Set up disconnect event handler.
       TDIClnSetEventHandler(
                             pDevExt->pAddrFileObj,
                             pDevExt->pTcpDevObj,
                             TDI_EVENT_DISCONNECT,
                             TDIClnEventDisconnect,   // Disconnect event handler routine.
                             NULL                     // Event to be signalled by event handler.
                            );
  
     if (!NT_SUCCESS(status))
       {
        pInStr->rc = status;
        break;
       }

     status =                                         // Set up error event handler.
       TDIClnSetEventHandler(
                             pDevExt->pAddrFileObj,
                             pDevExt->pTcpDevObj,
                             TDI_EVENT_ERROR_EX,
                             TDIClnEventErrorEx,      // Error event handler routine.
                             NULL
                            );

     if (!NT_SUCCESS(status))
       {
        pInStr->rc = status;
        break;
       }


     //
     // Associate connection endpoints with transport address.
     //

     for (ULONG i = 0; i < NbrConns; i ++)            
       {
        status = TDIClnAssocAddr(                     
                                 pDevExt->pTDIClnConnArr[i].pConnFileObj,
                                 pDevExt->pTcpDevObj,
                                 pDevExt->hAddr
                                );

        if (!NT_SUCCESS(status))
          {
           pInStr->rc = status;
           goto doCleanUp;
          }
       }

     //
     // Handle the requested operation.
     //

     ExecStatus = HTTPFetchClient(
                                  pDevExt,
                                  DestAddr,
                                  DestPort,
                                  ReqElem,            // Address of request-element array.
                                  pInStr
                                 );

     //
     // Copy bytes into the output buffer.
     //

     if (STATUS_SUCCESS==ExecStatus)                  // Success?
       {
        PCHAR pOutData = (PCHAR)&pInStr->Buffer;      // Point to output buffer.
        ULONG i,
              ulBytesCopied,
              saveBytesCopied;

        for (
             i = 0,
               ulBytesCopied = 0;
             i < NbrReqElems;
             i ++
            )
          {
           if (0==ReqElem[i].ReqIoStatus.Information) // Nothing received?
             break;                                   // Leave 'for' loop.

           saveBytesCopied = ulBytesCopied;           // Keep bytes copied up to this point.

           ulBytesCopied +=                           // Accumulate bytes copied.
             ReqElem[i].ulBytesReceived;

           if (ulBytesCopied>lenOutputBfr)            // Not enough space left in output buffer?
             {
              DbgPrint((JADrvNm " " JADrvRtnsName ".HTTPFetch:  Output buffer too small, quitting\n"));
              ulBytesCopied = saveBytesCopied;        // Restore to number of bytes actually copied.
              status =
                pInStr->rc =
                  STATUS_INSUFFICIENT_RESOURCES;
              break;
             }

           memcpy(pOutData,                           // Copy data.
                  ReqElem[i].pBuffer,
                  ReqElem[i].ReqIoStatus.Information
                 );

           pOutData +=                                // Point to next available byte.
             ReqElem[i].ReqIoStatus.Information;
          }

        pInStr->ulBuffer = ulBytesCopied;             // Show bytes copied into buffer.

        *pOutBufferSz = sizeof(TDIClientTestStr) +    // Set size copied to size of header (including the byte of Buffer)
                        ulBytesCopied            -    //   plus bytes copied here
                        1;                            //   less 1 for the byte of Buffer itself.
       }

     //
     // Disassociate connection endpoints from transport address.
     //

     for (ULONG i = 0; i < NbrConns; i ++)            
       {
        status = TDIClnDisassocAddr(
                                    pDevExt->pTDIClnConnArr[i].pConnFileObj,
                                    pDevExt->pTcpDevObj
                                   );

        if (!NT_SUCCESS(status))
          {
           pInStr->rc = status;
           goto doCleanUp;
          }
       }
    } while(0);                                       // End 'do-while' single-iteration loop.

doCleanUp:
 if (NULL!=pDevExt->pBufferBase)                      // Got a buffer?
   {
    ExFreePool(pDevExt->pBufferBase);
    pDevExt->pBufferBase = NULL;
   }

 if (NULL!=pDevExt->pReqElemsArr)                     // Got request elements?
   {
    ExFreePool(pDevExt->pReqElemsArr);
    pDevExt->pReqElemsArr = NULL;
   }

 if (INVALID_HANDLE_VALUE!=pDevExt->hAddr)            // Opened transport address?
   {
    ZwClose(pDevExt->hAddr);
    pDevExt->hAddr = INVALID_HANDLE_VALUE;
   }

 if (NULL!=pDevExt->pTDIClnConnArr)                   // Got connection structures?
   {
    for (ULONG i = 0; i < NbrConns; i ++ )            
      {
       if (INVALID_HANDLE_VALUE!=                     // Opened connection endpoint?
           pDevExt->pTDIClnConnArr[i].hConn)
         {
          ZwClose(pDevExt->pTDIClnConnArr[i].hConn);
          pDevExt->pTDIClnConnArr[i].hConn = INVALID_HANDLE_VALUE;
         }

       if (NULL!=                                     // Referenced object?
             pDevExt->pTDIClnConnArr[i].pConnFileObj)
         {
          ObDereferenceObject(pDevExt->pTDIClnConnArr[i].pConnFileObj);
          pDevExt->pTDIClnConnArr[i].pConnFileObj = NULL;
         }
      }

    ExFreePool(pDevExt->pTDIClnConnArr);              // Free storage used for connection structures.
    pDevExt->pTDIClnConnArr = NULL;
   }

 if (NULL!=pDevExt->pAddrFileObj)                     // Referenced object?
   {
    ObDereferenceObject(pDevExt->pAddrFileObj);
    pDevExt->pAddrFileObj = NULL;
   }

 return STATUS_SUCCESS==status ? ExecStatus : status; // Return ExecStatus unless status!=STATUS_SUCCESS.
}                                                     // End HTTPFetch().

/**************************************************************************************************/
/*                                                                                                */
/* Perform functions as client to remote server.                                                  */
/*                                                                                                */
/**************************************************************************************************/
NTSTATUS
HTTPFetchClient(
                pTDIClientExtension  pDevExt,
                ULONG                DestAddr,
                USHORT               DestPort,
                pTDIClnReqElem       pReqElem,        // Address of request-element array.
                pTDIClientTestStr    pInStr           // Parameters from user space (via IOCTL).
               )
{
 NTSTATUS                    status;

 do {                                                 // Single-iteration loop, to make possible escape via break.
     pTDIClnConn                 pLclConn = NULL;

     //
     // Connect to address and port specified by IOCTL.
     //

     // Note:  If TDIClientExec is done on a previously used connection, even one that has been disconnected,
     // STATUS_ADDRESS_ALREADY_EXISTS (0xC000020A) will result if connection is in TIME_WAIT.

     for (ULONG i = 0; i < NbrConns; i ++)            // Try to open a connection endpoint.
       {
//      DbgPrint((JADrvNm " " JADrvRtnsName ".HTTPFetchClient:  i = %d, event at 0x%08x\n", i, &pDevExt->pTDIClnConnArr[i].DiscEvent));

        status = TDIClnConnect(                       // Effect connection by initiating offer.
                               pDevExt->pTDIClnConnArr[i].pConnFileObj,
                               pDevExt->pTcpDevObj,
                               DestAddr,
                               DestPort
                              );

        if (NT_SUCCESS(status))                       // Success?
          {                                           // Use this connection structure.
           pLclConn = &pDevExt->pTDIClnConnArr[i];    // Get a pointer to the connection structure.
           pLclConn->bConnd = TRUE; 
           KeInitializeEvent(&pLclConn->DiscEvent, NotificationEvent, FALSE);                     

           break;
          }
       }

     if (NULL==pLclConn)                              // Didn't work?
       {
        DbgPrint((JADrvNm " " JADrvRtnsName ".HTTPFetchClient:  Failed in TDIClnConnect(), quitting\n", status));
        break;
       }

     // Note:  Because the same buffers are used in Receive and Send, all Send operations must be complete
     //        before Receive operations commence, and vice-versa.

     //
     // Perform Sends.
     //

     status = HTTPFetchPerformSend(
                                   pDevExt,
                                   pLclConn->pConnFileObj,
                                   pReqElem,          // Address of request-element array.
                                   pInStr
                                  );

     if (STATUS_SUCCESS!=status)                      // A problem?
       break;

     //
     // Perform Receives.
     //

     status = HTTPFetchPerformReceives(
                                       pDevExt,
                                       pLclConn->pConnFileObj,
                                       pReqElem,           // Address of request-element array.
                                       TDIClientURL,       // This indicates disconnection at the proper place.
                                       pLclConn
                                      );

     if (STATUS_SUCCESS!=status)
       break;

     //
     // Disconnect.
     //

     status = TDIClnDisconnect(
                               pLclConn->pConnFileObj,
                               pDevExt->pTcpDevObj
                              );

     if (
         !NT_SUCCESS(status)                          // A problem?
           &&
         STATUS_CONNECTION_INVALID!=status            // Problem is not invalid connection, eg, not due to other side disconnecting?
        )
       break;

     // Wait on disconnection to complete.

//   DbgPrint((JADrvNm " " JADrvRtnsName ".HTTPFetchClient:  i = %d, event at 0x%08x\n", i, &pLclConn->DiscEvent));

     KeWaitForSingleObject(&pLclConn->DiscEvent, Executive, KernelMode, FALSE, 0);
    } while(0);                                       // End 'do-while' single-iteration loop.
  
 return status;
}                                                     // End TDIClnExecClient().

/**************************************************************************************************/
/*                                                                                                */
/* Perform Sends on open connection.                                                              */
/*                                                                                                */
/**************************************************************************************************/
NTSTATUS
HTTPFetchPerformSend(
                     pTDIClientExtension pDevExt,
                     PFILE_OBJECT        pConnFileObj,
                     pTDIClnReqElem      pReqElem,    // Address of request-element array.
                     pTDIClientTestStr   pInStr       // Parameters from user space (via IOCTL).
                    )
{
 NTSTATUS                    status = STATUS_SUCCESS;

 do {                                                 // Single-iteration loop, to make possible escape via break.
     ULONG ulBfr = strlen(pHTTPData[0])          +    // Length of first fixed part.
                   strlen(pInStr->InURIResource) +    // Length of URI resource.
                   strlen(pHTTPData[1])          +    // Length of second fixed part.
                   1;                                 // Length of null terminator.

     char * pData =                                   // Get storage for dynamically built HTTP request data.
       (char *)ExAllocatePool(NonPagedPool, ulBfr);

     if (NULL==pData)
       {
        DbgPrint((JADrvNm " " JADrvRtnsName ".HTTPFetchPerformSend:  Couldn't get buffer\n"));
        status = STATUS_INSUFFICIENT_RESOURCES;
        break;
       }

     strcpy(pData, pHTTPData[0]);                     // Build HTTP data, with "GET,"
     strcat(pData, pInStr->InURIResource);            //   the supplied URI resource and
     strcat(pData, pHTTPData[1]);                     //     the remainder.

     status = TDIClnSend(pConnFileObj,
                         pDevExt->pTcpDevObj,
                         pData,
                         ulBfr
                        );

     ExFreePool(pData);

     if (!NT_SUCCESS(status))
       break;
    } while(0);                                       // End 'do-while' single-iteration loop.
  
 if (STATUS_SUCCESS!=status)
   {
    DbgPrint((JADrvNm " " JADrvRtnsName ".HTTPFetchPerformSend:  Ending status = %lx\n", status));
   }
  
 return status;
}                                                     // End HTTPFetchPerformSend().

/**************************************************************************************************/
/*                                                                                                */
/* Perform Receives on open connection.                                                           */
/*                                                                                                */
/* If caller is acting as client, disconnection will be done, too.                                */
/*                                                                                                */
/**************************************************************************************************/
NTSTATUS
HTTPFetchPerformReceives(
                         pTDIClientExtension pDevExt,
                         PFILE_OBJECT        pConnFileObj,
                         pTDIClnReqElem      pReqElem,// Address of request-element array.
                         TDIClientOperType   OperType,
                         pTDIClnConn         pLclConn
                        )
{
 NTSTATUS                    status;

 do {                                                 // Single-iteration loop, to make possible escape via break.
     ULONG i,
           nbrWaits,
           ulDataRcvd;

     // Do the number of Receives indicated by NbrReqElems, unless disconnection (by the other side) has occurred.
     // In the event of a disconnection, the final Receive will wait some seconds, then Disconnect will be regis-
     // tered by the Disconnect event handler (TDIClnEventDisconnect()), which will signal the Disconnect event,
     // and the outstanding Receive will complete with IoStatus.Status = 0 and IoStatus.Information = 0.

     for (                                            // Do Receives (or just loop, if Receive event handler used).
          i = 0,
            nbrWaits = 0,
            ulDataRcvd = 0;
          i < NbrReqElems                             // Haven't exceeded maximum number of requests?
            &&
          0==KeReadStateEvent(&pLclConn->DiscEvent);  // Not disconnected?
          i ++,
            nbrWaits ++                               // Bump number of waits to be done.
         )
       {
        // If the Receive event handler is being used, incoming data are received without any Receive Irps being
        // sent to the transport.  That is, this particular routine is more "server-like," just responding to
        // client requests and not (in the case of Receive operations) initiating I/O.  But the same Receive event
        // handler logic works well when the role being performed is that of a client to a remote server.
        //
        // For didactic purposes, however, the "active" Receive logic (that is, the call to TDIClnRecv) is
        // retained and can be used by building with the preprocessor variable UseRecvHandler set to FALSE (see
        // above on how to do that).

        if (TRUE==UseRecvHandler)                     // Using Receive event handler?
          continue;                                   // Skip to bottom of loop.

        // Since there's no guarantee that a particular Receive will contain integral sent units
        // (that is, the strings sent by WinsockServer.cpp), zero the Receive buffer so that even
        // if the last string in a buffer is not complete, it will appear as a string since what
        // there is of it will be null-terminated.

        pReqElem[i].pBuffer[TDIClnURLRecvBfrLen-1] =  // Ensure last byte in buffer can function as a null terminator.
          0;

//      DbgPrint((JADrvNm " " JADrvRtnsName ".TDIClnPerformReceives:  About to start Receive\n"));

        status = TDIClnRecv(pConnFileObj,
                            pDevExt->pTcpDevObj,
                            pReqElem[i].pBuffer,           // Buffer to fill.
                            TDIClnURLRecvBfrLen-1,         // Ensure that at least the last null remains untouched.
                            &pReqElem[i].ReqIoStatus,      // IoStatus.
                            (PVOID)&pReqElem[i].RecvEvent  // Context for I/O completion routine.
                           );

        if (
            STATUS_SUCCESS!=status
              &&
            STATUS_PENDING!=status
           )
          {
           if (STATUS_INVALID_DEVICE_STATE!=status)   // Not (presumably) past last good Send/Receive?
             {
              DbgPrint((JADrvNm " " JADrvRtnsName ".HTTPFetchPerformReceives:  Receive status = %lx\n", status));
             }
           break;
          }

        if (STATUS_PENDING==status)
          status = KeWaitForSingleObject(&pReqElem[i].RecvEvent, Executive, KernelMode, FALSE, NULL);

//      KTIMER lclTimer;                                                                               
                                                                                               
//      LARGE_INTEGER Timeout;
//      Timeout.QuadPart = -20000000L;                // 2 seconds

// Next is really kludgy, but gives remote node a chance to send stuff, stuff to arrive here and remote node eventually to disconnect.

//      KeInitializeTimerEx(&lclTimer, NotificationTimer);

//      KeSetTimerEx(&lclTimer, Timeout, 0, NULL);

//      status = KeWaitForSingleObject(&lclTimer, Executive, KernelMode, FALSE, NULL);

        ulDataRcvd += pReqElem[i].ulBytesReceived;    // Get running total of bytes received.
       }                                              // End 'for' do Receives (or just loop).

//   DbgPrint((JADrvNm " " JADrvRtnsName ".TDIClnPerformReceives:  Total bytes received = %d\n", ulDataRcvd));

     // Display the received data.

//   for (i = 0; i < nbrWaits; i ++)                  
//     {
//      // Note:  If other side disconnected prematurely (ie, TDIClnDisconnect got STATUS_CONNECTION_INVALID),
//      //        ReqIoStatus.Status will probably = STATUS_CONNECTION_RESET, and ReqIoStatus.Information = 0).
//
//      if (                                                     
//          STATUS_SUCCESS!=                          // Some error?
//            pReqElem[i].ReqIoStatus.Status     
//            ||
//          0==pReqElem[i].ReqIoStatus.Information    // No data?
//         )
//        {
//         DbgPrint((JADrvNm " " JADrvRtnsName ".TDIClnPerformReceives:  i = %d, ReqIoStatus.Status = 0x%08x, "
//                   "ReqIoStatus.Information = 0x%08x\n",
//                   i, pReqElem[i].ReqIoStatus.Status, pReqElem[i].ReqIoStatus.Information));
//         continue;                                  // Skip to bottom of the current for-loop.
//        }
//
//      #define ServerMsgArraySz 10
//
//      // It is assumed -- but not checked -- that in each Receive there is at least 1 string and
//      // that the total number of strings sent across receives does not exceed ServerMsgArraySz.
//
//      char       * pSvrMsg[ServerMsgArraySz];
//      int          msgCt = 0;
//      BOOLEAN      bFindNextStr = TRUE;
//
//      // Find strings (there may be more than one in the received data, since sent data may have been aggregated).
//
//      for (ULONG charIdx = 0; charIdx < pReqElem[i].ReqIoStatus.Information; charIdx ++)                                                                                                                                                                     
//        {
//         if (TRUE==bFindNextStr)                    // Looking for a string?
//           if (0!=pReqElem[i].pBuffer[charIdx])     // Is current byte not 0?
//             {
//              msgCt++;                              // Bump string count.
//              pSvrMsg[msgCt-1] =                    // Point to current string.
//                &pReqElem[i].pBuffer[charIdx];
//              bFindNextStr = FALSE;                 // Remember now not looking for a string.
//             }
//           else
//             ;
//         else                                       // Handling a string.
//           if (0==pReqElem[i].pBuffer[charIdx])     // Is current byte 0?
//             bFindNextStr = TRUE;                   // Remember now looking for a string.
//           else
//             ;
//        }
//
//      // Display the string(s) received from the server.  (The first and last could be partial.)                                                                                                                                                          
//
//      for (int msgIdx = 0; msgIdx < msgCt; msgIdx ++)
//        {
//         DbgPrint((JADrvNm " " JADrvRtnsName ".TDIClnPerformReceives:  For i = %d, received data = \n\n>%s<\n",
//                   i, pSvrMsg[msgIdx]));
//        }
//     }                                              // End 'for' Display the received data.
    } while(0);                                       // End 'do-while' single-iteration loop.
  
 if (STATUS_SUCCESS!=status)
   {
    DbgPrint((JADrvNm " " JADrvRtnsName ".HTTPFetchPerformReceives:  Ending status = %lx\n", status));
   }
  
 return status;
}                                                     // End HTTPFetchPerformReceives().


//****************************************************************************//
//*                                                                           //
//* Copyright (C) 2003, James Antognini, antognini@mindspring.com.            //
//*                                                                           //
//****************************************************************************//

/**************************************************************************************************/      
/*                                                                                                */      
/* Invoke TDI client, supplying IP address and port to connect to.  At present, 192.168.1.5 is    */      
/* always the IP address.  The port may be specified but defaults to 5004.                        */      
/*                                                                                                */      
/**************************************************************************************************/      

/**************************************************************************************************/      
/*                                                                                                */      
/* Notes:                                                                                         */      
/*        1) The default DNS IP address supplied here in dfltDNSIPAddr and also the default       */      
/*           dfltDNSIPAddrIP address supplied here in dfltIPAddr will probably need to be         */      
/*           changed.                                                                             */      
/*                                                                                                */      
/*        2) Winsock error codes are in winsock2.h and are defined as 10000 plus the remainder.   */      
/*           Thus, 10093 will be found under the string '93'.                                     */      
/*                                                                                                */      
/**************************************************************************************************/      

#define JARtnName         "TalkTDIClient"
#define JARtnVer          "1.29"

#include <winsock2.h>
#include <windows.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <process.h>
#include <commctrl.h>
#include <winioctl.h>

#include "TDIClient.h"

#define rcOK      0
#define rcError   8

static struct
  {
   char              * pInStr;
   TDIClientOperType   OperType;
  }
   InStrArr[] =
     {                                                // Except that CmdUnknown has to be first, the following can be in any order.
      {"",       TDIClientUnknown},
      {"server", TDIClientServer},
      {"client", TDIClientClient},
      {"URL",    TDIClientURL},
      {"DNS",    TDIClientDNS},
      {".",      TDIClientServer}
     };

/**************************************************************************************************/      
/*                                                                                                */      
/* Prototypes (forward defines).                                                                  */      
/*                                                                                                */      
/**************************************************************************************************/      

BOOL
  OpenDevice(IN LPCTSTR, HANDLE *);

BOOL
  CallDriver(HANDLE, int, PBYTE, int, PBYTE, int);

/**************************************************************************************************/      
/*                                                                                                */      
/* Display syntax.                                                                                */      
/*                                                                                                */      
/**************************************************************************************************/      
void
PrintUsage()
{
 DWORD                   i,
                         lnInStrArr =                 // Get number of instances.
                           sizeof InStrArr / sizeof InStrArr[0];

 printf("\n  Unsupported command\n");
 printf("\n  Usage:  " JARtnName " <operand>\n");
 printf("\n          where <operand> is one of these:\n\n");

 for (i = 1; i < lnInStrArr; i ++)
   printf("            %s\n", InStrArr[i].pInStr);

 printf("\n          Eg,\n"
        "\n            <server | client | URL | DNS | .> <IP address | IP name | .>"
        "\n              <port | . <URL resource>>\n\n"
       );
 printf("\n          (Default role is server; default IP address, 192.168.1.5;"
        "\n          default port, 5004.  A default is denoted by a period (\".\")."
        "\n          IP address is not meaning for server but is accepted.)\n"
       );

}                                                     // End PrintUsage().

/**************************************************************************************************/      
/*                                                                                                */      
/**************************************************************************************************/      
int main(
         IN int    nbrArgs,
         IN char * pArgv[]
        )
{
 #define rcOK          0
 #define rcError       8

 #define CmdUnknown    0
 #define CmdStart      1
 #define CmdStop       2
 #define CmdTest       3
 #define CmdTest2      4
 #define CmdTest3      5
 #define CmdTest4      6
 #define CmdTest5      7

 char             static dfltOperType[] = "server",   // Default operation type.
                         dfltIPAddr[] =               // Default IP address.
                           charDfltRmtAddr,
                         dfltPort[] = charDfltPort,   // Default port.
                         dfltURLPort[] = "80",        // Default URL port.
                         dfltDNSIPAddr[] =            // Default DNS IP address.
                           "207.69.188.186",
                         dfltDNSPort[] = "53",        // Default DNS port.
                         DevicePath[] = "\\DosDevices\\",
                         dfltURIResource[] = "/",
                         DateCompiledBase[] = __DATE__,                                                                             
                         TimeCompiledBase[] = " "__TIME__;                                                                             
 #define CompDateTimeStr "dd mmm yyyy hh:mm:ss"      
 #define chQuestion      '?'
 char                    PgmCompileInfo[sizeof(CompDateTimeStr)+1],
                         DateCompiled[] =             // Build date in preferred (dd mmm yyyy) format.                                      
                           {DateCompiledBase[4], DateCompiledBase[5], DateCompiledBase[6],
                            DateCompiledBase[0], DateCompiledBase[1], DateCompiledBase[2], DateCompiledBase[3],
                            DateCompiledBase[7], DateCompiledBase[8], DateCompiledBase[9], DateCompiledBase[10],
                            0x0
                           },
                         dynIPAddr[16] =              // Default is IP address is not looked up (that is, name not given).
                           {chQuestion},
                         DriverName[] = JADrvNm,
                         FullDeviceName[sizeof(DevicePath)+sizeof(DriverName)];
 char                  * pIPAddr,
                       * pPort = NULL,
                       * pURIResource;
 HANDLE                  hDevice = INVALID_HANDLE_VALUE,
                         hLclEvnt = INVALID_HANDLE_VALUE;
 int                     rc = rcOK,
                         flagOpenDevice,
                         CmdNbr = CmdUnknown;
 TDIClientTestStr        lclTDIClientTestStr;
 pTDIClientTestStr       pLclStr;
 DWORD                   i,
                         lnInStrArr =                 // Get number of instances.
                           sizeof InStrArr / sizeof InStrArr[0];
 WSADATA                 WSAData;
 BOOL                    bHaveWSA = FALSE;

 if (' '==DateCompiled[0])                            // Is first day a blank?
  strcpy(PgmCompileInfo, DateCompiled+1);
 else
  strcpy(PgmCompileInfo, DateCompiled+0);

 strcat(PgmCompileInfo, TimeCompiledBase);

 printf(JARtnName " v" JARtnVer " (compiled %s)\n", PgmCompileInfo);                                                                                   

 i = lnInStrArr;                                      // Ensure PrintUsage() done if not enough parameters.

 if (nbrArgs>=2)                                      // At least the "verb" parameter supplied?
   {
    for (i = 1; i < lnInStrArr; i ++)                 // Go through expected parameters.
      if (0==_stricmp(pArgv[1], InStrArr[i].pInStr))  // Does the second parm match?
        {
         CmdNbr =
           lclTDIClientTestStr.InOperType =
             InStrArr[i].OperType;
         if (TDIClientURL==CmdNbr)                    // URL?
           pPort = dfltURLPort;                       // Point to default URL port.
         break;                                       // If yes, break.
        }
   }

 if (i==lnInStrArr)                                   // No verb or non-supported verb?
   {
    PrintUsage();

    rc = rcError;
    goto ExitPoint;
   }

 if (nbrArgs>=3)
   {                                                                                  
    pIPAddr = pArgv[2];                               // Get IP address.
    if (0==strcmp(pIPAddr, "."))                      // Dot given?
      pIPAddr = dfltIPAddr;                           // Point to default IP address.
   }
 else
   pIPAddr = dfltIPAddr;                              // Get IP addr.

 if (                                          
     TDIClientDNS==lclTDIClientTestStr.InOperType     // DNS?
       &&
     pIPAddr==dfltIPAddr                              // Using default IP address, namely, IP name not given (or dot given)?
    )
   {
    printf("  " JARtnName ".main():  For DNS request, an IP name is required\n");

    rc = rcError;
    goto ExitPoint;
   }

 if (nbrArgs>=4)                                   
   {                                                                                  
    char * pTmpPort = pArgv[3];                       // Port to supplied temporary port.

    if (0!=strcmp(pTmpPort, "."))                     // Dot not given?
      pPort = pTmpPort;                               // Point to supplied port.
    else                                              // Dot given
      if (TDIClientDNS==                              // DNS request?
            lclTDIClientTestStr.InOperType)
        pPort = dfltDNSPort;
      else
      if (NULL==pPort)                                // Port not already 80, that is, URL not given?
        pPort = dfltPort;                             // Point to default port.
   }
 else                                       
   {
    if (TDIClientDNS==                                // DNS request?
          lclTDIClientTestStr.InOperType)
      pPort = dfltDNSPort;
    else
    if (NULL==pPort)                                  // Port not already 80, that is, URL not given?
      pPort = dfltPort;                               // Get port.
   }

 if (nbrArgs>=5)                                   
   {                                                                                  
    pURIResource = pArgv[4];                          // Get URI resource.
    if (0==strcmp(pURIResource, "."))                 // Dot given?
      pURIResource = dfltURIResource;                 // Point to default URI resource. 
   }
 else                                       
   pURIResource = dfltURIResource;                    // Point to default URI resource.

 // If necessary, get IP address of IP name.

 if (
     (
      TDIClientClient==lclTDIClientTestStr.InOperType // Client operation?
        ||
      TDIClientURL==lclTDIClientTestStr.InOperType    // URL operation?
     )
       &&
     !isdigit(*(PUCHAR)pIPAddr)                       // First byte is not a digit?
    )
   {
    int rcWSA = WSAStartup(MAKEWORD(2,0), &WSAData);  // Initialize Winsocket; accept up to Winsock 2.0.

    if (0!=rcWSA)       
      {
       printf("  " JARtnName ".main():  WSAStartup() failed.  Error = %d\n", WSAGetLastError());

       rc = rcError;
       goto ExitPoint;
      }

    bHaveWSA = TRUE;                                  // Remember to clean up winsock.

    struct hostent * pHostInfo =                      // Get pointer to resolved IP name.
                       gethostbyname(pIPAddr);

    if (NULL==pHostInfo)                              // Didn't work?
      {
       printf("  " JARtnName ".main():  Couldn't resolve IP name = %s, rc = %d\n", pIPAddr, WSAGetLastError());

       rc = rcError;
       goto ExitPoint;
      }
    else
      {
       // Get IP address in character form.

       ULONG addr =                                   // Reverse from network order.
         GetNetwkAddrDw(*(PULONG)pHostInfo->h_addr);

       char octet1[4], 
            octet2[4],
            octet3[4],
            octet4[4];

       _ultoa(addr>>24,              octet1, 10);
       _ultoa((0x00ff0000&addr)>>16, octet2, 10);
       _ultoa((0x0000ff00&addr)>>8,  octet3, 10);
       _ultoa(0x000000ff&addr,       octet4, 10);
             
       strcpy(dynIPAddr, octet1);
       strcat(dynIPAddr, ".");
       strcat(dynIPAddr, octet2);
       strcat(dynIPAddr, ".");
       strcat(dynIPAddr, octet3);
       strcat(dynIPAddr, ".");
       strcat(dynIPAddr, octet4);
      }
   }

 if (TDIClientServer==lclTDIClientTestStr.InOperType) // Server?
   {
    printf("  Instructions:  Server listening on port %s\n", pPort);
   }
 else
 if (TDIClientClient==lclTDIClientTestStr.InOperType) // Client?
   {
    if (chQuestion==dynIPAddr[0])                     // IP address not looked up?
      printf("  Instructions:  Client opening IP addr = %s, port = %s\n", pIPAddr, pPort);
    else
      {
       printf("  Instructions:  Client opening IP name = %s, IP addr = %s, port = %s\n",
              pIPAddr, dynIPAddr, pPort);
       pIPAddr = dynIPAddr;                           // Point to dynamically resolved IP addr.
      }
   }
 else
 if (TDIClientURL==lclTDIClientTestStr.InOperType)    // URL?
   {
    if (chQuestion==dynIPAddr[0])                     // IP address not looked up?
     printf("  Instructions:  HTTP client opening IP addr = %s, port = %s, URL resource = %s\n",
            pIPAddr, pPort, pURIResource);
    else
      {
       printf("  Instructions:  HTTP client opening URL = %s, IP addr = %s, port = %s, URL resource = %s\n",
              pIPAddr, dynIPAddr, pPort, pURIResource);
       pIPAddr = dynIPAddr;                           // Point to dynamically resolved IP addr.
      }
   }
 else
 if (TDIClientDNS==lclTDIClientTestStr.InOperType)    // DNS?
   {
    printf("  Instructions:  DNS client getting IP name = %s, port = %s, DNS at %s\n",
           pIPAddr, pPort, dfltDNSIPAddr);
   }

 strcpy(FullDeviceName, DevicePath);
 strcat(FullDeviceName, DriverName);

 flagOpenDevice = OpenDevice(
                             DriverName,
                             &hDevice
                            );

 if (TRUE==flagOpenDevice)                            // Success?
   {
    BOOL bFlag;

    strcpy(lclTDIClientTestStr.InDestAddr, pIPAddr);
    strcpy(lclTDIClientTestStr.InDestPort, pPort);
    strcpy(lclTDIClientTestStr.InURIResource, pURIResource);

    switch(CmdNbr)
      {
       case TDIClientServer:
       case TDIClientClient:
  
         bFlag = CallDriver(
                            hDevice,
                            TDIClient_TEST,
                            (PBYTE)&lclTDIClientTestStr,
                            sizeof(TDIClientTestStr),
                            (PBYTE)&lclTDIClientTestStr,
                            sizeof(TDIClientTestStr)
                           );

         if (TRUE==bFlag)
           {
            if (0==lclTDIClientTestStr.rc)
              printf("  Total bytes sent in kernel = %d, received in kernel = %d\n",
                     lclTDIClientTestStr.ulKernelSent, lclTDIClientTestStr.ulKernelReceived);
            else
              printf("  " JARtnName ".main():  IOCTL rc = 0x%08x\n", lclTDIClientTestStr.rc);
           }

         break;

       case TDIClientURL:
  
         #define TestStrSz 100000
  
         pLclStr = (pTDIClientTestStr)malloc(TestStrSz);

         if (NULL==pLclStr)
           {
            printf("  " JARtnName ".main():  Failed to get buffer, quitting\n");
            break;
           }

         memset(pLclStr, 0, TestStrSz);               // Clear buffer (for eventual printf).

         memcpy(pLclStr,                              // Copy parameter structure at buffer beginning.
                &lclTDIClientTestStr,
                sizeof(TDIClientTestStr)
               );

         bFlag = CallDriver(
                            hDevice,
                            TDIClient_TEST2,
                            (PBYTE)pLclStr,
                            sizeof(TDIClientTestStr),
                            (PBYTE)pLclStr,
                            TestStrSz
                           );

         if (TRUE==bFlag)
           {
            if (0==pLclStr->rc)
              {
               printf("  Number of bytes received = %d\n", pLclStr->ulBuffer);
               printf("  Data = ***>>>\n\n%s\n\n<<<***\n", pLclStr->Buffer);

              }
            else
              printf("  " JARtnName ".main():  IOCTL rc = 0x%08x\n", pLclStr->rc);
           }


         free(pLclStr);

         break;

       case TDIClientDNS:
  
         #define TestDNSStrSz 1000
  
         pLclStr = (pTDIClientTestStr)malloc(TestDNSStrSz);

         if (NULL==pLclStr)
           {
            printf("  " JARtnName ".main():  Failed to get buffer, quitting\n");
            break;
           }

         memset(pLclStr, 0, TestDNSStrSz);            // Clear buffer.

         memcpy(pLclStr,                              // Copy parameter structure at buffer beginning.
                &lclTDIClientTestStr,
                sizeof(TDIClientTestStr)
               );

         strcpy(pLclStr->InDNServerIPAddr,            // Copy DNS address.
                dfltDNSIPAddr
               );

         bFlag = CallDriver(
                            hDevice,
                            TDIClient_TEST3,
                            (PBYTE)pLclStr,
                            sizeof(TDIClientTestStr),
                            (PBYTE)pLclStr,
                            TestDNSStrSz
                           );

         if (TRUE==bFlag)
           {
            if (0==pLclStr->rc)                       // OK?
              {
               printf("  Number of data bytes received = %d\n", pLclStr->ulBuffer);

               ShowNSData((pMyDNSQuery)pLclStr->Buffer);
              }
            else                                      // Some problem.
              printf("  " JARtnName ".main():  IOCTL rc = 0x%08x\n", pLclStr->rc);

              #define STATUS_CANCELLED  0xC0000120    // Derived from ntstatus.h.

              if (STATUS_CANCELLED==pLclStr->rc)      // Cancelled (presumably time out)?
                printf("  " JARtnName ".main():           = STATUS_CANCELLED, presumably timed out\n");
           }

         free(pLclStr);

         break;

       default:
         printf("  " JARtnName ".main():  Unsupported command\n");

         break;
      }                                               // End switch(CmdNbr).

    CloseHandle(hDevice);
   }                                                  // End if(flag).
 else
   {
    printf("  " JARtnName ".main():  OpenDevice result = not OK\n");
    rc = rcError;
   }

ExitPoint:
  if (TRUE==bHaveWSA)                                 // Got winsock resources?
    WSACleanup();

 return rc;
}                                                     // End main().

/**************************************************************************************************/      
/*                                                                                                */      
/**************************************************************************************************/      
BOOL
OpenDevice(
           IN LPCTSTR   DriverName,
           PHANDLE      phDevice
          )
{
 TCHAR    completeDeviceName[64] = "\\\\.\\";
 HANDLE   hDevice;
 DWORD    lclError;

 // Create a \\.\XXX device name that CreateFile can use.

 strcat(completeDeviceName,
        DriverName
       );

 hDevice = CreateFile(
                      completeDeviceName,
                      GENERIC_READ | GENERIC_WRITE,
                      0,
                      NULL,
                      OPEN_EXISTING,
                      FILE_ATTRIBUTE_NORMAL,
                      NULL
                     );

 if (hDevice==INVALID_HANDLE_VALUE)                 // hDevice = -1 if failure.
   {
    lclError = GetLastError();                      // Get more information.
    return FALSE;
   }

 // If user wants the handle, give it to him.  Otherwise, just close it.

 if ( phDevice )
   *phDevice = hDevice;
 else
   CloseHandle( hDevice );

 return TRUE;
}                                                   // End OpenDevice().

/**************************************************************************************************/      
/*                                                                                                */      
/* Sends a DeviceIoControl to the driver along with some data.                                    */      
/*                                                                                                */      
/**************************************************************************************************/      
BOOL
CallDriver(
           HANDLE inHandle,
           int    Msg,
           PBYTE  pInData,
           int    InDataLen,
           PBYTE  pOutData,
           int    OutDataLen
          )
{
 DWORD   ErrorCode,
         nb;
 BOOL    bResult,
         bFlag;
                                                                     
 if (
     TDIClient_TEST==Msg
       ||
     TDIClient_TEST2==Msg
       ||
     TDIClient_TEST3==Msg
    )
   {
    bResult = DeviceIoControl(
                              inHandle,
                              Msg,
                              pInData,
                              InDataLen,
                              pOutData,
                              OutDataLen,
                              &nb,
                              NULL
                             );
   }
 else
   {
    printf("  " JARtnName "().CallDriver():  Unknown code = %08xx\n", Msg);
    bFlag = FALSE;                                                                
        
    goto done;  
   }
                                                                     
 if (TRUE==bResult)                                                                     
   bFlag = TRUE;                                                                 
 else                                                                     
   {
    ErrorCode = GetLastError();
    printf("  " JARtnName "().CallDriver():  ErrorCode = %08xx\n", ErrorCode);
     
    bFlag = FALSE;                                                                
   }
                                                                     
done:
 return bFlag;                                                      
}                                                     // End CallDriver().
 

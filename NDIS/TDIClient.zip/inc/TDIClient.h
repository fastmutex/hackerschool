//**************************************************************************************************//
//*                                                                                                *//
//* Copyright (C) 2003, James Antognini, antognini@mindspring.com.                                 *//
//*                                                                                                *//
//**************************************************************************************************//

#define JADrvNm          "TDIClient"
#define JADrvNmW        L"TDIClient"
 
#define wcharTcpDevName L"\\Device\\Tcp" 
#define wcharUdpDevName L"\\Device\\Udp" 
 
#define arraysize(p) (sizeof(p)/sizeof((p)[0]))
 
#define TDIClnDNSPort   53
 
#ifdef JADriverKernelMode
  
#define DrvTestWait(prefix)                           /* Wait for signalling, after saying where event is located. */ \
                                                      /* Parameter prefix may be "" but otherwise prefixes message.*/ \
          {                                                                                                           \
           KEVENT tmpEvent;                                                                                           \
           KeInitializeEvent(&tmpEvent, NotificationEvent, FALSE);                                                    \
           DbgPrint((prefix "Event at 0x%08X, and waiting ...\n",&tmpEvent));                                         \
           KeWaitForSingleObject(&tmpEvent, Executive, KernelMode, FALSE, 0);                                         \
          }
  
#define INVALID_HANDLE_VALUE ((HANDLE)(LONG_PTR)-1)
 
#if DBG
#define DbgPrint(arg) DbgPrint arg
#else
#define DbgPrint(arg)
#endif

//***************************************************************************//
//                                                                           //
// Types, definitions, etc.                                                  //
//                                                                           //
//***************************************************************************//

typedef struct _TDIClnReqElem                         // TDI request element.
  {
   KEVENT                RecvEvent;                   // Event associated with Receive request.
   PCHAR                 pBuffer;                     // Addr of buffer for request.
   ULONG                 ulBuffer;                    // Size of buffer.
   ULONG                 ulBytesReceived;             // Number of bytes received, set by TDIClnEventReceive() or TDIClnIoCompRtnRecv().
   IO_STATUS_BLOCK       ReqIoStatus;                 // I/O status block.
  }
   TDIClnReqElem, * pTDIClnReqElem;
                                                      
// Next fixes a problem (C2501) in the _TDIClnConn typdef struct.

typedef struct _TDI_CONNECTION_INFORMATION * PTDI_CONNECTION_INFORMATION;

typedef struct _TDIClientExtension * pTDIClientExtension;

typedef struct _TDIClnConn
  {                                                   // Connection structure.
   pTDIClientExtension   pDevExt;                     // Pointer to device extension of TDI client.
   HANDLE                hConn;                       // Handle to connection endpoint.
   PFILE_OBJECT          pConnFileObj;                // Address of file object for connection endpoint.
   PTDI_CONNECTION_INFORMATION                        // Not used.
                         pServerConnInfo;
   PTDI_CONNECTION_INFORMATION                        // Client connection information
                         pClientConnInfo;
   pTDIClnReqElem        pReqElemsArr;                // Pointer to array of request elements.
   KEVENT                AccEvent;
   KEVENT                DiscEvent;
   LONG                  IdxReqElemAvail;             // Index of first available request element.
   BOOLEAN               bConnd;
  }
   TDIClnConn, * pTDIClnConn;

typedef struct _ConnParms
  {
   pTDIClientExtension   pDevExt;
   PTDI_CONNECTION_INFORMATION
                         pServerConnInfo;
   PTDI_CONNECTION_INFORMATION
                         pClientConnInfo;
  }
   ConnParms, * pConnParms;

typedef struct _TDIClientExtension                    // Device extension of TDI client.
  {
   UNICODE_STRING        JAUniSymLinkName;
   UNICODE_STRING        JAUniDeviceName;
   UNICODE_STRING        JARegPath;
   ANSI_STRING           JADriverName;
   PIRP                  pIrpAccept;
   HANDLE                hAddr;
   PDEVICE_OBJECT        pTcpDevObj;
   PDEVICE_OBJECT        pUdpDevObj;
   PFILE_OBJECT          pAddrFileObj;
   PCHAR                 pBufferBase;
   pTDIClnReqElem        pReqElemsArr;
   pTDIClnConn           pTDIClnConnArr;
   ULONG                 DNSIPAddr[4];
  }
   TDIClientExtension, * pTDIClientExtension;

//***************************************************************************//
//                                                                           //
// Routine prototypes.                                                       //
//                                                                           //
//***************************************************************************//

typedef struct _TDIClientExtension * pTDIClientExtension;

typedef struct _TDIClientTestStr * pTDIClientTestStr;

NTSTATUS
TDIClientDispatchAny(IN PDEVICE_OBJECT, IN PIRP);

NTSTATUS
TDIClientMain(IN pTDIClientExtension, IN pTDIClientTestStr);

VOID
TDIClientUnload(IN PDRIVER_OBJECT);

ULONG
GetInetAddr(IN LPWSTR, OUT LPWSTR *); 

NTSTATUS
TDIClnOpenTransAddr(PWSTR, PHANDLE, PFILE_OBJECT *, USHORT);

NTSTATUS
TDIClnOpenConnEndPt(pTDIClnConn, pTDIClientExtension);

NTSTATUS
TDIClnSetEventHandler(PFILE_OBJECT, PDEVICE_OBJECT, LONG, PVOID, PVOID);

NTSTATUS
TDIClnAssocAddr(PFILE_OBJECT, PDEVICE_OBJECT, HANDLE);

NTSTATUS                              
TDIClnDisassocAddr(PFILE_OBJECT, PDEVICE_OBJECT);

NTSTATUS
TDIClnConnect(PFILE_OBJECT, PDEVICE_OBJECT, ULONG, USHORT);

NTSTATUS
TDIClnSend(PFILE_OBJECT, PDEVICE_OBJECT, PVOID, ULONG);

NTSTATUS
TDIClnRecv(PFILE_OBJECT, PDEVICE_OBJECT, PVOID, ULONG, PIO_STATUS_BLOCK, PVOID);

NTSTATUS                                     
TDIClnSendDGram(PFILE_OBJECT, PDEVICE_OBJECT, PTDI_CONNECTION_INFORMATION, PVOID, ULONG);                            
                   
NTSTATUS                                     
TDIClnRecvDGram(PFILE_OBJECT, PDEVICE_OBJECT, PTDI_CONNECTION_INFORMATION, PVOID, ULONG, PIO_STATUS_BLOCK);                           
                   
NTSTATUS
TDIClnDisconnect(PFILE_OBJECT, PDEVICE_OBJECT);

// Next fixes a problem (C2501) in the TDIClnEventDisconnect definition.
typedef PVOID CONNECTION_CONTEXT;

NTSTATUS
TDIClnEventDisconnect(PVOID, CONNECTION_CONTEXT, LONG, PVOID, LONG, PVOID, ULONG);

NTSTATUS                             
TDIClnEventConnect(PVOID, LONG, PVOID, LONG, PVOID, LONG, PVOID, CONNECTION_CONTEXT *, PIRP *);

NTSTATUS
TDIClnEventErrorEx(PVOID, NTSTATUS, PVOID);

NTSTATUS
TDIClnEventReceive(PVOID, CONNECTION_CONTEXT, ULONG, ULONG, ULONG, PULONG, PVOID, PIRP *);

NTSTATUS                          
TDIClnIoCompRtnRecv(PDEVICE_OBJECT, PIRP, PVOID);

NTSTATUS                                          
TDIClnIoCompRtnRecvDGram(PDEVICE_OBJECT, PIRP, PVOID);

NTSTATUS                          
TDIClnIoCompRtnAcc(PDEVICE_OBJECT, PIRP, PVOID);

NTSTATUS                     
HTTPFetch(IN pTDIClientExtension, IN pTDIClientTestStr, IN OUT PULONG);  

NTSTATUS                                       
NSLookup(IN pTDIClientExtension, IN pTDIClientTestStr, IN OUT PULONG);

NTSTATUS
GetNSInfo(pTDIClientExtension);   

#endif                                                // End #ifdef JADriverKernelMode.
  
#define FILE_DEVICE_TDIClient      0x00008A00
 
#define TDIClient_TEST  (ULONG) CTL_CODE(FILE_DEVICE_TDIClient,    \
                                         0x01,                     \
                                         METHOD_BUFFERED,          \
                                         FILE_ANY_ACCESS           \
                                        )                          
                                                                 
#define TDIClient_TEST2 (ULONG) CTL_CODE(FILE_DEVICE_TDIClient,    \
                                         0x02,                     \
                                         METHOD_BUFFERED,          \
                                         FILE_ANY_ACCESS           \
                                        )                          
                                                                 
#define TDIClient_TEST3 (ULONG) CTL_CODE(FILE_DEVICE_TDIClient,    \
                                         0x03,                     \
                                         METHOD_BUFFERED,          \
                                         FILE_ANY_ACCESS           \
                                        )                          
                                                                 
typedef enum
  {
   TDIClientUnknown,
   TDIClientClient,
   TDIClientServer,
   TDIClientURL,
   TDIClientDNS 
  }
   TDIClientOperType;

#define DNSTimeoutValue    5                          // 5 seconds.

#define charDfltRmtAddr    "192.168.1.5" 
#define charDfltServerAddr "192.168.1.2" 
#define charDfltPort       "5004" 
 
#define NSLookupQueryId    0x4a41 
 
#define GetNetwkAddr(a, b, c, d)                      /* Get address in network form; eg, GetNetwkAddr(192, 168, 1, 5) => 0x0501a8c0. */ \
          (a + (b<<8) + (c<<16) + (d<<24))
 
#define GetNetwkAddrDw(a)                             /* Get address of a doubleword (4 bytes) in network form; */ \
                                                      /* eg, GetNetwkAddrDw(-xc0a80105) => 0x0501a8c0.          */ \
          (((a&0xFF)<<24) + ((a&0xFF00)<<8) + ((a&0xFF0000)>>8) + ((a&0xFF000000)>>24))  

#define GetNetwkPort(a)                               /* Get port in network form; eg, GetNetwkPort(5004) => 0x8c13. */ \
          (((0xFF&a)<<8) + ((0xFF00&a)>>8))
 
#define TDIClientPort           5004
#define TDIClientRecvBfrLen     1024
#define TDIClnUDPBfrMaxLen       512                  /* Per RFC 1035, page 32. */
#define TDIClnLabelMaxLen         63                  /* Label is a one-byte length field followed by that number of bytes. */
                                                      /*   63 is per RFC 1035, page 8.                                      */
#define TDIClnHostAddr             1                  /* Host address. 1 (called "A") is per RFC 1035, page 12. */
#define TDIClnCanonicalName        5                  /* Canonical name for an alias.  5 (called "CNAME") is per RFC 1035, page 12. */
#define TDIClnDomainNameMaxLen   255                  /* 255 is per RFC 1035, page 8. */
#define TDIClnDNSInternetClass     1                  /* 1 (called "Internet") is per RFC 1035, page 13. */
 
typedef unsigned long ULONG;
typedef unsigned short USHORT;

typedef struct _TDIClientTestStr
  {
   ULONG             rc;                              // Return code.
   ULONG             ulBuffer;                        // Number of bytes returned in Buffer below (fields before Buffer not counted).
   ULONG             ulKernelSent;                    // Total number of bytes kernel routine sent.
   ULONG             ulKernelReceived;                // Total number of bytes kernel routine received.
   TDIClientOperType InOperType;                      // Operation.
   char              InDestAddr[256];                 // IP address or IP name, depending on operation.
   char              InDestPort[8];
   char              InDNServerIPAddr[16];
   char              InURIResource[64];
   char              Buffer[1];
  }
   TDIClientTestStr, * pTDIClientTestStr;
  
typedef struct _myDNSQuery                                                                                                            
  {                                                                                                                                   
   USHORT             QueryId;                                                                                                        
   union                                                                                                                              
     {                                                                                                                                
      USHORT          QueryFields;                                                                                                    
      struct                                                                                                                          
        {                                                                                                                             
         // Note:  These bit fields are reversed from the big-endian mapping of RFC 1035 but will yield, via the MS x86 compiler,
         //        the desired big-endian mapping.

         USHORT       RecursDesired : 1;              // 1 ==> recursion desired.
         USHORT       Truncd        : 1;              // 1 ==> message truncated.  Meaningful only in responses.
         USHORT       AuthAnsw      : 1;              // 1 ==> authoritative answer.  Meaningful only in responses.
         USHORT       OpcodeFd      : 4;              // 0 ==> standard query.
         USHORT       QryReqFd      : 1;              // 0 ==> query; 1 ==> response.
         USHORT       RespCode      : 4;              // Response code:  0 ==> success;
                                                      //                 1 ==> format error;
                                                      //                 2 ==> server error;
                                                      //                 3 ==> name error;
                                                      //                 4 ==> not implemented;
                                                      //                 5 ==> refused.
         USHORT       ZReserved     : 3;              // Reserved.
         USHORT       RecursAvail   : 1;              // 1 ==> recursion available in server.
        };
     };
   USHORT             QuestionCnt;                    // Number of entries in question section.
   USHORT             AnswerCount;                    // Number of resource records (RRs) in answer section.
   USHORT             NSRRCount;                      // Number of name-server RRs in authority-records section.
   USHORT             AddRRCount;                     // Number of RRs in addition records section.
   char               QuestionSec[1];                 // Beginning of question section.
  }
   MyDNSQuery, * pMyDNSQuery;

// Map codes in RespCode above.

#define TDIClnRespCodeOK             0
#define TDIClnRespCodeFmtErr         1 
#define TDIClnRespCodeSvrErr         2 
#define TDIClnRespCodeNameErr        3 
#define TDIClnRespCodeNotImplErr     4 
#define TDIClnRespCodeRefusedErr     5 

typedef struct _MyDNSRR                               // Map resource record (RR) AFTER name field, which may be a name
  {                                                   //   or an offset to a name.
   USHORT             RRType;                         // RR type code.
   USHORT             RRClass;                        // Class of data in RRData.
   ULONG              RRTTL;                          // Time to live, in seconds.
   USHORT             RRDataLn;                       // Size of RRData.
   char               RRData[1];                      // Response record data.  Interpretation depends on RRType and RRClass.
  }                                                                                                                                   
   MyDNSRR, * pMyDNSRR;                                                                                                               

#define TDIClnCanonRRLen (2 +                             /* Length relative pointer */    \
                          FIELD_OFFSET(MyDNSRR, RRData) + /* Length of fixed RR fields */  \
                         2)                               /* Length of relative pointer */

#define TDIClnAddrRRLen  (2 +                             /* Length relative pointer */   \
                          FIELD_OFFSET(MyDNSRR, RRData) + /* Length of fixed RR fields */ \
                         4)                               /* Length of IP address. */

//***************************************************************************//
//                                                                           //
// User-space routine prototypes.                                            //
//                                                                           //
//***************************************************************************//

void
ShowNSData(pMyDNSQuery);


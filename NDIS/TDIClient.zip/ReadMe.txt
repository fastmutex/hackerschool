This is a demonstration of a TDI client driver.  It has been tested on WinXP and, to some extent, on Win2K.  This is not a
complete server vis-a-via a remote client (like WinsockClient, below) or a complete client vis-a-vis a remote server (like
WinsockServer, below); it is rather a demonstration of the TDI functions that probably would employed in such a complete
kernel application.  As a consequence, there are a few peculiarities, assumptions or shortcuts in the code, things that would
not appear in a complete application.  As much as possible, these peculiarities, etc, have been identified in comments.

These files are included:

  .\ReadMe.txt -- This file.
  .\TDIClient.cpp -- Main driver file (eg, DriverEntry, dispatch routines, unload routine).
  .\TDIClientRtns.cpp -- Driver subroutines for TDI.  Includes TDIClientMain, which acts as a client or a server to
       WinsockServer or WinsockClient, respectively.  Further includes subroutiens invoked by HTTPFetch and NSLookup.
  .\HTTPFetch.cpp -- Driver subroutine to get a Web page via HTTP.  See "Using HTTPFetch" below.
  .\NSLookup.cpp -- Driver subroutine to get DNS information.  See "Using NSLookup" below.
  .\GetNSInfo.cpp -- Driver subroutine to get DNS information from the registry, stored in NIC subkeys.  May be called by NSLookup.
  .\Utils.cpp -- Driver subroutine for TDI.
  .\inc\TDIClient.h -- Driver include file.  Used also in building WinsockServer.cpp and WinsockClient.cpp.
  .\TDIClient.dsw -- VC++ workspace to build driver (points to TDIClient.dsp and TalkTDIClient.dsp).
  .\TDIClient.dsp -- VC++ project file to build driver.  Note:  The VC++ build assumes that one has separately obtained
      Mark Roddy's ddkbuild.bat (see www.hollistech.com) and set it up.
  .\sources -- File that prescribes how to build driver.
  .\makefile --  File used in nmake.
  .\TalkTDIClient.cpp -- User-state program to drive TDI client bind, connection, etc.
  .\TalkTDIClient.dsp -- VC++ project for TalkTDIClient.cpp.
  .\ShowNSData.cpp -- User-state subroutine to display DNS information returned from kernel.  Called by TalkTDIClient.
  JA.pgm\src\C\Misc\WinsockSample\Server\WinsockServer.cpp -- User-state program to exchange data with TDI client driver or
      with WinsockClient.cpp.
  JA.pgm\src\C\Misc\WinsockSample\Client\WinsockClient.cpp -- User-state program to exchange data with WinsockServer.cpp.
      Does pretty much what TDI client driver in TDIClientRtns does.
  JA.pgm\src\C\Misc\WinsockSample\Client\WinsockDNSClient.cpp -- User-state program to get DNS information.  Does pretty much
      what NSLookup does.
  JA.pgm\src\C\Misc\WinsockSample\Client\WinsockHTTPClient.cpp -- User-state program to get a Web page.  Does pretty much
      what HTTPFetch does.
  JA.pgm\src\C\Misc\WinsockSample\WinsockSample.dsw -- VC++ workspace file that points to Server.dsp and Client.dsp.
  JA.pgm\src\C\Misc\WinsockSample\Server\WinsockServer.dsp -- VC++ project file to build WinsockServer.cpp.
  JA.pgm\src\C\Misc\WinsockSample\Client\WinsockClient.dsp -- VC++ project file to build WinsockClient.cpp.
  JA.pgm\src\C\Misc\WinsockSample\Client\WinsockHTTPClient.dsp -- VC++ project file to build WinsockHTTPClient.cpp.
  JA.pgm\src\C\Misc\WinsockSample\Client\WinsockDNSClient.dsp -- VC++ project file to build WinsockDNSClient.cpp.

Note:  The driver code can be built to employ a Receive event handler, or not.  See "More on building the driver" below.

Installing the driver --

  Let's assume that the executable is c:\JA.pgm\src\c\drivers\libfre_wxp_x86\i386\tdiclient.sys.  Using InstallDriver.exe (see
  InstallDriver.zip under the same directory as that where you obtained TDIClient.zip), go to the directory where both
  InstallDriver.exe and TDIClient.sys have been placed and do (you must be an administrator for this to succeed):

    InstallDriver TDIClient load

  Build WinsockServer, eg, by the VC++ project Server.  Build WinsockClient. Build TalkTDIClient.  Then follow the scenario for
  the client role or for the server role, given below.

  Note:  A desktop firewall may interfere with function of TDIClient.  It may be necessary to turn off the firewall or to set
  up appropriate rules (the form of the rules will depend on the firewall).

The TDI client in its client role (that is, as client to a remote server) --

  In the scenario running the TDI client as a client, using port 5001 on the remote system (assuming the TDI client driver has
  been loaded on system 192.168.1.2), the TDI client connects, sends and receives.  Thus:

    1) On system 192.168.1.5 (actually, this could be on system 192.168.1.2), run (in a command window):

         WinsockServer port 5001

       The program will display

         WinsockServer v1.43 (compiled 21 Apr 2003 11:50:33)
           Using port = 5001

       and will wait.

    2) On system 192.168.1.2, run (in a command window):

         TalkTDIClient client 192.168.1.5 5001

       The program will display:

         TalkTDIClient v1.29 (compiled 21 Apr 2003 01:04:57)
           Instructions:  Client opening IP addr = 192.168.1.5, port = 5001

       and almost immediately thereafter:

         Total bytes sent in kernel = 217, received in kernel = 309

    3) On system 192.168.1.5, in the command window one will see:
                                                                                                                          
         WinsockServer:  Received from client =
           ***>>>Hello from TDIClientMain() v2.25 (compiled 21 Apr 2003 10:50:18)<<<***
         WinsockServer:  Received from client =
           ***>>>Hello number 2 from TDIClient driver<<<***
         WinsockServer:  Received from client =
           ***>>>Hello from TDIClient driver number 3<<<***
         WinsockServer:  Received from client =
           ***>>>Hello number 4 from TDIClient driver<<<***
         WinsockServer:  Received from client =
           ***>>>Hello from TDIClient driver number 5<<<***
         WinsockServer:  Finished receiving data

         WinsockServer:  Total received from client = 217

         WinsockServer:  About to send a total of 309 bytes to client

       and in a debugging session of system 192.168.1.2 (eg, via windbg; and assuming the TDI client driver was created in a
       checked build), one will see:

         TDIClient TDIClientRtns.TDIClnPerformReceives:  For i = 0, received data = >This is a first (1) message from the Winsock server v1.43 (compiled 21 Apr 2003 11:50:33).<
         TDIClient TDIClientRtns.TDIClnPerformReceives:  For i = 1, received data = >This is a second (2) message from the Winsock server.<
         TDIClient TDIClientRtns.TDIClnPerformReceives:  For i = 1, received data = >This is a third (3) message from the Winsock server.<
         TDIClient TDIClientRtns.TDIClnPerformReceives:  For i = 1, received data = >This is a fourth (4) message from the Winsock server.<
         TDIClient TDIClientRtns.TDIClnPerformReceives:  For i = 1, received data = >This is a fifth (5) message from the Winsock server.<

The TDI client in its server role (that is, as server to a remote client) --

  In the scenario running the TDI client in its server role, using port 5003 on its own system (assuming the TDI client
  driver has been loaded on system 192.168.1.2), the TDI client listens, receives and sends.  Thus:

    1) On system 192.168.1.2, run (in a command window):

         TalkTDIClient server . 5003

       The program will display:

         TalkTDIClient v1.29 (compiled 21 Apr 2003 01:04:57)
           Instructions:  Server listening on port 5003

       and will wait.

    2) On system 192.168.1.5, run (in a command window):

         winsockclient . 192.168.1.2 5003

       The program will display:

         WinsockClient v1.50 (compiled 21 Apr 2003 11:58:51)
           Using IP address = 192.168.1.2, port = 5003

       and, almost immediately,

         WinsockClient:  About to send a total of 309 bytes to server

         WinsockClient:  Received from server =
           >Hello from TDIClientMain() v2.25 (compiled 21 Apr 2003 10:50:18)<
         WinsockClient:  Received from server =
           >Hello number 2 from TDIClient driver<
         WinsockClient:  Received from server =
           >Hello from TDIClient driver number 3<
         WinsockClient:  Received from server =
           >Hello number 4 from TDIClient driver<
         WinsockClient:  Received from server =
           >Hello from TDIClient driver number 5<
         WinsockClient:  Finished receiving data

         WinsockClient:  Total received from server = 217

       and in a debugging session of system 192.168.1.2 (eg, via windbg; and assuming the TDI client driver was created in a
       checked build), one will see:

         TDIClient TDIClientRtns.TDIClnPerformReceives:  For i = 0, received data = >This is a first (1) message from the Winsock client v1.50 (compiled 21 Apr 2003 11:58:51).<
         TDIClient TDIClientRtns.TDIClnPerformReceives:  For i = 1, received data = >This is a second (2) message from the Winsock client.<
         TDIClient TDIClientRtns.TDIClnPerformReceives:  For i = 1, received data = >This is a third (3) message from the Winsock client.<
         TDIClient TDIClientRtns.TDIClnPerformReceives:  For i = 1, received data = >This is a fourth (4) message from the Winsock client.<
         TDIClient TDIClientRtns.TDIClnPerformReceives:  For i = 1, received data = >This is a fifth (5) message from the Winsock client.<

       and in the command window on system 192.168.1.2, one will see:

         Total bytes sent in kernel = 217, received in kernel = 309

Unloading and uninstalling the driver --

  In a command window, do

    InstallDriver TDIClient unload

More on building the driver --

  By default, the TDI client driver uses explicit Receive operations and does not use the Receive event handler.  To use the
  Receive event handler (and not to do explicit Receives), do this in the command window where the driver is to be built:

    set C_DEFINES=-DUseRecvHandler=TRUE
   
  and then do a complete rebuild,  namely,
   
    build -cef
   
  If it is is desired to build in VC++ with the same effect, the sources file must be changed (since there is no command
  window): 
   
    C_DEFINES=$(C_DEFINES) -DUseRecvHandler=TRUE

  and then a complete rebuild must be done.

Using HTTPFetch --

  HTTPFetch in the driver can get a Web page and return it to user space.  HTTPFetch can be invoked via TalkTDIClient, as in
  this example to get the page named /us/ at www.ibm.com:

    TalkTDIClient URL www.ibm.com . /us/

Using NSLookup --

  NSLookup in the driver can get domain name-server information from a DNS.  The DNS may be specified in the request for the
  information or may be obtained from registry information.  To invoke the function:

    TalkTDIClient DNS www.ibm.com

  Note:  At present, there is no parameterized method of supplying the DNS IP address.  This address comes either from 
  hard-coded information in TalkTDIClient or, if not supplied there, from registry information (NIC entries under the TcpIp
  service) obtained by the kernel routine.


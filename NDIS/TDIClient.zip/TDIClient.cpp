//****************************************************************************//
//*                                                                           //
//* Copyright (C) 2003, James Antognini, antognini@mindspring.com.            //
//*                                                                           //
//****************************************************************************//

/**************************************************************************************************/      
/*                                                                                                */      
/*                                                                                                */      
/**************************************************************************************************/      

#define JADriverVersion "1.36"                                                                  
                                                                                                
#ifdef __cplusplus  // C++ conversion.                                                          
extern "C"                                                                                      
{                                                                                               
#endif              // End #ifdef C++ conversion.                                               
                                                                                                
#include <ntddk.h>
                                                                                                
#define  JADriverKernelMode 1                         // Ensure kernel pieces available.        
#include "TDIClient.h"                                                                             
                                                                                                
#ifdef __cplusplus  // C++ conversion.                                                          
}                                                                                               
#endif              // End #ifdef C++ conversion.                                               

//****************************************************************************//
//*                                                                           //
//* Globals.                                                                  //
//*                                                                           //
//****************************************************************************//

#define CompDateTimeStr "dd mmm yyyy hh:mm:ss"      
                                                    
char DrvCompileInfo[sizeof(CompDateTimeStr)+1];

PDEVICE_OBJECT  pPermDevObj = NULL,
                pTDIClientDevObj = NULL;
 
PDRIVER_OBJECT  pTDIClientObj = NULL;

//***************************************************************************//
//*                                                                         *//
//* DriverEntry.                                                            *//
//*                                                                         *//
//***************************************************************************//
extern "C"
NTSTATUS
DriverEntry(
            IN PDRIVER_OBJECT  pDriverObject,
            IN PUNICODE_STRING pRegistryPath
           )
{
 NTSTATUS                        status = STATUS_SUCCESS;
 UNICODE_STRING                  DeviceNameUniString,
                                 DeviceLinkUniString,
                                 DriverName,
                                 WkUniStr;
 PDEVICE_OBJECT                  pDevObj = NULL;
 pTDIClientExtension             pDevExt;
 ULONG                           i;
 BOOLEAN                         bHaveSymLink = FALSE,
                                 bHaveRegPath = FALSE;
 WCHAR                    static backslash = L'\\',   // Delimiter in Unicode.          
                                 constDeviceName[] = L"\\Device\\",                 
                                 constDeviceLink[] = L"\\DosDevices\\";   
 PWSTR                           pIdx;
 ANSI_STRING                     LclDrvName;
 char                     static DateCompiledBase[] = __DATE__,                                                                             
                                 TimeCompiledBase[] = " "__TIME__;                                                                             
 char                            DateCompiled[] =     // Build date in preferred (dd mmm yyyy) format.                                      
                                   {DateCompiledBase[4], DateCompiledBase[5], DateCompiledBase[6],                         
                                    DateCompiledBase[0], DateCompiledBase[1], DateCompiledBase[2], DateCompiledBase[3],
                                    DateCompiledBase[7], DateCompiledBase[8], DateCompiledBase[9], DateCompiledBase[10],
                                    0x0
                                   };

 if (' '==DateCompiled[0])
  strcpy(DrvCompileInfo, DateCompiled+1);
 else
  strcpy(DrvCompileInfo, DateCompiled+0);

 strcat(DrvCompileInfo, TimeCompiledBase);

 DbgPrint((JADrvNm " v" JADriverVersion " (compiled %s)\n", DrvCompileInfo));

// DbgPrint((JADrvNm " " JADrvRtnsName " v" JADrvRtnsVer " (compiled %s)\n",
//         NSLookupCompileInfo));

 // Invoke an attached debugger.  If there's none, continue.

 _try                                                 // Per Mark Roddy, comp.os.ms-windows.programmer.nt.kernel-mode, 27 Apr 2001.
    {
     DbgBreakPoint();
    }
     _except(EXCEPTION_EXECUTE_HANDLER)
      {
      }

 DeviceNameUniString.Buffer = NULL;                   // Ensure safe exit by branch to label 'done'.
 DeviceLinkUniString.Buffer = NULL;                   // "
 LclDrvName.Buffer = NULL;                            // "

 if (!NT_SUCCESS(status)) goto done;

 // Find the driver name in the registry path information.  The following assumes the string to be searched ends with a
 // backslash followed by 1 or more WCHARs that are the Unicode name.
  
 for (                                                // Find last delimiter by working back from end.       
      pIdx =                                          // Point to last WCHAR in buffer.                      
        pRegistryPath->Buffer + (pRegistryPath->Length / sizeof(WCHAR)) - 1;
      ;
      pIdx--                                          // Decrement by WCHAR width.                           
     )                                                                                                       
   if (backslash==*pIdx)                              // Is current WCHAR a delimiter?                       
     break;                                                                                                 

 // Build Unicode descriptor of driver name.
  
 pIdx++;                                              // Point to just after backslash.
  
 DriverName.Length = pRegistryPath->Length -          // Calculate length.
                     ((pIdx - pRegistryPath->Buffer) * sizeof(WCHAR)); 
  
 DriverName.MaximumLength = DriverName.Length +       // Figure in length of terminator.
                            sizeof(WCHAR);
 DriverName.Buffer = pIdx;                            // Point to driver name.

 status = RtlUnicodeStringToAnsiString(               // Get driver name in ansi.
                                       &LclDrvName,   // Descriptor.
                                       &DriverName,   // Unicode string to convert.
                                       TRUE           // Allocate space (which must be freed later).
                                      );

 if (!NT_SUCCESS(status))                             // A problem?
   {
    DbgPrint((JADrvNm " DriverEntry:  Failed to convert driver name!\n"));
    goto done;
   }

 DeviceNameUniString.Length = 0;                      // Show current length of device name.

 DeviceNameUniString.MaximumLength =                  // Show maximum length of device name.
   sizeof(constDeviceName) -
   sizeof(WCHAR)           +                          // Don't need size of first terminator (that is, terminator of constDeviceName).
   DriverName.MaximumLength;

 DeviceNameUniString.Buffer =                         // Get space for device name and for ASCII driver name.
   (PWSTR)ExAllocatePoolWithTag(
                                PagedPool,
                                DeviceNameUniString.MaximumLength,
                                'xxJA'
                               );

 if (NULL==DeviceNameUniString.Buffer)                // Failed to get storage? 
   {
    DbgPrint(("%s DriverEntry:  Failed to get storage for device name!\n", LclDrvName.Buffer));
    goto done;
   }

 // Now build proper device name, eg, '\Device\Driver'.

 RtlAppendUnicodeToString(                            // Initialize by appending L"\\Device\\" to empty string.
                          &DeviceNameUniString,
                          constDeviceName
                         );

 RtlAppendUnicodeStringToString(                      // Append driver name.
                                &DeviceNameUniString,
                                &DriverName
                               );
                                
 // Set up the device.

 status = IoCreateDevice(
                         pDriverObject,
                         sizeof(TDIClientExtension),
                         &DeviceNameUniString,
                         FILE_DEVICE_UNKNOWN,         // Per Walt Oney, p 403.
                         0,
                         FALSE,                       // Not exclusive.
                         &pDevObj
                        );

 if (FALSE==NT_SUCCESS(status))                       // A problem?
   {
    DbgPrint(("%s DriverEntry:  Failed to create the device, rc = 0x%08X!\n", LclDrvName.Buffer, status));
    goto done;
   }

// DbgPrint(("%s DriverEntry:  Device at 0x%p\n", LclDrvName.Buffer, pDevObj));

 pPermDevObj = pDevObj;                               // Save device address in module's global storage.

 // Extension will have been zeroed by OS.

 pDevExt = (pTDIClientExtension)pDevObj->DeviceExtension;

 pDevExt->JAUniDeviceName.Length =                    // Save length of Unicode driver name.
   DeviceNameUniString.Length;                                                            
 pDevExt->JAUniDeviceName.MaximumLength =             // Save maximum length of Unicode driver name.
   DeviceNameUniString.MaximumLength;                                                            
 pDevExt->JAUniDeviceName.Buffer =                    // Save address of Unicode driver name.
   DeviceNameUniString.Buffer;                                                                   
   
 memcpy(&pDevExt->JADriverName,                       // Copy ANSI-string descriptor.
        &LclDrvName,
        sizeof(pDevExt->JADriverName)
       );
   
 // Create a symbolic link to gain access to this driver/device, eg, '\DosDevices\Driver'.

 DeviceLinkUniString.Buffer =                         // Get space for symbolic link name.
   (PWSTR)ExAllocatePoolWithTag(           
                                PagedPool,
                                sizeof(constDeviceLink) +
                                  DriverName.Length,
                                'xxJA'
                               );

 if (NULL==DeviceLinkUniString.Buffer)                // Failed to get storage? 
   {
    DbgPrint(("%s DriverEntry:  Failed to get storage for device link!\n", LclDrvName.Buffer));

    goto done;
   }

 DeviceLinkUniString.Length = 0;                      // Show current length.
 DeviceLinkUniString.MaximumLength =                  // Show maximum length.
   sizeof(constDeviceLink) -
   sizeof(WCHAR)           +                          // Don't need size of first terminator (that is, terminator of constDeviceLink).
   DriverName.MaximumLength;

 RtlAppendUnicodeToString(                            // Initialize by appending L"\\DosDevices\\" to empty string.
                          &DeviceLinkUniString,
                          constDeviceLink
                         );

 RtlAppendUnicodeStringToString(                      // Append driver name.
                                &DeviceLinkUniString,
                                &DriverName
                               );
                                
 status = IoCreateSymbolicLink(
                               &DeviceLinkUniString,
                               &DeviceNameUniString
                              );

 if (FALSE==NT_SUCCESS(status))                       // A problem?
   {
    DbgPrint(("%s DriverEntry:  IoCreateSymbolicLink failed, rc = 0x%08X\n", LclDrvName.Buffer, status));

    goto done;
   }

 bHaveSymLink = TRUE;

 pDevExt->JAUniSymLinkName = DeviceLinkUniString;     // Copy descriptor.

 // Copy the registry path.   
   
 pDevExt->JARegPath.MaximumLength = pRegistryPath->Length + sizeof(UNICODE_NULL); 
 pDevExt->JARegPath.Length = pRegistryPath->Length; 
 pDevExt->JARegPath.Buffer = (PWSTR)ExAllocatePoolWithTag(PagedPool, pDevExt->JARegPath.MaximumLength, 'xxJA');   
   
 if (NULL==pDevExt->JARegPath.Buffer)                 // A problem?  
   {   
    DbgPrint(("%s DriverEntry:  Unable to allocate %d bytes for copy of registry key name\n",
              LclDrvName.Buffer,
              pRegistryPath->Length + sizeof(WCHAR)
             )
            );

    status = STATUS_INSUFFICIENT_RESOURCES;
    goto done;
   }   
   
 bHaveRegPath = TRUE;                                 // Remember storage allocated.
   
 RtlCopyUnicodeString(&pDevExt->JARegPath, pRegistryPath);  
   
 // Minimally support all types of IRP (taken from Walter Oney's "Programming the Microsoft Windows Driver Model,"
 // p 402).
   
 for (i = 0; i <= IRP_MJ_MAXIMUM_FUNCTION; i++)
   pDriverObject->MajorFunction[i] = TDIClientDispatchAny;

 pDriverObject->DriverUnload = TDIClientUnload;

// DbgPrint(("%s DriverEntry:  Initialization complete\n", LclDrvName.Buffer));

done:

 if (NT_SUCCESS(status))                              // No problem?
   {                                                
    pTDIClientObj = pDriverObject;
    pTDIClientDevObj = pDevObj;
   }
 else
   {
    if (TRUE==bHaveRegPath)                           // Copied registry path?
      ExFreePool(pDevExt->JARegPath.Buffer);

    if (TRUE==bHaveSymLink)                           // Symbolic link established?
      IoDeleteSymbolicLink(&DeviceLinkUniString);

    if (NULL!=DeviceLinkUniString.Buffer)             // Free working storage for symbolic link name.
      ExFreePool(DeviceLinkUniString.Buffer);

    if (NULL!=DeviceNameUniString.Buffer)             // Free working storage for device name.
      ExFreePool(DeviceNameUniString.Buffer);

    if (NULL!=LclDrvName.Buffer)                      // Free working storage for ansi driver name.
      RtlFreeAnsiString(&LclDrvName);

    if (NULL!=pDevObj)                                // Was a device object created?
      {
       pPermDevObj = NULL;                            // Be neat.

       IoDeleteDevice(pDevObj);
      }
   }

 return status;
}

/**************************************************************************************************/
/*                                                                                                */
/**************************************************************************************************/
NTSTATUS
TDIClientDispatchAny(
                     IN PDEVICE_OBJECT pDevObj,
                     IN PIRP           pIrp
                    )
{
 PCHAR static pType[] =
                {
                 "IRP_MJ_CREATE",
                 "IRP_MJ_CREATE_NAMED_PIPE",
                 "IRP_MJ_CLOSE",
                 "IRP_MJ_READ",
                 "IRP_MJ_WRITE",
                 "IRP_MJ_QUERY_INFORMATION",
                 "IRP_MJ_SET_INFORMATION",
                 "IRP_MJ_QUERY_EA",
                 "IRP_MJ_SET_EA",
                 "IRP_MJ_FLUSH_BUFFERS",
                 "IRP_MJ_QUERY_VOLUME_INFORMATION",
                 "IRP_MJ_SET_VOLUME_INFORMATION",
                 "IRP_MJ_DIRECTORY_CONTROL",
                 "IRP_MJ_FILE_SYSTEM_CONTROL",
                 "IRP_MJ_DEVICE_CONTROL",
                 "IRP_MJ_INTERNAL_DEVICE_CONTROL",
                 "IRP_MJ_SHUTDOWN",
                 "IRP_MJ_LOCK_CONTROL",
                 "IRP_MJ_CLEANUP",
                 "IRP_MJ_CREATE_MAILSLOT",
                 "IRP_MJ_QUERY_SECURITY",
                 "IRP_MJ_SET_SECURITY",
                 "IRP_MJ_POWER",
                 "IRP_MJ_SYSTEM_CONTROL",
                 "IRP_MJ_DEVICE_CHANGE",
                 "IRP_MJ_QUERY_QUOTA",
                 "IRP_MJ_SET_QUOTA",
                 "IRP_MJ_PNP",
                 "IRP_MJ_PNP_POWER",
                 "IRP_MJ_MAXIMUM_FUNCTION"
                };
 NTSTATUS                status = STATUS_SUCCESS,
                         lclStatus;
 PIO_STACK_LOCATION      pIrpStack;
 pTDIClientExtension     pDevExt =                    // Address of device object extension.
                           (pTDIClientExtension)pDevObj->DeviceExtension;
 PVOID                   pOutBuffer;
 ULONG                   lenOutBuffer,
                         IoControlCode;

 pIrp->IoStatus.Status      = STATUS_SUCCESS;
 pIrp->IoStatus.Information = 0;

 pIrpStack = IoGetCurrentIrpStackLocation(pIrp);

 pTDIClientTestStr pInTestStr = (pTDIClientTestStr)pIrp->AssociatedIrp.SystemBuffer;

 if (pIrpStack->MajorFunction<=IRP_MJ_MAXIMUM_FUNCTION)
   {
    DbgPrint(("%s DispatchAny:  IRP type = %s.\n", pDevExt->JADriverName.Buffer, pType[pIrpStack->MajorFunction]));
   }
 else
   {
    DbgPrint(("%s DispatchAny:  Unknown Irp type = %0X02x.\n", pDevExt->JADriverName.Buffer, pIrpStack->MajorFunction));
   }

 //pInBuffer     = pIrp->AssociatedIrp.SystemBuffer;    // Point to input buffer.
 //lenInBuffer   =                                      // Length of input buffer.
 //  pIrpStack->Parameters.DeviceIoControl.InputBufferLength;
 //pOutBuffer    = pIrp->AssociatedIrp.SystemBuffer;    // Point to output buffer.

 lenOutBuffer  =                                      // Length of output buffer.
   pIrpStack->Parameters.DeviceIoControl.OutputBufferLength;
 IoControlCode =                                      // Get IOCTL internal code.
   pIrpStack->Parameters.DeviceIoControl.IoControlCode;

 switch(pIrpStack->MajorFunction)
   {
    case IRP_MJ_DEVICE_CONTROL:

      switch(IoControlCode)
        {
         case TDIClient_TEST:

           // Note:  No test that input/output buffer is of proper length.

           lclStatus = TDIClientMain(
                                     pDevExt,
                                     pInTestStr
                                    );

           pIrp->IoStatus.Information =               // Set size to be copied back to caller.
             sizeof(TDIClientTestStr);

           pInTestStr->rc = lclStatus;                // Set return code for caller.

           break;

         case TDIClient_TEST2:

           lclStatus = HTTPFetch(
                                 pDevExt,
                                 pInTestStr,
                                 &lenOutBuffer
                                );

           pIrp->IoStatus.Information = lenOutBuffer; // Set size to be copied back to caller.

           break;

         case TDIClient_TEST3:

           lclStatus = NSLookup(
                                pDevExt,
                                pInTestStr,
                                &lenOutBuffer
                               );

           pIrp->IoStatus.Information = lenOutBuffer; // Set size to be copied back to caller.

           break;

         default:

           DbgPrint(("%s DispatchAny:  Unknown internal IOCTL type = 0x%08x\n", pDevExt->JADriverName.Buffer, IoControlCode));
        }

    default:
      ;
   }

 IoCompleteRequest(pIrp, IO_NO_INCREMENT);

 return status;
}

/**************************************************************************************************/
/*                                                                                                */
/**************************************************************************************************/
VOID
TDIClientUnload(IN PDRIVER_OBJECT pDrvObj)
{
 NTSTATUS                status;
 pTDIClientExtension     pDevExt =                    // Address of device object extension.
                           (pTDIClientExtension)pPermDevObj->DeviceExtension;

 DbgPrint(("%s Unload:  Unloading\n", pDevExt->JADriverName.Buffer));

 ExFreePool(pDevExt->JARegPath.Buffer);

 IoDeleteSymbolicLink(&pDevExt->JAUniSymLinkName);    // Delete symbolic link.

 ExFreePool(pDevExt->JAUniSymLinkName.Buffer);

 ExFreePool(pDevExt->JAUniDeviceName.Buffer);
  
 RtlFreeAnsiString(&pDevExt->JADriverName);

 IoDeleteDevice(pDrvObj->DeviceObject);               // Delete device object.
}


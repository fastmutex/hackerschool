//****************************************************************************//
//*                                                                           //
//* Copyright (C) 2003, James Antognini, antognini@mindspring.com.            //
//*                                                                           //
//****************************************************************************//

/**************************************************************************************************/      
/*                                                                                                */      
/* Adapted from                                                                                   */
/* ms-help://MS.MSDNQTR.2002JUL.1033/wcewinsk/htm/_wcecomm_TCP_Stream_Socket_Client.htm.          */
/*                                                                                                */      
/**************************************************************************************************/      

#define JAProgNm      "WinsockDNSClient"
#define JAProgVersion "1.00"  

#include <winsock2.h>
#include <windows.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <process.h>
#include <commctrl.h>
#include <winioctl.h>

#include "TDIClient.h"

#define charDfltDNSServerAddr "207.69.188.186"
#define charDfltDNSPort       "53"

PUCHAR
CopyNextStanza(IN PUCHAR pInData, OUT PUCHAR pStr)
  {
   PUCHAR pNextAvail;

   do
     {
      UCHAR tmpName[63+1+1],
            ulChar = *pInData;                        // Pick up length field. 

      if (0==ulChar)                                  // Zero?
        {
         pNextAvail = NULL;
         break;
        }

      memcpy(tmpName, pInData+1, ulChar);             // Copy partial name to temp.

      tmpName[ulChar] = '.';                          // Append a period
      tmpName[ulChar+1] = 0;                          //   and a null terminator.

      strcat((char *)pStr, (char *)tmpName);          // Copy from temp to permanent.

      pNextAvail = pInData +                          // Point to next available byte in permanent.
                   strlen((char *)tmpName);
     }
      while(0);

   return pNextAvail;
  }

int main(
         IN int    nbrArgs,
         IN char * pArgv[]
        )
{
  #define rcOK         0
  #define rcError      8

  #define CmdUnknown   0
  #define CmdStart     1
  #define CmdStop      2
  #define CmdTest      3
  #define CmdTest2     4

  static struct
    {
     DWORD CmdCode;
     char * pInStr;
    }
     InStrArr[] =
       {                                              // Except that CmdUnknown has to be first, the following can be in any order.
        {CmdUnknown, ""},
        {CmdTest,   "DNSServer"},
        {CmdTest2,  "."},
       };

  char             static dfltIPAddr[] =              // Default IP address.
                            charDfltDNSServerAddr,
                          dfltPort[] =                // Default port.
                            charDfltDNSPort,
                          dfltName[] = "www.ibm.com",
                          DateCompiledBase[] = __DATE__,
                          TimeCompiledBase[] = " "__TIME__,
                          JAProgInfo[] = JAProgNm " v" JAProgVersion " (compiled ";

  #define CompDateTimeStr "dd mmm yyyy hh:mm:ss"      

  char                    DateCompiled[12] =          // Build date in preferred (dd mmm yyyy) format.
                            {DateCompiledBase[4], DateCompiledBase[5], DateCompiledBase[6],
                             DateCompiledBase[0], DateCompiledBase[1], DateCompiledBase[2], DateCompiledBase[3],
                             DateCompiledBase[7], DateCompiledBase[8], DateCompiledBase[9], DateCompiledBase[10],
                             0x0
                            },
                          szClientA[TDIClientRecvBfrLen],
                          PgmCompiledInfo[sizeof(CompDateTimeStr)+1];
  char                  * pIPAddr,     
                        * pPort;       
  int rcRecv,                         // Return value of recv function
      port,                           // Port to use.
      i,
      rc = rcOK,
      lnInStrArr =                    // Get number of instances.          
        sizeof InStrArr / sizeof InStrArr[0],                           
      lclStatus,
      sendLn,
      CmdNbr = CmdUnknown;
  BOOL bFirst = TRUE;

  SOCKET ServerSock = INVALID_SOCKET; // Socket bound to the server
  SOCKADDR_IN destination_sin;        // Server socket address
  PHOSTENT pHostEnt = NULL;           // Points to the HOSTENT structure of the server
  WSADATA WSAData;                    // Contains details of the Winsocket implementation
  PUSHORT pShort;

  char * pBuffer = NULL,
       * pQuestData;

  typedef struct _myDNSQuery
    {
     USHORT            QueryId;
     union
       {
        USHORT         QueryFields;
        struct
          {
           USHORT      RecursDesired : 1;             // 1 ==> recursion desired.
           USHORT      Truncd        : 1;             // 1 ==> message truncated.  Meaningful only in responses.
           USHORT      AuthAnsw      : 1;             // 1 ==> authoritative answer.  Meaningful only in responses.
           USHORT      OpcodeFd      : 4;             // 0 ==> standard query.
           USHORT      QryReqFd      : 1;             // 0 ==> query; 1 ==> response.
           USHORT      RespCode      : 4;             // Response code:  0 ==> success;
                                                      //                 1 ==> format error; 
                                                      //                 2 ==> server error; 
                                                      //                 3 ==> name error; 
                                                      //                 4 ==> not implemented;
                                                      //                 5 ==> refused.
           USHORT      ZReserved     : 3;             // Reserved.
           USHORT      RecursAvail   : 1;             // 1 ==> recursion available in server.
          };
       };
     USHORT            QuestionCount;                 // Number of entries in question section.
     USHORT            AnswerCount;                   // Number of resource records (RRs) in answer section.
     USHORT            NSRRCount;                     // Number of name-server RRs in authority-records section.
     USHORT            AddRRCount;                    // Number of RRs in addition records section.
     char              Question[1];                   // Beginning of question section.
    }
     myDNSQuery, * pMyDNSQuery;

  typedef struct _myDNSRR                             // Map response AFTER name field, which may be a name or an offset to a name.
    {
     USHORT            RRType;                        // RR type code.
     USHORT            RRClass;                       // Class of data in RRData.
     ULONG             RRTTL;                         // Time to live, in seconds.
     USHORT            RRRDataLn;                     // Size of RRData.
     char              RRData[1];                     // Response record data.  Interpretation depends on RespType and RespClass.
    }
     myDNSRR, * pMyDNSRR;

  pMyDNSQuery pQryData,
              pRspData;

  pMyDNSRR    pRRData;

  if (' '==DateCompiled[0])
   strcpy(PgmCompiledInfo, DateCompiled+1);
  else
   strcpy(PgmCompiledInfo, DateCompiled+0);

  strcat(PgmCompiledInfo, TimeCompiledBase);

  printf("%s%s)\n", JAProgInfo, PgmCompiledInfo);

  if (nbrArgs>=2)
    {
     for (i = 1; i < lnInStrArr; i ++)                // Go through expected parameters.
       if (0==_stricmp(pArgv[1], InStrArr[i].pInStr)) // Does the second parm match?
         break;                                       // If yes, break.
    }
  else
    i = lnInStrArr;                                   // Ensure next conditional yields supported parameter information.

  if (i<lnInStrArr)                                   // Found a supported command?
    {
     CmdNbr = InStrArr[i].CmdCode;
     if (CmdTest2==CmdNbr)                            // Dot given?
       CmdNbr = CmdTest;                              // Use full command.
    }
  else
    {
     printf("\nUnsupported command\n\n");
     printf("Usage: " JAProgNm " <operand>\n\n");
     printf("       where <operand> is one of these:\n\n");
     for (i = 1; i < lnInStrArr; i ++)
       printf("         %s\n", InStrArr[i].pInStr);
     printf("\n       Eg,\n\n         <DNSServer  | . <IP address | IP name | .> <port | .>>\n");
     printf("\n       (Capitalization is ignored.)\n");
     printf("\n       (Defaults:  IP addr = %s, port = %s.)\n", dfltIPAddr, dfltPort);

     rc = 1;
     goto ExitPoint;
    }

  if (nbrArgs>=3)
    {
     pIPAddr = pArgv[2];                              // Get IP address.
     if (0==strcmp(pIPAddr, "."))                     // Dot given?
       pIPAddr = dfltIPAddr;                          // Point to default IP address.
    }
  else
    pIPAddr = dfltIPAddr;                             // Get IP address.

  if (4==nbrArgs)
    {
     pPort = pArgv[3];                                // Get port.
     if (0==strcmp(pPort, "."))                       // Dot given?
       pPort = dfltPort;                              // Point to default port.
    }
  else
    pPort = dfltPort;                                 // Get port.

  port = atoi(pPort);                                 // Convert ascii to integer.

  printf("   Using IP address = %s, port = %d\n", pIPAddr, port);

  // Initialize Winsocket. 
  if (0!=WSAStartup(MAKEWORD(2, 0), &WSAData))        // Accept up to Winsock 2.0.
  {
    printf(JAProgNm ":  WSAStartup failed.  Error = %d\n", WSAGetLastError());
    return 1;
  }

  // Create a UDP/IP socket that is bound to the server.
  if (INVALID_SOCKET==(ServerSock = socket(AF_INET, SOCK_DGRAM, 0)))
  {
    printf(JAProgNm ":  Allocating socket failed.  Error = %d\n", WSAGetLastError());
    return 1;
  }

  // Fill out the server socket's address information.
  destination_sin.sin_family = AF_INET;

  // Retrieve the host information corresponding to the host name.
  if (NULL==(pHostEnt = gethostbyname(pIPAddr))) 
  {
    printf(JAProgNm ":  Unable to get the host name.  Error = %d\n", WSAGetLastError ());
    closesocket (ServerSock);
    return 1;
  }

  // Assign the socket IP address.
  memcpy((char FAR *)&(destination_sin.sin_addr), 
         pHostEnt->h_addr, 
         pHostEnt->h_length
        );

  // Convert to network ordering.
  destination_sin.sin_port = htons(port);

  // Establish a connection to the server socket.
  if (SOCKET_ERROR==connect(ServerSock, 
                            (PSOCKADDR)&destination_sin, 
                            sizeof(destination_sin)
                           )
     )
  {
    ULONG error = WSAGetLastError();
    printf(JAProgNm ":  Connecting to the server failed.  Error = %d%s\n", error, WSAECONNREFUSED==error ? " (connection refused)" : "");
    closesocket(ServerSock);
    return 1;
  }

  // Send data to the server.

  #define UDPBfrSz 128

  sendLn = UDPBfrSz;

  pBuffer = (char *)malloc(sendLn);                   // Get a buffer.

  if (NULL==pBuffer)                                  // No good?
    {
     printf(JAProgNm ":  Couldn't allocate buffer, quitting\n");
     goto CloseSocket;
    }

  pQryData = (pMyDNSQuery)pBuffer;                    // Point to query.

  memset(pQryData, 0, UDPBfrSz);                      // Zero area.

  pQryData->QueryId = GetNetwkPort(2);                // Set query id (nominal).

  pQryData->RecursDesired = TRUE;                     // Show recursion OK.

  pQryData->QuestionCount = GetNetwkPort(1);          // Set number of queries.

  pQuestData = ((char *)pQryData) +                   // Point to question area.
               FIELD_OFFSET(myDNSQuery, Question);

  *(PUCHAR)pQuestData = 3;                            // Set length of first piece.

  memcpy(pQuestData+1, "www", strlen("www"));
                                                      
  *(PUCHAR)(pQuestData+4) = 3;                        // Set length of second piece.

  memcpy(pQuestData+5, "ibm", strlen("ibm"));

  *(PUCHAR)(pQuestData+8) = 3;                        // Set length of third piece.

  memcpy(pQuestData+9, "com", strlen("com"));

  pShort = (PUSHORT)((PUCHAR)pQuestData + 13);        // Point past question area.

  *pShort = GetNetwkPort(1);                          // Set QNAME.
   
  *(pShort+1) = GetNetwkPort(1);                      // Set QTYPE.
   
  sendLn = FIELD_OFFSET(myDNSQuery, Question) +       // Get total length.
           strlen(pQuestData) + 1             +
           2                                  +
           2;

  printf(JAProgNm ":  Sending %d bytes\n", sendLn);

  lclStatus = send(ServerSock,                        // Send datagram.
                   pBuffer,
                   sendLn,
                   0
                  );

  if (SOCKET_ERROR==lclStatus)
    {
     printf(JAProgNm ":  Sending data to the server failed.  Error = %d\n", WSAGetLastError());
     goto CloseSocket;
    }

  pRspData = (pMyDNSQuery)szClientA;                  // Point to response area.

  // Receive data from the server socket.
  rcRecv = recv(ServerSock, (char *)pRspData, sizeof(szClientA), 0);

  // Check if there is any data received. If there is, display it.
  if (SOCKET_ERROR==rcRecv)
  {
    printf(JAProgNm ":  No data is received, recv failed.  Error = %d\n", WSAGetLastError());
  }
  else if (0==rcRecv)
  {
    printf(JAProgNm ":  Finished receiving data\n");
  }
  else
  {
    printf("\n\n" JAProgNm ":  Total received from server = %d\n", rcRecv);

    UCHAR FullName[64];

    USHORT NameOffset =                               // Get name offset, including 2 high-order bits.
             GetNetwkPort(* (PUSHORT) (((PUCHAR)pRspData)+sendLn) );

    NameOffset &= ~0xc000;                            // Turn off high-order 2 bits.

    PUCHAR pNameFd =                                  // Point to name.
             ((PUCHAR)pQryData) + FIELD_OFFSET(myDNSQuery, QueryId) + NameOffset,
           pPartName;

    pRRData =                                         // Point to RR field.
      (pMyDNSRR)(((PUCHAR)pRspData) + sendLn + 2);

    USHORT nbrAnswers =                               // Get number of RR fields.
             GetNetwkPort(pRspData->AnswerCount);

    for (                                             // Go through RR fields.
         ULONG i = 0;
         i < nbrAnswers;
         i ++
        )
      {
       FullName[0] = 0;

       pPartName = pNameFd;

       do
         {
          pPartName =                                 // Build name, piece by piece.
            CopyNextStanza(pPartName, FullName);
         }
           while(NULL!=pPartName);

       FullName[strlen((const char *)FullName)-1] = 0;// Replace final '.' with null terminator.

       char IPAddr[16],
            Octet1[4],
            Octet2[4],
            Octet3[4],
            Octet4[4];

       ULONG addr =                                   // Get IP address, converting it from network form.
               GetNetwkAddrDw(*(PULONG)pRRData->RRData);

       _ultoa(addr>>24,              Octet1, 10);       
       _ultoa((0x00ff0000&addr)>>16, Octet2, 10);
       _ultoa((0x0000ff00&addr)>>8,  Octet3, 10);
       _ultoa(0x000000ff&addr,       Octet4, 10);

       strcpy(IPAddr, Octet1);
       strcat(IPAddr, ".");
       strcat(IPAddr, Octet2);
       strcat(IPAddr, ".");
       strcat(IPAddr, Octet3);
       strcat(IPAddr, ".");
       strcat(IPAddr, Octet4);

       printf("Name = %s, IP addr = %s\n", FullName, IPAddr);

       pRRData =                                      // Point to next RR field.
         (pMyDNSRR) ( ((PUCHAR)pRRData) + FIELD_OFFSET(myDNSRR, RRData) +
                      4 +
                      2
                    );
      }

  }

CloseSocket:
  // Close the socket.
  closesocket(ServerSock);

  WSACleanup();

  if (NULL!=pBuffer)
    free(pBuffer);                                    // Free buffer.

ExitPoint:
  return 0;
}


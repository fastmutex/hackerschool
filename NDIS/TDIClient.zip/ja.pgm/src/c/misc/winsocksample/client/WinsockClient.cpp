//****************************************************************************//
//*                                                                           //
//* Copyright (C) 2003, James Antognini, antognini@mindspring.com.            //
//*                                                                           //
//****************************************************************************//

/**************************************************************************************************/      
/*                                                                                                */      
/* Adapted from                                                                                   */
/* ms-help://MS.MSDNQTR.2002JUL.1033/wcewinsk/htm/_wcecomm_TCP_Stream_Socket_Client.htm.          */
/*                                                                                                */      
/**************************************************************************************************/      

#define JAProgNm      "WinsockClient"
#define JAProgVersion "1.50"

#include <winsock2.h>
#include <windows.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <process.h>
#include <commctrl.h>
#include <winioctl.h>

#include "TDIClient.h"

int main(
         IN int    nbrArgs,
         IN char * pArgv[]
        )
{
  #define rcOK         0
  #define rcError      8

  #define CmdUnknown   0
  #define CmdStart     1
  #define CmdStop      2
  #define CmdTest      3
  #define CmdTest2     4

  static struct
    {
     DWORD CmdCode;
     char * pInStr;
    }
     InStrArr[] =
       {                                              // Except that CmdUnknown has to be first, the following can be in any order.
        {CmdUnknown, ""},
        {CmdTest,   "RmtServer"},
        {CmdTest2,  "."},
       };

  char             static dfltIPAddr[] =              // Default IP address.
                            charDfltServerAddr,
                          dfltPort[] = charDfltPort,  // Default port.
                          DateCompiledBase[] = __DATE__,
                          TimeCompiledBase[] = " "__TIME__,
                          JAProgInfo[] = JAProgNm " v" JAProgVersion " (compiled ";

  #define CompDateTimeStr "dd mmm yyyy hh:mm:ss"      

  char                    DateCompiled[12] =          // Build date in preferred (dd mmm yyyy) format.
                            {DateCompiledBase[4], DateCompiledBase[5], DateCompiledBase[6],
                             DateCompiledBase[0], DateCompiledBase[1], DateCompiledBase[2], DateCompiledBase[3],
                             DateCompiledBase[7], DateCompiledBase[8], DateCompiledBase[9], DateCompiledBase[10],
                             0x0
                            },
                          szClientA[TDIClientRecvBfrLen],
                          PgmCompiledInfo[sizeof(CompDateTimeStr)+1];
  char           static * pServerBoundMessage[] = {
                                                   "This is a first (1) message from the Winsock client v" JAProgVersion " (compiled ",
                                                   "This is a second (2) message from the Winsock client.",
                                                   "This is a third (3) message from the Winsock client.",
                                                   "This is a fourth (4) message from the Winsock client.",
                                                   "This is a fifth (5) message from the Winsock client."
                                                  };
  char                  * pIPAddr,     
                        * pPort;       
  int rcRecv,                         // Return value of recv function
      port,                           // Port to use.
      i,
      rc = rcOK,
      lnInStrArr =                    // Get number of instances.          
        sizeof InStrArr / sizeof InStrArr[0],                           
      TotalRecvd = 0,
      CmdNbr = CmdUnknown;
  BOOL bFirst = TRUE;
  ULONG ulTotalSend;                                  // Total number of bytes that will be sent.
//int TimeOutVal,
//    szVal,
//    statusSockCall;
//ULONG valDontBlock;

  SOCKET ServerSock = INVALID_SOCKET; // Socket bound to the server
  SOCKADDR_IN destination_sin;        // Server socket address
  PHOSTENT phostent = NULL;           // Points to the HOSTENT structure of the server
  WSADATA WSAData;                    // Contains details of the Winsocket implementation

  if (' '==DateCompiled[0])
   strcpy(PgmCompiledInfo, DateCompiled+1);
  else
   strcpy(PgmCompiledInfo, DateCompiled+0);

  strcat(PgmCompiledInfo, TimeCompiledBase);

  printf("%s%s)\n", JAProgInfo, PgmCompiledInfo);

  if (nbrArgs>=2)
    {
     for (i = 1; i < lnInStrArr; i ++)                // Go through expected parameters.
       if (0==_stricmp(pArgv[1], InStrArr[i].pInStr)) // Does the second parm match?
         break;                                       // If yes, break.
    }
  else
    i = lnInStrArr;                                   // Ensure next conditional yields supported parameter information.

  if (i<lnInStrArr)                                   // Found a supported command?
    {
     CmdNbr = InStrArr[i].CmdCode;
     if (CmdTest2==CmdNbr)                            // Dot given?
       CmdNbr = CmdTest;                              // Use full command.
    }
  else
    {
     printf("\nUnsupported command\n\n");
     printf("Usage: " JAProgNm " <operand>\n\n");
     printf("       where <operand> is one of these:\n\n");
     for (i = 1; i < lnInStrArr; i ++)
       printf("         %s\n", InStrArr[i].pInStr);
     printf("\n       Eg,\n\n         <RmtServer  | . <IP address | IP name | .> <port | .>>\n");
     printf("\n       (Capitalization is ignored.)\n");
     printf("\n       (Defaults:  IP addr = %s, port = %s.)\n", dfltIPAddr, dfltPort);

     rc = 1;
     goto ExitPoint;
    }

  if (nbrArgs>=3)
    {
     pIPAddr = pArgv[2];                              // Get IP address.
     if (0==strcmp(pIPAddr, "."))                     // Dot given?
       pIPAddr = dfltIPAddr;                          // Point to default IP address.
    }
  else
    pIPAddr = dfltIPAddr;                             // Get IP address.

  if (4==nbrArgs)
    {
     pPort = pArgv[3];                                // Get port.
     if (0==strcmp(pPort, "."))                       // Dot given?
       pPort = dfltPort;                              // Point to default port.
    }
  else
    pPort = dfltPort;                                 // Get port.

  port = atoi(pPort);                                 // Convert ascii to integer.

  printf("  Using IP address = %s, port = %d\n", pIPAddr, port);

  // Initialize Winsocket. 
  if (WSAStartup(MAKEWORD(2,0), &WSAData) != 0)       // Accept up to Winsock 2.0.
  {
    printf(JAProgNm ":  WSAStartup failed.  Error = %d\n", WSAGetLastError());
    return 1;
  }

  // Create a TCP/IP socket that is bound to the server.
  if ((ServerSock = socket(AF_INET, SOCK_STREAM, 0)) == INVALID_SOCKET)
  {
    printf(JAProgNm ":  Allocating socket failed.  Error = %d\n", WSAGetLastError());
    return 1;
  }

//statusSockCall = ioctlsocket(ServerSock,            // Make socket non-blocking.
//                             FIONBIO,
//                             &valDontBlock
//                            );
//
//if (0!=statusSockCall)
//  {
//   printf(JAProgNm ":  Failed in ioctlsocket(), rc = %d\n", WSAGetLastError());
//  }

//TimeOutVal = -1;
//szVal = sizeof(TimeOutVal);
//
//statusSockCall = getsockopt(ServerSock,
//                            SOL_SOCKET,
//                            SO_SNDTIMEO,
//                            (char*)&TimeOutVal,
//                            &szVal
//                           );
//
//if (0!=statusSockCall)
//  {
//   printf(JAProgNm ":  Failed in getsockopt(), rc = %d\n", WSAGetLastError());
//  }

  // Fill out the server socket's address information.
  destination_sin.sin_family = AF_INET;

  // Retrieve the host information corresponding to the host name.
  if ((phostent = gethostbyname (pIPAddr)) == NULL) 
  {
    printf(JAProgNm ":  Unable to get the host name.  Error = %d\n", WSAGetLastError ());
    closesocket (ServerSock);
    return 1;
  }

  // Assign the socket IP address.
  memcpy((char FAR *)&(destination_sin.sin_addr), 
         phostent->h_addr, 
         phostent->h_length);

  // Convert to network ordering.
  destination_sin.sin_port = htons(port);

  // Establish a connection to the server socket.
  if (connect (ServerSock, 
               (PSOCKADDR) &destination_sin, 
               sizeof (destination_sin)) == SOCKET_ERROR) 
  {
    ULONG error = WSAGetLastError();
    printf(JAProgNm ":  Connecting to the server failed.  Error = %d%s\n", error, WSAECONNREFUSED==error ? " (connection refused)" : "");
    closesocket (ServerSock);
    return 1;
  }

  // Behavior:  1) send loop.
  //            2) receive loop.

  // Send strings to the server.

  for (                                               // Add size of strings (including terminator), except for first.
       i = 1,
         ulTotalSend = 0;
       i < arraysize(pServerBoundMessage);
       i ++
      )
    ulTotalSend += strlen(pServerBoundMessage[i])+1;  

  // Send strings to the server.
  for (                                               // Send loop.
       i = 0;
       i < arraysize(pServerBoundMessage);
       i ++
      )
    {
     char * pBuffer;

     ULONG sendLn = strlen(pServerBoundMessage[i])+1; // Get size of current string, including terminator.

     if (0==i)                                        // First send?
       {
        sendLn += sizeof(ULONG)            +          // Add size of length field,
                  strlen(PgmCompiledInfo)  +          //   size of date/time compiled and
                  2;                                  //   size of closing parenthesis and period

        pBuffer = (char *)malloc(sendLn);             // Get a buffer.

        if (NULL==pBuffer)                            // No good?
          {
           printf(JAProgNm ":  Couldn't allocate buffer, quitting\n");
           goto DoShutdown;
          }

        ulTotalSend += sendLn;                        // Add size of first string.

        *(PULONG)pBuffer = ulTotalSend;               // Copy total amount to be sent.
        strcpy(pBuffer+sizeof(ULONG),                 // Copy fixed string.
               pServerBoundMessage[0]
              );
        strcat(pBuffer+sizeof(ULONG),                 // Append date/time compiled.
               PgmCompiledInfo
              );
        strcat(pBuffer+sizeof(ULONG), ").");          // Append closing parenthesis and period.

//      printf(JAProgNm ":  Sending %d bytes\n  >%s<\n", sendLn, pBuffer+sizeof(ULONG));

        printf("\n" JAProgNm ":  About to send a total of %d bytes to server\n\n", ulTotalSend);
       }
     else
       pBuffer = pServerBoundMessage[i];              // Point to fixed string.

//   printf(JAProgNm ":  Sending %d bytes\n  >%s<\n",  sendLn, pServerBoundMessage[i]);

     int lclStatus = send(ServerSock,
                          pBuffer,
                          sendLn,
                          0
                         );

     if (0==i)                                        // First send?
       free(pBuffer);                                 // Free buffer.

     if (SOCKET_ERROR==lclStatus)
       {
        printf(JAProgNm ":  Sending data #%d to the server failed.  Error = %d\n", i, WSAGetLastError());
       }
     else
       {
//      printf(JAProgNm ":  Sent %d bytes to the server\n", lclStatus);
       }
    }                                                 // End 'for' Send loop.

DoShutdown:
  // Disable sending on ServerSock.
  shutdown(ServerSock, SD_SEND);

  for (;;)
  {
    // Receive data from the server socket.
    rcRecv = recv(ServerSock, szClientA, sizeof(szClientA), 0);

    // Check if there is any data received. If there is, display it.
    if (SOCKET_ERROR==rcRecv)
    {
      printf(JAProgNm ":  No data is received, recv failed.  Error = %d\n", WSAGetLastError());
      break;
    }
    else if (0==rcRecv)
    {
      printf(JAProgNm ":  Finished receiving data\n");
      break;
    }
    else
    {
      TotalRecvd += rcRecv;                           // Accumulate total received.

      #define ServerMsgArraySz 10

      // It is assumed -- but not checked -- that in each receive there is at least 1 string and
      // that the total number of strings sent across receives does not exceed ServerMsgArraySz.

      char    * pSvrMsg[ServerMsgArraySz];
      int       msgCt = 0;
      BOOLEAN   bFindNextStr = TRUE;

      // Find strings (there may be more than one in the received data).
      for (int charIdx = 0; charIdx < rcRecv; charIdx ++)
        {
         if (TRUE==bFirst)                            // First string?
           {                                                                                                                                                                                        
            charIdx += sizeof(ULONG);                 // Bump past total byte count.                                                                                                                  
            bFirst = FALSE;                           // Turn flag off.                                                                                                                                                                                   
           }                                                                                                                                                                                        
                                                                                                                   
         if (TRUE==bFindNextStr)                      // Looking for a string?
           if (0!=szClientA[charIdx])                 // Is current byte not 0?
             {
              msgCt++;                                // Bump string count.
              pSvrMsg[msgCt-1] = &szClientA[charIdx]; // Point to current string.
              bFindNextStr = FALSE;                   // Remember now not looking for a string.
             }
           else
             ;
         else                                         // Handling a string.
           if (0==szClientA[charIdx])                 // Is current byte 0?
             bFindNextStr = TRUE;                     // Remember now looking for a string.
           else
             ;
        }

      for (int msgIdx = 0; msgIdx < msgCt; msgIdx ++)
        // Display the string(s) received from the server.
        printf(JAProgNm ":  Received from server = \n  >%s<\n", pSvrMsg[msgIdx]);
    }
  }

  printf("\n" JAProgNm ":  Total received from server = %d\n", TotalRecvd);

  // Disable receiving on ServerSock.
  shutdown(ServerSock, SD_RECEIVE);

  // Close the socket.
  closesocket(ServerSock);

  WSACleanup();

ExitPoint:
  return 0;
}


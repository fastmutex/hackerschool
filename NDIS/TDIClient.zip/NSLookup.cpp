//****************************************************************************//
//*                                                                           //
//* Copyright (C) 2003, James Antognini, antognini@mindspring.com.            //
//*                                                                           //
//****************************************************************************//

/******************************************************************************/      
/*                                                                            */      
/* Notes:                                                                     */      
/*                                                                            */      
/******************************************************************************/      

#define JADrvRtnsName   "NSLookup"
#define JADrvRtnsVer    "1.12"                                                                  
                                                                                                
#ifdef __cplusplus  // C++ conversion.                                                          
extern "C"                                                                                      
{                                                                                               
#endif              // End #ifdef C++ conversion.                                               
                                                                                                
#include <ntddk.h>
#include <tdikrnl.h>
                                                                                                
#define JADriverKernelMode     1                      // Ensure kernel pieces available.        
#include "TDIClient.h"                                                                             
                                                                                                
#ifdef __cplusplus  // C++ conversion.                                                          
}                                                                                               
#endif              // End #ifdef C++ conversion.                                               

#define TDIClnDNSRecvBfrLen TDIClnUDPBfrMaxLen

//****************************************************************************//
//*                                                                           //
//* Globals.                                                                  //
//*                                                                           //
//****************************************************************************//

#define CompDateTimeStr "dd mmm yyyy hh:mm:ss"

char NSLookupCompileInfo[sizeof(CompDateTimeStr)+1] = // Null in first character means not initialized.
       {0x0};

//****************************************************************************//
//*                                                                           //
//* Forward definitions of routines provided here.                            //
//*                                                                           //
//****************************************************************************//

NTSTATUS
NSLookupClient(pTDIClientExtension, PFILE_OBJECT, pTDIClnReqElem, pTDIClientTestStr);

NTSTATUS
NSLookupPerformSend(pTDIClientExtension, PFILE_OBJECT, PTDI_CONNECTION_INFORMATION, pTDIClnReqElem, ULONG, pTDIClientTestStr);

NTSTATUS
NSLookupPerformReceive(pTDIClientExtension, PFILE_OBJECT, PTDI_CONNECTION_INFORMATION, pTDIClnReqElem, ULONG);

NTSTATUS
BuildDNSQuery(PCHAR, PCHAR, PULONG);

/**************************************************************************************************/
/*                                                                                                */
/* Send a DNS-format datagram to a name server and return the results.                            */
/*                                                                                                */
/**************************************************************************************************/
NTSTATUS
NSLookup(
         pTDIClientExtension pDevExt,                 // Device extension.
         pTDIClientTestStr   pInStr,                  // Parameters from user space (via IOCTL).
         PULONG              pOutBufferSz             // Size of output buffer.
        )
{
 NTSTATUS                    status,
                             ExecStatus = STATUS_SUCCESS;
 pTDIClnReqElem              pReqElem = NULL;

 if (0==NSLookupCompileInfo[0])                       // Information string about compilation date and time not yet built?
   {
    char static DateCompiledBase[] = __DATE__,
                TimeCompiledBase[] = " "__TIME__;
    char        tmpDateCompileInfo[]   =              // Build date in preferred (dd mmm yyyy) format.
                  {DateCompiledBase[4], DateCompiledBase[5], DateCompiledBase[6],
                   DateCompiledBase[0], DateCompiledBase[1], DateCompiledBase[2], DateCompiledBase[3],
                   DateCompiledBase[7], DateCompiledBase[8], DateCompiledBase[9], DateCompiledBase[10],
                   0x0
                  };

    // Build date and time of compilation.

    if (' '==tmpDateCompileInfo[0])                   // Leading blank (ie, first through ninth day of month)?
      strcpy(NSLookupCompileInfo, tmpDateCompileInfo+1);
    else
      strcpy(NSLookupCompileInfo, tmpDateCompileInfo+0);
    strcat(NSLookupCompileInfo, TimeCompiledBase);
   }

 DbgPrint((JADrvNm " " JADrvRtnsName " v" JADrvRtnsVer " (compiled %s)\n",
           NSLookupCompileInfo));
 
 do {                                                 // Single-iteration loop, to make possible escape via break.
     pInStr->rc = STATUS_SUCCESS;                     // Presume success.
 
     ULONG lenOutputBfr = *pOutBufferSz;              // Save output buffer size.

     *pOutBufferSz = sizeof(TDIClientTestStr);        // Set minimum output size.

     pDevExt->hAddr = INVALID_HANDLE_VALUE;
     pDevExt->pAddrFileObj = NULL;

     //
     // Open transport address.
     //

     status = TDIClnOpenTransAddr(                    
                                  wcharUdpDevName,
                                  &pDevExt->hAddr,
                                  &pDevExt->pAddrFileObj,
                                  0
                                 );

     if (!NT_SUCCESS(status))                         // A problem?
       {
        pInStr->rc = status;
        break;
       }

     //
     // Get request element, buffer space.
     //

     pReqElem = (pTDIClnReqElem)ExAllocatePool(PagedPool, sizeof(TDIClnReqElem) + TDIClnDNSRecvBfrLen);

     if (NULL==pReqElem)                              // Didn't work?
       {
        DbgPrint((JADrvNm " " JADrvRtnsName ".NSLookup:  Failed to get request elements, quitting\n"));
        status =
          pInStr->rc =
            STATUS_INSUFFICIENT_RESOURCES;
        break;
       }

     PCHAR pBuffer = (PCHAR)pReqElem +                // Point to buffer.
                     sizeof(TDIClnReqElem);

     // Set up request element.

     memset(pReqElem, 0, sizeof(TDIClnReqElem));      // Clear element.
     pReqElem->pBuffer = pBuffer;                     // Point to buffer.
     pReqElem->ulBuffer = TDIClnDNSRecvBfrLen;        // Size of buffer.

     pDevExt->pUdpDevObj =                            // Point to UDP device object.
       IoGetRelatedDeviceObject(pDevExt->pAddrFileObj);

     //
     // Handle the requested operation.
     //

     ExecStatus = NSLookupClient(
                                 pDevExt,
                                 pDevExt->pAddrFileObj,
                                 pReqElem,            // Address of request element.
                                 pInStr
                                );

     //
     // Copy bytes into the output buffer.
     //

     if (
         STATUS_SUCCESS==ExecStatus                   // Success?
           &&
         pReqElem->ReqIoStatus.Information>0          // Something received?
        )                 
       {
        if (pReqElem->ReqIoStatus.Information>        // Not enough space left in output buffer?
              (lenOutputBfr-FIELD_OFFSET(TDIClientTestStr, Buffer))
           )
          {
           DbgPrint((JADrvNm " " JADrvRtnsName ".NSLookup:  Output buffer too small, quitting\n"));
           status =
             pInStr->rc =
               STATUS_INSUFFICIENT_RESOURCES;
           break;
          }

        memcpy(&pInStr->Buffer,                       // Copy data.
               pReqElem->pBuffer,
               pReqElem->ReqIoStatus.Information
              );

        pInStr->ulBuffer =                            // Show bytes copied into buffer.
          pReqElem->ReqIoStatus.Information;

        *pOutBufferSz =
          FIELD_OFFSET(TDIClientTestStr, Buffer) +    // Set size copied to size of structure up to but not including Buffer
          pReqElem->ReqIoStatus.Information;          //   plus bytes copied to Buffer.
       }
    } while(0);                                       // End 'do-while' single-iteration loop.

 if (NULL!=pReqElem)                                  // Got request element?
   ExFreePool(pReqElem);

 if (INVALID_HANDLE_VALUE!=pDevExt->hAddr)            // Opened transport address?
   {
    ZwClose(pDevExt->hAddr);
    pDevExt->hAddr = INVALID_HANDLE_VALUE;
   }

 if (NULL!=pDevExt->pAddrFileObj)                     // Referenced object?
   {
    ObDereferenceObject(pDevExt->pAddrFileObj);
    pDevExt->pAddrFileObj = NULL;
   }

 return STATUS_SUCCESS==status ? ExecStatus : status; // Return ExecStatus unless status!=STATUS_SUCCESS.
}                                                     // End NSLookup().

/**************************************************************************************************/
/*                                                                                                */
/* Perform functions as client to remote domain name server.                                      */
/*                                                                                                */
/**************************************************************************************************/
NTSTATUS
NSLookupClient(
               pTDIClientExtension   pDevExt,
               PFILE_OBJECT          pAddrFileObj,
               pTDIClnReqElem        pReqElem,        // Address of request element.
               pTDIClientTestStr     pInStr           // Parameters from user space (via IOCTL).
              )
{
 NTSTATUS                    status;

 do {                                                 // Single-iteration loop, to make possible escape via break.
     // The IP address of the domain name server is taken from the input parameters, if it was provided.  Otherwise,
     // the address is sought from the registry.

     ULONG DNServerAddr;

     USHORT ulDNSIPAddr =                             // Get length of supplied DNS IP address, if any.
              strlen(pInStr->InDNServerIPAddr);

     if (0!=ulDNSIPAddr)                              // Length of supplied DNS IP address not 0?
       {
        // Build the network form of the DNS IP address.

        ANSI_STRING AnsiDNServerAddr;

        AnsiDNServerAddr.Length = ulDNSIPAddr;
        AnsiDNServerAddr.MaximumLength = ulDNSIPAddr + 1;
        AnsiDNServerAddr.Buffer = pInStr->InDNServerIPAddr;

        UNICODE_STRING UniDNServerAddr;

        status = RtlAnsiStringToUnicodeString(&UniDNServerAddr, &AnsiDNServerAddr, TRUE);

        if (!NT_SUCCESS(status))
          {
           DbgPrint((JADrvNm " " JADrvRtnsName ".NSLookupClient:  Failed RtlAnsiStringToUnicodeString() # 1, status = 0x%08x, quitting\n",
                     status));

           pInStr->rc = status;
           break;
          }

        WCHAR * pOutW;

        DNServerAddr =                                // Get network-form address (translate octets to binary and swap positions).
          GetInetAddr(UniDNServerAddr.Buffer, &pOutW);

        RtlFreeUnicodeString(&UniDNServerAddr);       // Free allocated storage.
       }                                              // End 'if' Length of DNS IP address not 0.
     else
     if (0!=pDevExt->DNSIPAddr[0])                    // A DNS IP address already obtained from the registry?
       DNServerAddr = pDevExt->DNSIPAddr[0];          // Use it.
     else
       {
        status = GetNSInfo(pDevExt);                  // Try to get DNS IP address from the registry.
 
        if (STATUS_SUCCESS!=status)                   // A problem?
          { 
           DbgPrint((JADrvNm " " JADrvRtnsName ".NSLookupClient:  GetNSInfo() rc = 0x%08x, quitting\n", status));

           pInStr->rc = status;
           break;
          } 

        DNServerAddr = pDevExt->DNSIPAddr[0];         // Use DNS IP address just now obtained.
       }

     USHORT DNServerPort =                            // Get network-form port.                                                                
              GetNetwkPort(TDIClnDNSPort);
                                                                                                                                          
     TA_IP_ADDRESS RmtDNSIPAddr = {1,                                                         
                                   {TDI_ADDRESS_LENGTH_IP,                                    
                                    TDI_ADDRESS_TYPE_IP,                                      
                                    {DNServerPort, DNServerAddr}                                        
                                   }                                                          
                                  };                                                          
                                                                                      
     TDI_CONNECTION_INFORMATION RmtDNSInfo = {0, 0, 0, 0, sizeof(RmtDNSIPAddr), &RmtDNSIPAddr};

     ULONG ulBfr = pReqElem->ulBuffer;                // Size of buffer, which will be updated to size built.

     status = BuildDNSQuery(pInStr->InDestAddr, pReqElem->pBuffer, &ulBfr);

     if (!NT_SUCCESS(status))
       {
        status =
          pInStr->rc =
            STATUS_INSUFFICIENT_RESOURCES;
        break;
       }

     // Note:  Because the same buffers are used in Receive and Send, all Send operations must be complete
     //        before Receive operations commence, and vice-versa.

     //
     // Perform SendDatagram.
     //

     status = NSLookupPerformSend(
                                  pDevExt,
                                  pAddrFileObj,
                                  &RmtDNSInfo,
                                  pReqElem,           // Address of request element.
                                  ulBfr,
                                  pInStr
                                 );

     if (STATUS_SUCCESS!=status)                      // A problem?
       {
        pInStr->rc = status;
        break;
       }

     //
     // Perform ReceiveDatagram.
     //

     status = NSLookupPerformReceive(
                                     pDevExt,
                                     pAddrFileObj,
                                     &RmtDNSInfo,
                                     pReqElem,        // Address of request element.
                                     pReqElem->ulBuffer
                                    );

     if (STATUS_SUCCESS!=status)
       {
        pInStr->rc = status;
        break;
       }
    } while(0);                                       // End 'do-while' single-iteration loop.
  
 return status;
}                                                     // End NSLookupClient().

/**************************************************************************************************/
/*                                                                                                */
/* Perform Send Datagram.                                                                         */
/*                                                                                                */
/**************************************************************************************************/
NTSTATUS
NSLookupPerformSend(
                    pTDIClientExtension         pDevExt,
                    PFILE_OBJECT                pAddrFileObj,
                    PTDI_CONNECTION_INFORMATION pRmtDNSInfo,
                    pTDIClnReqElem              pReqElem,  // Address of request-element array.
                    ULONG                       sendLn,    // Length to send
                    pTDIClientTestStr           pInStr     // Parameters from user space (via IOCTL).
                   )
{
 NTSTATUS                    status = STATUS_SUCCESS;

 do {                                                 // Single-iteration loop, to make possible escape via break.
     status = TDIClnSendDGram(pAddrFileObj,
                              pDevExt->pUdpDevObj,
                              pRmtDNSInfo,
                              pReqElem->pBuffer,
                              sendLn
                             );

    } while(0);                                       // End 'do-while' single-iteration loop.
  
 if (STATUS_SUCCESS!=status)
   {
    DbgPrint((JADrvNm " " JADrvRtnsName ".NSLookupPerformSend:  Ending status = %lx\n", status));
   }
  
 return status;
}                                                     // End NSLookupPerformSend().

/**************************************************************************************************/
/*                                                                                                */
/* Perform Receive Datagram.                                                                      */
/*                                                                                                */
/**************************************************************************************************/
NTSTATUS
NSLookupPerformReceive(
                       pTDIClientExtension   pDevExt,
                       PFILE_OBJECT          pAddrFileObj,
                       PTDI_CONNECTION_INFORMATION
                                             pRmtDNSInfo,
                       pTDIClnReqElem        pReqElem,// Address of request element.
                       ULONG                 ulBfr    // Length of buffer pointed to by request element.
                      )
{
 NTSTATUS                    status;

 do {                                                 // Single-iteration loop, to make possible escape via break.
//   DbgPrint((JADrvNm " " JADrvRtnsName ".NSLookupPerformReceive:  About to start Receive Datagram\n"));

     status = TDIClnRecvDGram(pAddrFileObj,
                              pDevExt->pUdpDevObj,
                              pRmtDNSInfo,
                              pReqElem->pBuffer,      // Buffer to fill.
                              ulBfr,                  // Length of buffer.
                              &pReqElem->ReqIoStatus  // IoStatus.
                             );

     if (
         STATUS_SUCCESS!=status
           &&
         STATUS_PENDING!=status
        )
       {
        if (STATUS_INVALID_DEVICE_STATE!=status)      // Not (presumably) past last good Send/Receive?
          {
           DbgPrint((JADrvNm " " JADrvRtnsName ".NSLookupPerformReceive:  Receive status = %lx\n", status));
          }
        break;
       }

//   DbgPrint((JADrvNm " " JADrvRtnsName ".NSLookupPerformReceive:  Total bytes received = %d\n", ulDataRcvd));

    } while(0);                                       // End 'do-while' single-iteration loop.
  
 if (STATUS_SUCCESS!=status)
   {
    DbgPrint((JADrvNm " " JADrvRtnsName ".NSLookupPerformReceive:  Ending status = %lx\n", status));
   }
  
 return status;
}                                                     // End NSLookupPerformReceive().

/**************************************************************************************************/
/*                                                                                                */
/* Build the DNS query.  Refer to RFC 1035, especially pp 25-28, for details.                     */
/*                                                                                                */
/**************************************************************************************************/
NTSTATUS
BuildDNSQuery(
              PCHAR     pInIPName,                    // IP name that needs a DNS query built.
              PCHAR     pBuffer,                      // Buffer provided for building the query.
              PULONG    pUlBfr                        // Length of buffer provided.
             )
{
 NTSTATUS status = STATUS_SUCCESS;

 PCHAR pQuestData = pBuffer +                         // Point to what will be the question section.
                    FIELD_OFFSET(MyDNSQuery, QuestionSec);

 ULONG cumLen = pQuestData - pBuffer;                 // Get length of first part, up to question section.

 if (cumLen>*pUlBfr)                                  // Not enough space?
   {
    status = STATUS_INSUFFICIENT_RESOURCES;
    goto exit;
   }

 memset(pBuffer, 0, *pUlBfr);                         // Zero entire buffer. 

 pMyDNSQuery pQryData = (pMyDNSQuery)pBuffer;         // Point to buffer for building query, in front of question section.

 pQryData->QueryId = GetNetwkPort(NSLookupQueryId);   // Set query id (nominal value).

 // Several bits values are significant.  Two are zero:  That for query (versus response) and that for a standard query.

 pQryData->RecursDesired = TRUE;                      // Show recursion OK.  

 pQryData->QuestionCnt = GetNetwkPort(1);             // Set number of queries to 1.

 // Now build the question section, which follows the header information just set.

 PCHAR pOut = pQuestData,                             // Point to question section.
       pStr = pInIPName,                              // Point to beginning of the IP name.
       pStrLast = pStr + strlen(pStr);                // Point to last byte of the IP name, the null terminator.

 for (                                                // Build "DNS labels" or name segments (each a 1-byte length,
      ;                                               //   followed by that number of bytes).
      pStr<pStrLast;                                  // So long as at a point before null terminator.
     )
   {
    char lenDNSLabel;

    PCHAR pDot = strchr(pStr, '.');                   // Find next period in supplied IP name.

    if (NULL==pDot)                                   // None?
      lenDNSLabel = strlen(pStr);                     // Get remaining length.
    else
      lenDNSLabel = pDot - pStr;                      // Calculate length.

    cumLen += lenDNSLabel + 1;                        // Get cumulative length.

    if (cumLen>*pUlBfr)                               // Not enough space left?
      {
       status = STATUS_INSUFFICIENT_RESOURCES;
       goto exit;
      }

    *pOut = lenDNSLabel;                              // Set length of current DNS label.

    memcpy(pOut+1, pStr, lenDNSLabel);                // Copy current DNS label.

    pStr += lenDNSLabel + 1;                          // Bump pointer.
    pOut += lenDNSLabel + 1;                          // Ditto.
   }                                                  // End 'for' build DNS labels.

 if ((cumLen+1+2+2)>*pUlBfr)                          // Not enough space left for null plus QTYPE and QCLASS?
   {
    status = STATUS_INSUFFICIENT_RESOURCES;
    goto exit;
   }

 PUSHORT pShort = (PUSHORT)(pOut + 1);                // Point past question area, including final byte of 0 (the null, or root, label).

 *pShort = GetNetwkPort(TDIClnHostAddr);              // Set QTYPE to A (host address).

 *(pShort+1) = GetNetwkPort(TDIClnDNSInternetClass);  // Set QCLASS to IN (Internet).

 ULONG sendLn = cumLen +                              // Calculate length:  Length of "labels" (name segments)plus
                1      +                              //   length of concluding, null label plus
                2      +                              //   length of QTYPE plus
                2;                                    //   length of QCLASS.

 *pUlBfr = sendLn;                                    // Show length of result.

exit:
 return status;
}                                                     // End BuildDNSQuery().


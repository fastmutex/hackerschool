//****************************************************************************//
//*                                                                           //
//* Copyright (C) 2003, James Antognini, antognini@mindspring.com.            //
//*                                                                           //
//****************************************************************************//

/**************************************************************************************************/      
/*                                                                                                */      
/* Notes:                                                                                         */      
/*                                                                                                */      
/**************************************************************************************************/      

#define JARtnName         "ShowNSData"
#define JARtnVer          "1.03"

#include <windows.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <process.h>
#include <commctrl.h>
#include <winioctl.h>

#include "TDIClient.h"

/**************************************************************************************************/      
/*                                                                                                */      
/* Prototypes (forward defines).                                                                  */      
/*                                                                                                */      
/**************************************************************************************************/      

PUCHAR
  CopyNextNameSegment(PUCHAR, PUCHAR);

/**************************************************************************************************/      
/*                                                                                                */      
/* Consult TDIClient.h and RFC 1035, especially pages 8, 12, 13, 28 and 32, for clarification.    */      
/*                                                                                                */      
/**************************************************************************************************/      
void
ShowNSData(pMyDNSQuery pRspData)
{
 UCHAR FullName[TDIClnDomainNameMaxLen+1];            // Area to build name.
 ULONG i,
       nbrAnswers =                                   // Get number of RR fields.
         GetNetwkPort(pRspData->AnswerCount),
       ulQuery =                                      // Get length of data sent in query, and given back (as a header of sorts), namely:
         FIELD_OFFSET(MyDNSQuery, QuestionSec) +      //   Header in query. 
         strlen((PCHAR)pRspData +                     //   Length of name segments or "labels," each of which is 1-byte length followed by
                FIELD_OFFSET(MyDNSQuery, QuestionSec) //     that number of bytes.
               )                               +
         1                                     +      //   Length of null label or root-name segment (a 1-byte zero).
         2                                     +      //   Length of QTYPE.
         2;                                           //   Length of QCLASS.
 PUCHAR pCurrName = ((PUCHAR)pRspData) + ulQuery,     // Point to beginning of answer section.
        pNameFd,                                      // Pointer to name segments ("labels").
        pPartName;                                    
 pMyDNSRR pRmngRR;                                    // Pointer to rest of RR field.

 if (TDIClnRespCodeOK!=pRspData->RespCode)            // Some problem?
   {
    printf("  " JARtnName "():  Response code = 0x%04x\n", pRspData->RespCode);

    switch(pRspData->RespCode)                        // Add an explanation of the code value.
      {
       case TDIClnRespCodeFmtErr:
         printf("  " JARtnName "():                = Format error\n");
         break;

       case TDIClnRespCodeSvrErr:
         printf("  " JARtnName "():                = Server error\n");
         break;

       case TDIClnRespCodeNameErr:
         printf("  " JARtnName "():                = Name error; presumably an unknown name\n");
         break;

       case TDIClnRespCodeNotImplErr:
         printf("  " JARtnName "():                = Implementation error\n");
         break;

       case TDIClnRespCodeRefusedErr:
         printf("  " JARtnName "():                = Refused\n");
         break;

       default:
         printf("  " JARtnName "():                = Unknown\n");
      }

    goto exit;
   }                                                  // End 'if' some problem.

 for (                                                // Go through RR fields.
      i = 0;
      i < nbrAnswers;
      i ++
     )
   {
    USHORT NameOffset =                               // Pick up name offset plus, presumably, 2 high network-order bits.
             GetNetwkPort(*(PUSHORT)pCurrName);

    // Check for a relative pointer to name segments.

    #define RelPtrBits 0xc000

    if (RelPtrBits!=(NameOffset&RelPtrBits))          // 2 high network-order bits not on?
      {
       printf("  " JARtnName "():  Didn't find 2 high network-order bits on in current RR, i = %d, quitting interpretation\n", i);
       goto exit;
      }

    NameOffset &= ~RelPtrBits;                        // Turn off high-order 2 bits that indicate a pointer.

    pRmngRR = (pMyDNSRR)(pCurrName + 2);              // Point past pointer field, to rest of RR field.

    if (TDIClnCanonicalName==                         // Canonical RR type?
          GetNetwkPort(pRmngRR->RRType)
       )
      {
       USHORT NameOffset2 =                           // Pick up name offset plus, presumably, 2 high network-order bits.
                GetNetwkPort(*(PUSHORT)pRmngRR->RRData);

       if (                                           // Not a relative pointer to name segments?
           2!=GetNetwkPort(pRmngRR->RRDataLn)         // Data length not 2?
             ||
           RelPtrBits!=(NameOffset2&RelPtrBits)       // 2 high network-order bits not on?
          )
         {
          printf("  " JARtnName "():  Unrecognized data in canonical-RR RRData, quitting interpretation\n", i);
          goto exit;
         }

       NameOffset2 &= ~RelPtrBits;                    // Turn off high-order 2 bits that indicate a pointer.

       // Build original name.

       pNameFd =                                      // Point to original name segments.
            ((PUCHAR)pRspData) + FIELD_OFFSET(MyDNSQuery, QueryId) + NameOffset;

       pPartName = pNameFd;                           // Copy pointer to name field.

       FullName[0] = 0;                               // Ensure first byte is a null.

       do
         {
          pPartName =                                 // Build name, piece by piece.
            CopyNextNameSegment(pPartName, FullName);
         }
           while(NULL!=pPartName);

       FullName[strlen((const char *)FullName)-1] = 0;// Replace final '.' with null terminator.

       // Build canonical name.
        
       UCHAR CanonFullName[TDIClnDomainNameMaxLen+1] =// Area to build canonical name.
               {0};

       pNameFd =                                      // Point to canonical name segments.
            ((PUCHAR)pRspData) + FIELD_OFFSET(MyDNSQuery, QueryId) + NameOffset2;

       pPartName = pNameFd;                           // Copy pointer to name field.

       do
         {
          pPartName =                                 // Build name, piece by piece.
            CopyNextNameSegment(pPartName, CanonFullName);
         }
           while(NULL!=pPartName);

       CanonFullName[strlen((const char *)CanonFullName)-1] = 0;

       printf("  Canonical name of %s is %s\n", FullName, CanonFullName);

       pCurrName += TDIClnCanonRRLen;                 // Bump pointer to name.
      }                                               // End 'if' canonical RR type.
    else
    if (TDIClnHostAddr==                              // Host-address RR type?
          GetNetwkPort(pRmngRR->RRType)
       )
      {
       pNameFd =                                      // Point to original name segments.
            ((PUCHAR)pRspData) + FIELD_OFFSET(MyDNSQuery, QueryId) + NameOffset;

       pPartName = pNameFd;                           // Copy pointer to name field.

       FullName[0] = 0;                               // Ensure first byte is a null.

       do
         {
          pPartName =                                 // Build name, piece by piece.
            CopyNextNameSegment(pPartName, FullName);
         }
           while(NULL!=pPartName);

       FullName[strlen((const char *)FullName)-1] = 0;// Replace final '.' with null terminator.

       char IPAddr[16],
            Octet1[4],
            Octet2[4],
            Octet3[4],
            Octet4[4];

       ULONG addr =                                   // Get IP address, converting it from network form.
               GetNetwkAddrDw(*(PULONG)pRmngRR->RRData);

       _ultoa(addr>>24,              Octet1, 10);     // get ASCII
       _ultoa((0x00ff0000&addr)>>16, Octet2, 10);     //   form of
       _ultoa((0x0000ff00&addr)>>8,  Octet3, 10);     //     each
       _ultoa(0x000000ff&addr,       Octet4, 10);     //       piece.

       strcpy(IPAddr, Octet1);                        // Put
       strcat(IPAddr, ".");                           //   everything
       strcat(IPAddr, Octet2);                        //     together.
       strcat(IPAddr, ".");                           //        "
       strcat(IPAddr, Octet3);                        //        "
       strcat(IPAddr, ".");                           //        "
       strcat(IPAddr, Octet4);                        //        "

       printf("  Name = %s, IP addr = %s\n", FullName, IPAddr);

       pCurrName += TDIClnAddrRRLen;                  // Bump pointer to name.
      }
    else                                              // End 'if' host-address RR type.
      {
       printf("  " JARtnName "():  Unrecognized RRType = 0x%02x, quitting interpretation\n", GetNetwkPort(pRmngRR->RRType), i);
       goto exit;
      }
   }                                                  // End 'for' go through RR fields.
exit:
  return;
}                                                     // End ShowNSData().

/**************************************************************************************************/      
/*                                                                                                */      
/**************************************************************************************************/      
PUCHAR
CopyNextNameSegment(PUCHAR pInData, PUCHAR pStr)
  {
   PUCHAR pNextAvail;

   do                                                 // Single-iteration loop, to make possible escape via break.
     {
      UCHAR tmpName[TDIClnLabelMaxLen+1+1],
            ulChar = *pInData;                        // Pick up length field. 

      if (0==ulChar)                                  // Zero?
        {
         pNextAvail = NULL;
         break;
        }

      memcpy(tmpName, pInData+1, ulChar);             // Copy partial name to temp.

      tmpName[ulChar] = '.';                          // Append a period
      tmpName[ulChar+1] = 0;                          //   and a null terminator.

      strcat((char *)pStr, (char *)tmpName);          // Copy from temp to permanent.

      pNextAvail = pInData +                          // Point to next available byte in permanent.
                   strlen((char *)tmpName);
     } while(0);                                      // End 'do-while' single-iteration loop.

   return pNextAvail;
  }                                                   // End CopyNextNameSegment().

